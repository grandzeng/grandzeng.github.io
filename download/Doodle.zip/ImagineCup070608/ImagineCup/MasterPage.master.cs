﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using pageOperation;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using SketchDatabase.Util;
using SketchDatabase.Core;
using TaZeLi.Sketch;
using System.IO;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
            if (Session["user"] == null)
            {
                leftLogin.Visible = true;
                loginPanel.Visible = false;
            }
            else
            {
                leftLogin.Visible = false;
                loginPanel.Visible = true;
                User user = (User)Session["user"];
                LoginName.Text = user.Name;
            }
    }
    protected void LoginButton_Click(object sender, EventArgs e)
    {
        string userName = Login1.UserName.Trim();
        string userPWD = Login1.Password.Trim();
        User user = new User();
        user.Name = userName;
        DataAccess dataAccess = new DataAccess();
        if (!dataAccess.IsUserExists(user))
        {
            Login1.FailureText = "user dose not exist!";
            leftLogin.Visible = true;
            loginPanel.Visible = false;
        }
        else
        {
            user = dataAccess.FindUser(user.Name);
            if (user.Password.Equals(userPWD))
            {
                Session["user"] = user;
                leftLogin.Visible = false;
                loginPanel.Visible = true;
                LoginName.Text = "" + user.Name;
            }
            else
            {
                Login1.FailureText = "password errer!";
                leftLogin.Visible = true;
                loginPanel.Visible = false;
            }
        }
    }
    protected void logout_Click(object sender, ImageClickEventArgs e)
    {
        Session.Remove("user");
        leftLogin.Visible = true;
        loginPanel.Visible = false;
        Response.Redirect("Default.aspx");
    }
    protected void Register_Click(object sender, EventArgs e)
    {
        Response.Redirect("UserInfo.aspx?op=register");
    }

}
