﻿namespace ShapeContextGUIDemo
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.ImageDatabaseListView = new System.Windows.Forms.ListView();
            this.ImageDatabasePathBrowseButton = new System.Windows.Forms.Button();
            this.ImageDatabasePathTextbox = new System.Windows.Forms.TextBox();
            this.ImageDatabaseLoadButton = new System.Windows.Forms.Button();
            this.MainTableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.ImageDatabaseTableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.ImageDatabasePathTableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.ImageDatabaseSaveButton = new System.Windows.Forms.Button();
            this.QueryImageTableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.QueryPictureBox = new System.Windows.Forms.PictureBox();
            this.QueryResultListView = new System.Windows.Forms.ListView();
            this.QueryButton = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.OpenQueryImageButton = new System.Windows.Forms.Button();
            this.CreateNewQueryImageButton = new System.Windows.Forms.Button();
            this.AddQueryImageToImageDatabaseButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.ImageDatabaseStatusLabel = new System.Windows.Forms.Label();
            this.SpatialFeatureHashCheckBox = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.RemoveImageRecordButton = new System.Windows.Forms.Button();
            this.ExtractImageRecordButton = new System.Windows.Forms.Button();
            this.RemoveAllImageRecordButton = new System.Windows.Forms.Button();
            this.SaveQueryImageButton = new System.Windows.Forms.Button();
            this.AddImageToImageDatabaseButton = new System.Windows.Forms.Button();
            this.MainTableLayoutPanel.SuspendLayout();
            this.ImageDatabaseTableLayoutPanel.SuspendLayout();
            this.ImageDatabasePathTableLayoutPanel.SuspendLayout();
            this.QueryImageTableLayoutPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.QueryPictureBox)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // ImageDatabaseListView
            // 
            this.ImageDatabaseListView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ImageDatabaseListView.Location = new System.Drawing.Point(3, 36);
            this.ImageDatabaseListView.Name = "ImageDatabaseListView";
            this.ImageDatabaseListView.Size = new System.Drawing.Size(505, 369);
            this.ImageDatabaseListView.TabIndex = 1;
            this.ImageDatabaseListView.TileSize = new System.Drawing.Size(200, 200);
            this.ImageDatabaseListView.UseCompatibleStateImageBehavior = false;
            // 
            // ImageDatabasePathBrowseButton
            // 
            this.ImageDatabasePathBrowseButton.Location = new System.Drawing.Point(298, 3);
            this.ImageDatabasePathBrowseButton.Name = "ImageDatabasePathBrowseButton";
            this.ImageDatabasePathBrowseButton.Size = new System.Drawing.Size(64, 21);
            this.ImageDatabasePathBrowseButton.TabIndex = 0;
            this.ImageDatabasePathBrowseButton.Text = "Open";
            this.ImageDatabasePathBrowseButton.UseVisualStyleBackColor = true;
            this.ImageDatabasePathBrowseButton.Click += new System.EventHandler(this.ImageDatabasePathOpenButton_Click);
            // 
            // ImageDatabasePathTextbox
            // 
            this.ImageDatabasePathTextbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ImageDatabasePathTextbox.Location = new System.Drawing.Point(3, 3);
            this.ImageDatabasePathTextbox.Name = "ImageDatabasePathTextbox";
            this.ImageDatabasePathTextbox.Size = new System.Drawing.Size(289, 21);
            this.ImageDatabasePathTextbox.TabIndex = 1;
            // 
            // ImageDatabaseLoadButton
            // 
            this.ImageDatabaseLoadButton.Location = new System.Drawing.Point(368, 3);
            this.ImageDatabaseLoadButton.Name = "ImageDatabaseLoadButton";
            this.ImageDatabaseLoadButton.Size = new System.Drawing.Size(64, 21);
            this.ImageDatabaseLoadButton.TabIndex = 2;
            this.ImageDatabaseLoadButton.Text = "Load";
            this.ImageDatabaseLoadButton.UseVisualStyleBackColor = true;
            this.ImageDatabaseLoadButton.Click += new System.EventHandler(this.ImageDatabaseLoadButton_Click);
            // 
            // MainTableLayoutPanel
            // 
            this.MainTableLayoutPanel.ColumnCount = 2;
            this.MainTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.91216F));
            this.MainTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 69.08784F));
            this.MainTableLayoutPanel.Controls.Add(this.ImageDatabaseTableLayoutPanel, 1, 0);
            this.MainTableLayoutPanel.Controls.Add(this.QueryImageTableLayoutPanel, 0, 0);
            this.MainTableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainTableLayoutPanel.Location = new System.Drawing.Point(0, 0);
            this.MainTableLayoutPanel.Name = "MainTableLayoutPanel";
            this.MainTableLayoutPanel.RowCount = 1;
            this.MainTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MainTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.MainTableLayoutPanel.Size = new System.Drawing.Size(747, 447);
            this.MainTableLayoutPanel.TabIndex = 3;
            // 
            // ImageDatabaseTableLayoutPanel
            // 
            this.ImageDatabaseTableLayoutPanel.ColumnCount = 1;
            this.ImageDatabaseTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.ImageDatabaseTableLayoutPanel.Controls.Add(this.ImageDatabasePathTableLayoutPanel, 0, 0);
            this.ImageDatabaseTableLayoutPanel.Controls.Add(this.ImageDatabaseListView, 0, 1);
            this.ImageDatabaseTableLayoutPanel.Controls.Add(this.tableLayoutPanel2, 0, 2);
            this.ImageDatabaseTableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ImageDatabaseTableLayoutPanel.Location = new System.Drawing.Point(233, 3);
            this.ImageDatabaseTableLayoutPanel.Name = "ImageDatabaseTableLayoutPanel";
            this.ImageDatabaseTableLayoutPanel.RowCount = 3;
            this.ImageDatabaseTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.ImageDatabaseTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.ImageDatabaseTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.ImageDatabaseTableLayoutPanel.Size = new System.Drawing.Size(511, 441);
            this.ImageDatabaseTableLayoutPanel.TabIndex = 0;
            // 
            // ImageDatabasePathTableLayoutPanel
            // 
            this.ImageDatabasePathTableLayoutPanel.ColumnCount = 4;
            this.ImageDatabasePathTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.ImageDatabasePathTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.ImageDatabasePathTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.ImageDatabasePathTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.ImageDatabasePathTableLayoutPanel.Controls.Add(this.ImageDatabasePathTextbox, 0, 0);
            this.ImageDatabasePathTableLayoutPanel.Controls.Add(this.ImageDatabaseLoadButton, 2, 0);
            this.ImageDatabasePathTableLayoutPanel.Controls.Add(this.ImageDatabasePathBrowseButton, 1, 0);
            this.ImageDatabasePathTableLayoutPanel.Controls.Add(this.ImageDatabaseSaveButton, 3, 0);
            this.ImageDatabasePathTableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ImageDatabasePathTableLayoutPanel.Location = new System.Drawing.Point(3, 3);
            this.ImageDatabasePathTableLayoutPanel.Name = "ImageDatabasePathTableLayoutPanel";
            this.ImageDatabasePathTableLayoutPanel.RowCount = 1;
            this.ImageDatabasePathTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.ImageDatabasePathTableLayoutPanel.Size = new System.Drawing.Size(505, 27);
            this.ImageDatabasePathTableLayoutPanel.TabIndex = 0;
            // 
            // ImageDatabaseSaveButton
            // 
            this.ImageDatabaseSaveButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ImageDatabaseSaveButton.Location = new System.Drawing.Point(438, 3);
            this.ImageDatabaseSaveButton.Name = "ImageDatabaseSaveButton";
            this.ImageDatabaseSaveButton.Size = new System.Drawing.Size(64, 21);
            this.ImageDatabaseSaveButton.TabIndex = 3;
            this.ImageDatabaseSaveButton.Text = "Save";
            this.ImageDatabaseSaveButton.UseVisualStyleBackColor = true;
            this.ImageDatabaseSaveButton.Click += new System.EventHandler(this.ImageDatabaseSaveButton_Click);
            // 
            // QueryImageTableLayoutPanel
            // 
            this.QueryImageTableLayoutPanel.ColumnCount = 1;
            this.QueryImageTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.QueryImageTableLayoutPanel.Controls.Add(this.QueryPictureBox, 0, 1);
            this.QueryImageTableLayoutPanel.Controls.Add(this.QueryResultListView, 0, 4);
            this.QueryImageTableLayoutPanel.Controls.Add(this.QueryButton, 0, 3);
            this.QueryImageTableLayoutPanel.Controls.Add(this.tableLayoutPanel1, 0, 2);
            this.QueryImageTableLayoutPanel.Controls.Add(this.label1, 0, 0);
            this.QueryImageTableLayoutPanel.Controls.Add(this.ImageDatabaseStatusLabel, 0, 6);
            this.QueryImageTableLayoutPanel.Controls.Add(this.SpatialFeatureHashCheckBox, 0, 5);
            this.QueryImageTableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.QueryImageTableLayoutPanel.Location = new System.Drawing.Point(3, 3);
            this.QueryImageTableLayoutPanel.Name = "QueryImageTableLayoutPanel";
            this.QueryImageTableLayoutPanel.RowCount = 7;
            this.QueryImageTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.QueryImageTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.QueryImageTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.QueryImageTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.QueryImageTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.QueryImageTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.QueryImageTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.QueryImageTableLayoutPanel.Size = new System.Drawing.Size(224, 441);
            this.QueryImageTableLayoutPanel.TabIndex = 1;
            // 
            // QueryPictureBox
            // 
            this.QueryPictureBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.QueryPictureBox.Location = new System.Drawing.Point(3, 33);
            this.QueryPictureBox.Name = "QueryPictureBox";
            this.QueryPictureBox.Size = new System.Drawing.Size(218, 110);
            this.QueryPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.QueryPictureBox.TabIndex = 1;
            this.QueryPictureBox.TabStop = false;
            // 
            // QueryResultListView
            // 
            this.QueryResultListView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.QueryResultListView.Location = new System.Drawing.Point(3, 219);
            this.QueryResultListView.Name = "QueryResultListView";
            this.QueryResultListView.Size = new System.Drawing.Size(218, 168);
            this.QueryResultListView.TabIndex = 2;
            this.QueryResultListView.UseCompatibleStateImageBehavior = false;
            // 
            // QueryButton
            // 
            this.QueryButton.Location = new System.Drawing.Point(3, 189);
            this.QueryButton.Name = "QueryButton";
            this.QueryButton.Size = new System.Drawing.Size(75, 23);
            this.QueryButton.TabIndex = 3;
            this.QueryButton.Text = "Query";
            this.QueryButton.UseVisualStyleBackColor = true;
            this.QueryButton.Click += new System.EventHandler(this.QueryButton_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 54F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 52F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 55F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.tableLayoutPanel1.Controls.Add(this.OpenQueryImageButton, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.CreateNewQueryImageButton, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.AddQueryImageToImageDatabaseButton, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.SaveQueryImageButton, 3, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 149);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(218, 34);
            this.tableLayoutPanel1.TabIndex = 4;
            // 
            // OpenQueryImageButton
            // 
            this.OpenQueryImageButton.Location = new System.Drawing.Point(3, 3);
            this.OpenQueryImageButton.Name = "OpenQueryImageButton";
            this.OpenQueryImageButton.Size = new System.Drawing.Size(48, 23);
            this.OpenQueryImageButton.TabIndex = 0;
            this.OpenQueryImageButton.Text = "Open";
            this.OpenQueryImageButton.UseVisualStyleBackColor = true;
            this.OpenQueryImageButton.Click += new System.EventHandler(this.OpenQueryImageButton_Click);
            // 
            // CreateNewQueryImageButton
            // 
            this.CreateNewQueryImageButton.Location = new System.Drawing.Point(57, 3);
            this.CreateNewQueryImageButton.Name = "CreateNewQueryImageButton";
            this.CreateNewQueryImageButton.Size = new System.Drawing.Size(46, 23);
            this.CreateNewQueryImageButton.TabIndex = 0;
            this.CreateNewQueryImageButton.Text = "New Image";
            this.CreateNewQueryImageButton.UseVisualStyleBackColor = true;
            this.CreateNewQueryImageButton.Click += new System.EventHandler(this.CreateNewQueryImageButton_Click);
            // 
            // AddQueryImageToImageDatabaseButton
            // 
            this.AddQueryImageToImageDatabaseButton.Location = new System.Drawing.Point(109, 3);
            this.AddQueryImageToImageDatabaseButton.Name = "AddQueryImageToImageDatabaseButton";
            this.AddQueryImageToImageDatabaseButton.Size = new System.Drawing.Size(49, 23);
            this.AddQueryImageToImageDatabaseButton.TabIndex = 1;
            this.AddQueryImageToImageDatabaseButton.Text = "Add";
            this.AddQueryImageToImageDatabaseButton.UseVisualStyleBackColor = true;
            this.AddQueryImageToImageDatabaseButton.Click += new System.EventHandler(this.AddQueryImageToImageDatabaseButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 12);
            this.label1.TabIndex = 5;
            this.label1.Text = "Query Image :";
            // 
            // ImageDatabaseStatusLabel
            // 
            this.ImageDatabaseStatusLabel.AutoSize = true;
            this.ImageDatabaseStatusLabel.Font = new System.Drawing.Font("Tahoma", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ImageDatabaseStatusLabel.ForeColor = System.Drawing.Color.Red;
            this.ImageDatabaseStatusLabel.Location = new System.Drawing.Point(3, 410);
            this.ImageDatabaseStatusLabel.Name = "ImageDatabaseStatusLabel";
            this.ImageDatabaseStatusLabel.Size = new System.Drawing.Size(51, 17);
            this.ImageDatabaseStatusLabel.TabIndex = 6;
            this.ImageDatabaseStatusLabel.Text = "Normal";
            // 
            // SpatialFeatureHashCheckBox
            // 
            this.SpatialFeatureHashCheckBox.AutoSize = true;
            this.SpatialFeatureHashCheckBox.Checked = true;
            this.SpatialFeatureHashCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.SpatialFeatureHashCheckBox.Location = new System.Drawing.Point(3, 393);
            this.SpatialFeatureHashCheckBox.Name = "SpatialFeatureHashCheckBox";
            this.SpatialFeatureHashCheckBox.Size = new System.Drawing.Size(84, 14);
            this.SpatialFeatureHashCheckBox.TabIndex = 7;
            this.SpatialFeatureHashCheckBox.Text = "Use hash ?";
            this.SpatialFeatureHashCheckBox.UseVisualStyleBackColor = true;
            this.SpatialFeatureHashCheckBox.CheckedChanged += new System.EventHandler(this.SpatialFeatureHashCheckBox_CheckedChanged);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 5;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 76F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 77F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 74F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.RemoveImageRecordButton, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.ExtractImageRecordButton, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.RemoveAllImageRecordButton, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.AddImageToImageDatabaseButton, 3, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 411);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(505, 27);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // RemoveImageRecordButton
            // 
            this.RemoveImageRecordButton.Location = new System.Drawing.Point(3, 3);
            this.RemoveImageRecordButton.Name = "RemoveImageRecordButton";
            this.RemoveImageRecordButton.Size = new System.Drawing.Size(70, 21);
            this.RemoveImageRecordButton.TabIndex = 0;
            this.RemoveImageRecordButton.Text = "Remove";
            this.RemoveImageRecordButton.UseVisualStyleBackColor = true;
            this.RemoveImageRecordButton.Click += new System.EventHandler(this.RemoveImageRecordButton_Click);
            // 
            // ExtractImageRecordButton
            // 
            this.ExtractImageRecordButton.Location = new System.Drawing.Point(79, 3);
            this.ExtractImageRecordButton.Name = "ExtractImageRecordButton";
            this.ExtractImageRecordButton.Size = new System.Drawing.Size(71, 21);
            this.ExtractImageRecordButton.TabIndex = 1;
            this.ExtractImageRecordButton.Text = "Extract";
            this.ExtractImageRecordButton.UseVisualStyleBackColor = true;
            this.ExtractImageRecordButton.Click += new System.EventHandler(this.ExtractImageRecordButton_Click);
            // 
            // RemoveAllImageRecordButton
            // 
            this.RemoveAllImageRecordButton.Location = new System.Drawing.Point(156, 3);
            this.RemoveAllImageRecordButton.Name = "RemoveAllImageRecordButton";
            this.RemoveAllImageRecordButton.Size = new System.Drawing.Size(68, 21);
            this.RemoveAllImageRecordButton.TabIndex = 2;
            this.RemoveAllImageRecordButton.Text = "Clear";
            this.RemoveAllImageRecordButton.UseVisualStyleBackColor = true;
            this.RemoveAllImageRecordButton.Click += new System.EventHandler(this.RemoveAllImageRecordButton_Click);
            // 
            // SaveQueryImageButton
            // 
            this.SaveQueryImageButton.Location = new System.Drawing.Point(164, 3);
            this.SaveQueryImageButton.Name = "SaveQueryImageButton";
            this.SaveQueryImageButton.Size = new System.Drawing.Size(51, 23);
            this.SaveQueryImageButton.TabIndex = 2;
            this.SaveQueryImageButton.Text = "Save";
            this.SaveQueryImageButton.UseVisualStyleBackColor = true;
            this.SaveQueryImageButton.Click += new System.EventHandler(this.SaveQueryImageButton_Click);
            // 
            // AddImageToImageDatabaseButton
            // 
            this.AddImageToImageDatabaseButton.Location = new System.Drawing.Point(230, 3);
            this.AddImageToImageDatabaseButton.Name = "AddImageToImageDatabaseButton";
            this.AddImageToImageDatabaseButton.Size = new System.Drawing.Size(66, 21);
            this.AddImageToImageDatabaseButton.TabIndex = 3;
            this.AddImageToImageDatabaseButton.Text = "Add";
            this.AddImageToImageDatabaseButton.UseVisualStyleBackColor = true;
            this.AddImageToImageDatabaseButton.Click += new System.EventHandler(this.AddImageToImageDatabaseButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(747, 447);
            this.Controls.Add(this.MainTableLayoutPanel);
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.MainTableLayoutPanel.ResumeLayout(false);
            this.ImageDatabaseTableLayoutPanel.ResumeLayout(false);
            this.ImageDatabasePathTableLayoutPanel.ResumeLayout(false);
            this.ImageDatabasePathTableLayoutPanel.PerformLayout();
            this.QueryImageTableLayoutPanel.ResumeLayout(false);
            this.QueryImageTableLayoutPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.QueryPictureBox)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView ImageDatabaseListView;
        private System.Windows.Forms.Button ImageDatabasePathBrowseButton;
        private System.Windows.Forms.TextBox ImageDatabasePathTextbox;
        private System.Windows.Forms.Button ImageDatabaseLoadButton;
        private System.Windows.Forms.TableLayoutPanel MainTableLayoutPanel;
        private System.Windows.Forms.TableLayoutPanel ImageDatabaseTableLayoutPanel;
        private System.Windows.Forms.TableLayoutPanel ImageDatabasePathTableLayoutPanel;
        private System.Windows.Forms.TableLayoutPanel QueryImageTableLayoutPanel;
        private System.Windows.Forms.Button OpenQueryImageButton;
        private System.Windows.Forms.PictureBox QueryPictureBox;
        private System.Windows.Forms.ListView QueryResultListView;
        private System.Windows.Forms.Button QueryButton;
        private System.Windows.Forms.Button ImageDatabaseSaveButton;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button CreateNewQueryImageButton;
        private System.Windows.Forms.Button AddQueryImageToImageDatabaseButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label ImageDatabaseStatusLabel;
        private System.Windows.Forms.CheckBox SpatialFeatureHashCheckBox;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button RemoveImageRecordButton;
        private System.Windows.Forms.Button ExtractImageRecordButton;
        private System.Windows.Forms.Button RemoveAllImageRecordButton;
        private System.Windows.Forms.Button SaveQueryImageButton;
        private System.Windows.Forms.Button AddImageToImageDatabaseButton;
        








    }
}

