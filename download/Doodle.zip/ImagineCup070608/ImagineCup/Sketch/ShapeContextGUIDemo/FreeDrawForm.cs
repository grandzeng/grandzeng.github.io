﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Resources;
using System.IO;
using ShapeContextGUIDemo.Properties;

namespace ShapeContextGUIDemo
{
    public partial class FreeDrawForm : Form
    {
        private Bitmap _bitmap = null;
        private Point _last_point = new Point();
        private Point _cur_point = new Point();
        private bool _buttondown = false;
        private Graphics _bitmap_graphics;
        private Graphics _panel_graphics;


        public FreeDrawForm()
        {
            InitializeComponent();
            _bitmap = new Bitmap(this.DrawPanel.Width, this.DrawPanel.Height);
            _bitmap_graphics = Graphics.FromImage(_bitmap);
            _bitmap_graphics.Clear(Color.White);
            _panel_graphics = Graphics.FromHwnd(this.DrawPanel.Handle);
            this.DrawPanel.Cursor = new Cursor(new MemoryStream(Resources.PENCIL));
        }

        private void OKButton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void CancelExitButton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void DrawPanel_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.DrawImage(_bitmap, new Point(0, 0));
        }

        private void DrawPanel_MouseDown(object sender, MouseEventArgs e)
        {
            _buttondown = true;
            _last_point.X = e.X;
            _last_point.Y = e.Y;
            _bitmap_graphics.DrawLine(Pens.Black, _last_point, _last_point);
            _panel_graphics.DrawLine(Pens.Black, _last_point, _last_point);
        }

        private void DrawPanel_MouseUp(object sender, MouseEventArgs e)
        {
            _buttondown = false;
            _last_point.X = e.X;
            _last_point.Y = e.Y;
            _bitmap_graphics.DrawLine(Pens.Black, _last_point, _last_point);
            _panel_graphics.DrawLine(Pens.Black, _last_point, _last_point);

        }

        private void DrawPanel_MouseMove(object sender, MouseEventArgs e)
        {
            if (_buttondown)
            {
                _cur_point.X = e.X;
                _cur_point.Y = e.Y;
                _bitmap_graphics.DrawLine(Pens.Black, _last_point, _cur_point);
                _panel_graphics.DrawLine(Pens.Black, _last_point, _cur_point);
                _last_point = _cur_point;
            }
        }

        public Bitmap GetBitmap()
        {
            return _bitmap;
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            _bitmap_graphics.Clear(Color.White);
            _panel_graphics.Clear(Color.White);
        }

    }
}