﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ShapeContextGUIDemo
{
    public partial class InputImageIDForm : Form
    {
        private string _image_id = "";

        public InputImageIDForm()
        {
            InitializeComponent();
        }

        private void OKButton_Click(object sender, EventArgs e)
        {
            _image_id = this.ImageIDTextBox.Text;
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void CancelExitButton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        public string GetImageID()
        {
            return _image_id;
        }
    }
}