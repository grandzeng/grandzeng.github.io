﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using ShapeContextGUIDemo.Properties;
using TaZeLi.Sketch;

namespace ShapeContextGUIDemo
{
    public partial class MainForm : Form
    {
        private IGenericImageDatabase _db = null;
        private Image _query_image = null;
        private ImageList _db_imagelist = null;
        private static readonly int TOP_NUM = 3;

        public MainForm()
        {
            InitializeComponent();
            _db = GenericImageDatabaseFactory.CreateShapeContextDB();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            _db.Close();
        }

        private void ImageDatabasePathOpenButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                string path = dlg.FileName;
                this.ImageDatabasePathTextbox.Text = path;
                ImageDatabaseLoadButton_Click(sender, e);
            }
        }

        private void ImageDatabaseLoadButton_Click(object sender, EventArgs e)
        {
            string path = this.ImageDatabasePathTextbox.Text;
            if (path != null && path.Length > 0)
            {
                try
                {
                    _db.Load(path);
                    UpdateImageDatabaseListView();
                }
                catch (FileNotFoundException)
                {
                    MessageBox.Show("File not found : " + path);
                }
            }
        }

        private void ImageDatabaseSaveButton_Click(object sender, EventArgs e)
        {
            string path = this.ImageDatabasePathTextbox.Text;
            if (path != null && path.Length > 0)
            {
                _db.Save(path);
                MessageBox.Show("Image database was saved OK!");
            }
        }


        private void UpdateImageDatabaseListView()
        {
            this.ImageDatabaseListView.Items.Clear();

            int ListViewImageSize = Settings.Default.ListViewImageSize;
            _db_imagelist = new ImageList();
            this.ImageDatabaseListView.SmallImageList = _db_imagelist;
            this.ImageDatabaseListView.LargeImageList = _db_imagelist;
            this.ImageDatabaseListView.StateImageList = _db_imagelist;
            _db_imagelist.ImageSize = new Size(ListViewImageSize, ListViewImageSize);
            for (int i = 0; i < _db.Count(); i++)
            {
                GenericImageRecord imageRecord = _db.GetAt(i);
                Image image = imageRecord.GetImage();
                _db_imagelist.Images.Add(image);
                this.ImageDatabaseListView.Items.Add(imageRecord.GetID(), i);
            }
            this.ImageDatabaseListView.Update();

        }

        private void OpenQueryImageButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                _query_image = Image.FromFile(dlg.FileName);
                this.QueryPictureBox.Image = _query_image;
            }
        }

        private void ExecuteQueryImageProcess()
        {
            this.ImageDatabaseStatusLabel.Text = "Processing querying...please wait";
            this.Cursor = Cursors.WaitCursor;
            this.QueryResultListView.Items.Clear();
            this.Update();

            GenericImageRecord query = new GenericImageRecord();
            query.Create(_query_image, Color.White);
            GenericImageQueryResultSet rets = _db.Query(query, TOP_NUM);
            if (rets == null || rets.Count() == 0)
                return;

            int ListViewImageSize = Settings.Default.ListViewImageSize;
            ImageList resultsImageList = new ImageList();
            resultsImageList.ImageSize = new Size(ListViewImageSize, ListViewImageSize);
            for (int i = 0; i < rets.Count(); i++)
            {
                GenericImageRecord record = rets.GetRecord(i);
                resultsImageList.Images.Add(record.GetImage());
            }

            this.QueryResultListView.SmallImageList = resultsImageList;
            this.QueryResultListView.LargeImageList = resultsImageList;
            for (int i = 0; i < rets.Count(); i++)
                this.QueryResultListView.Items.Add(rets.GetRecord(i).GetID() + " : " + rets.GetDifference(i), i);

            this.ImageDatabaseStatusLabel.Text = "Normal.";
            this.Cursor = Cursors.Default;
            this.Update();
        }

        private void QueryButton_Click(object sender, EventArgs e)
        {
            ExecuteQueryImageProcess();
        }

        private void CreateNewQueryImageButton_Click(object sender, EventArgs e)
        {
            FreeDrawForm draw = new FreeDrawForm();
            if (draw.ShowDialog() == DialogResult.OK)
            {
                Bitmap drawbitmap = draw.GetBitmap();
                _query_image = drawbitmap;
                this.QueryPictureBox.Image = drawbitmap;
            }
        }

        private void AddQueryImageToImageDatabaseButton_Click(object sender, EventArgs e)
        {
            InputImageIDForm dlg = new InputImageIDForm();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                this.ImageDatabaseStatusLabel.Text = "Processing adding...please wait.";
                this.Cursor = Cursors.WaitCursor;
                this.Update();

                GenericImageRecord record = new GenericImageRecord(dlg.GetImageID(),_query_image,Color.White);
                _db.Add(record);
                UpdateImageDatabaseListView();
                this.ImageDatabaseStatusLabel.Text = "Normal.";

                this.Cursor = Cursors.Default;
                this.Update();
            }
        }

        private void SpatialFeatureHashCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (this.SpatialFeatureHashCheckBox.Checked)
                _db.SetAttribute("spaitalhash", "true");
            else
                _db.SetAttribute("spaitalhash", "false");
        }

        private void SaveQueryImageButton_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            if(dlg.ShowDialog() == DialogResult.OK)
            {
                string path = dlg.FileName;
                _query_image.Save(path);
                MessageBox.Show("Save image : " + path + " OK!");
            }
        }

        private void RemoveImageRecordButton_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < this.ImageDatabaseListView.SelectedIndices.Count; i++)
            {
                int index = this.ImageDatabaseListView.SelectedIndices[i];
                this.ImageDatabaseListView.Items.RemoveAt(index);
                _db_imagelist.Images.RemoveAt(index);
                _db.RemoveAt(index);
            }
            this.Update();
        }

        private void ExtractImageRecordButton_Click(object sender, EventArgs e)
        {
            if (this.ImageDatabaseListView.SelectedIndices.Count == 1)
            {
                int index = this.ImageDatabaseListView.SelectedIndices[0];
                GenericImageRecord record = _db.GetAt(index);
                Image image = record.GetImage();
                SaveFileDialog dlg = new SaveFileDialog();
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    string path = dlg.FileName;
                    image.Save(path);
                }
            }
        }

        private void RemoveAllImageRecordButton_Click(object sender, EventArgs e)
        {
            this.ImageDatabaseListView.Items.Clear();
            _db_imagelist.Images.Clear();
            _db.Clear();
            this.Update();
        }

        private void AddImageToImageDatabaseButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                string[] paths = dlg.FileNames;
                for (int i = 0; i < paths.Length; i++)
                {
                    Image image = Image.FromFile(paths[i]);
                    GenericImageRecord record = new GenericImageRecord(paths[i], image, Color.White);
                    _db.Add(record);
                    _db_imagelist.Images.Add(image);
                    this.ImageDatabaseListView.Items.Add(paths[i], _db.Count() - 1);
                }
            }
        }

    }
}
