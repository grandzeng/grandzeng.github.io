﻿namespace ShapeContextGUIDemo
{
    partial class InputImageIDForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.ImageIDTextBox = new System.Windows.Forms.TextBox();
            this.OKButton = new System.Windows.Forms.Button();
            this.CancelExitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ImageIDTextBox
            // 
            this.ImageIDTextBox.Location = new System.Drawing.Point(12, 10);
            this.ImageIDTextBox.Name = "ImageIDTextBox";
            this.ImageIDTextBox.Size = new System.Drawing.Size(228, 21);
            this.ImageIDTextBox.TabIndex = 0;
            // 
            // OKButton
            // 
            this.OKButton.Location = new System.Drawing.Point(12, 37);
            this.OKButton.Name = "OKButton";
            this.OKButton.Size = new System.Drawing.Size(75, 23);
            this.OKButton.TabIndex = 1;
            this.OKButton.Text = "OK";
            this.OKButton.UseVisualStyleBackColor = true;
            this.OKButton.Click += new System.EventHandler(this.OKButton_Click);
            // 
            // CancelButton
            // 
            this.CancelExitButton.Location = new System.Drawing.Point(165, 37);
            this.CancelExitButton.Name = "CancelButton";
            this.CancelExitButton.Size = new System.Drawing.Size(75, 23);
            this.CancelExitButton.TabIndex = 2;
            this.CancelExitButton.Text = "Cancel";
            this.CancelExitButton.UseVisualStyleBackColor = true;
            this.CancelExitButton.Click += new System.EventHandler(this.CancelExitButton_Click);
            // 
            // InputImageIDForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(250, 70);
            this.Controls.Add(this.CancelExitButton);
            this.Controls.Add(this.OKButton);
            this.Controls.Add(this.ImageIDTextBox);
            this.Name = "InputImageIDForm";
            this.Text = "InputImageIDForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox ImageIDTextBox;
        private System.Windows.Forms.Button OKButton;
        private System.Windows.Forms.Button CancelExitButton;
    }
}