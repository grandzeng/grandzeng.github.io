#include "SEEngine.h"

_SE_BEGIN

SEEngine::SEEngine(void)
{
	_maxPointCount = MAX_POINT_COUNT;
	_shapeContextBuf = NULL;
}

SEEngine::~SEEngine(void)
{
	if(_shapeContextBuf != NULL)
		delete[] _shapeContextBuf;
}

void SEEngine::Initialize( void )
{
	_pointShapeContext.Initialize();
	_imageShapeContext.Initialize(&_pointShapeContext);
	_binSize = _pointShapeContext.GetBinLength();
	_shapeContextBuf = new int[GetShapeContextMaxBufferSize()];
}

void SEEngine::Initialize(int maxPointCount)
{
	_maxPointCount = maxPointCount;
	Initialize();
}

void SEEngine::Destroy( void )
{
	delete[] _shapeContextBuf;
	_shapeContextBuf = NULL;
}


_SE_END
