#ifndef _SE_IMAGESHAPECONTEXT_H_
#define _SE_IMAGESHAPECONTEXT_H_

#include "global.h"
#include "SEPointsMatrix.h"
#include "SEPointShapeContext.h"

_SE_BEGIN

#define DUMMY_NODE 250.0

class SEImageShapeContext
{
public:
	SEImageShapeContext(void);
public:
	~SEImageShapeContext(void);

public:
	void Initialize(SEPointShapeContext* point_shapecontext);

	void CalPointsMatrix(int* x,int* y,int num, SEPointsMatrix& retMatrix);

	double CalPointsDifference(SEPointsMatrix& matrix1, SEPointsMatrix& matrix2);

private:
	void CalDistMatrix(int* x,int* y,int num, SEMatrix<int>& matrix);

	void CalThetaMatrix(int* x,int* y,int num, SEMatrix<int>& matrix);

private:
	SEPointShapeContext* _point_shapecontext;

	double _dummy_node;
};

_SE_END

#endif
