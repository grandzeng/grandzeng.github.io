#ifndef _SE_POINTSHAPECONTEXT_H_
#define _SE_POINTSHAPECONTEXT_H_

#include "global.h"
#include "SEMatrix.h"

_SE_BEGIN

class SEPointShapeContext
{
public:
	SEPointShapeContext(void);
public:
	~SEPointShapeContext(void);

public:

	void Initialize();

	void Initialize(int max_dist, int dist_binszie, int theta_binsize);

	int  GetBinLength();

	void CalPointBins(int* bins, int* x,int* y, int num, int center, SEMatrix<int>& dist, SEMatrix<int>& angle);

	static double CalPointDifference(int* bins1, int* bins2, int num);

	inline double GetLogDistScale() { return _log_dist_scale; };

	inline double GetThetaScale() { return _theta_scale; };


private:
	double    _log_dist_scale;
	double    _theta_scale;
	int       _max_dist;
	int       _log_dist_binsize;
	int       _theta_binsize;

	static const int DEFAULT_MAX_DIST = 128;
	static const int DEFAULT_LOG_DIST_BINSIZE = 6;
	static const int DEFAULT_THETA_BINSIZE = 12;
	
};

_SE_END

#endif 
