#include "SEEnvironment.h"
#include <cstdio>
_SE_BEGIN

SEEnvironment::SEEnvironment(void)
{
}

SEEnvironment::~SEEnvironment(void)
{
}

void SEEnvironment::SetValue(std::string& key, std::string& val)
{
	_map.insert(std::make_pair(key,val));
}

void SEEnvironment::SetValue(std::string& key, int val)
{
	char temp[64];
	itoa(val,temp, 10);
	std::string strVal(temp);
	_map.insert(std::make_pair(key,strVal));
}

void SEEnvironment::SetValue(std::string& key, double val)
{
	char temp[64];
	gcvt(val,12,temp);
	std::string strVal(temp);
	_map.insert(std::make_pair(key,strVal));
}

string SEEnvironment::GetValue(std::string& key)
{
	std::string empty;
	empty.clear();
	map<string,string>::const_iterator it = _map.find(key);
	if(it == _map.end())
		return empty;
	return (*it).second;
}

int SEEnvironment::GetIntValue(std::string &key)
{
	std::string strVal = GetValue(key);
	if(strVal.empty())
		return 0;
	const char* cstr = strVal.data();
	return atoi(cstr);
}

double SEEnvironment::GetDoubleValue(std::string &key)
{
	std::string strVal = GetValue(key);
	if(strVal.empty())
		return 0.0;
	const char* cstr = strVal.data();
	return atof(cstr);

}

_SE_END
