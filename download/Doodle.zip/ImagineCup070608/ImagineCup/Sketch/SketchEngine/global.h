#ifndef _GLOBAL_H_
#define _GLOBAL_H_



#define _SE_BEGIN namespace sketchengine {
#define _SE_END }
#define _SE_USE using namespace sketchengine

#endif
