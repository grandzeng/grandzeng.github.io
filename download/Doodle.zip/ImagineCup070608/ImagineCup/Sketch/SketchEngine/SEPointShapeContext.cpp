#include "SEPointShapeContext.h"

#include <cmath>
#include <cstdio>
#include <algorithm>

#include "global.h"
#include "SEMath.h"
#include "SEMatrix.h"

_SE_BEGIN

SEPointShapeContext::SEPointShapeContext(void)
{
	_max_dist = DEFAULT_MAX_DIST;
	_log_dist_binsize = DEFAULT_LOG_DIST_BINSIZE;
	_theta_binsize = DEFAULT_THETA_BINSIZE;
}

SEPointShapeContext::~SEPointShapeContext(void)
{
}

void SEPointShapeContext::Initialize()
{
	_log_dist_scale =  log((double)_max_dist) / ((double)_log_dist_binsize);
	_theta_scale    =  MATH_PI * 2 / ((double)_theta_binsize);
}

void SEPointShapeContext::Initialize(int max_dist, int dist_binszie, int theta_binsize)
{
	_max_dist = max_dist;
	_log_dist_binsize = dist_binszie;
	_theta_binsize = theta_binsize;
	Initialize();
}

int SEPointShapeContext::GetBinLength()
{
	return (_theta_binsize+1)*(_log_dist_binsize+1);
}

void SEPointShapeContext::CalPointBins(int* bins, int* x,int* y, int num, int center, SEMatrix<int>& dist, SEMatrix<int>& angle)
{
	int i;
	int rbin;
	int tbin;

	std::fill(bins, bins+num, 0);
	for(i=0; i<num; i++)
	{
		if(i == center)
			continue;
		rbin = dist.GetAt(center, i);
		tbin = angle.GetAt(center, i);
		if(rbin > _log_dist_binsize)
			continue;

		bins[rbin * _theta_binsize + tbin]++;
	}
}

double SEPointShapeContext::CalPointDifference( int* bins1, int* bins2, int num )
{
	double d = 0.0;
	double t;
	for (int i = 0; i < num; i++)
	{
		if(bins1[i] == bins2[i])
			continue;
		t  = (double)((bins1[i] - bins2[i])*(bins1[i] - bins2[i]));
		t /= (double)(bins1[i] + bins2[i]);
		d += t;
	}

	return d / 2.0;
}



_SE_END
