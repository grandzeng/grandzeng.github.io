#ifndef _SE_ENVIRONMENT_H_
#define _SE_ENVIRONMENT_H_

#include "global.h"
#include <string>
#include <map>

_SE_BEGIN

using namespace std;
class SEEnvironment
{
public:
	SEEnvironment(void);
public:
	virtual ~SEEnvironment(void);

public:
	void SetValue(string& key, string& val);

	void SetValue(string& key, int val);

	void SetValue(string& key, double val);
	
	string GetValue(string& key);

	int  GetIntValue(string& key);

	double GetDoubleValue(string& key);

private:
	map<string,string> _map;

};

_SE_END

#endif
