#include <string>
#include <iostream>
#include <cmath>

#include "global.h"
#include "SEWavelet.h"
#include "SEMatrix.h"
#include "SEEnvironment.h"

using namespace std;

_SE_USE;

int main(char* argv[])
{
	double test[] = {64,2,3,61,60,6,7,57};
	SEWavelet<double>::Transform(test, 8);
	int i;
	for(i=0;i<8;i++)
		cout<<test[i]<<",";

	cin>>i;
	return 0;
}
