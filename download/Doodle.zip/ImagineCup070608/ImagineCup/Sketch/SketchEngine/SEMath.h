#ifndef _SE_MATH_H_
#define _SE_MATH_H_

#include "global.h"
#include <cmath>

_SE_BEGIN

#ifndef MATH_PI
#define MATH_PI      3.14159265358979323846
#endif

#ifndef MATH_DOUBLE_MAX
#define MATH_DOUBLE_MAX (1.79769e+308)
#endif

class SEMath
{
public:

	SEMath(void)
	{
	}
public:

	~SEMath(void)
	{
	}

public:
	template <class T>
	inline static double Distance(T x1,T y1,T x2,T y2)
	{
		T dx = x2 - x1;
		T dy = y2 - y1;
		return sqrt((double)(dx*dx + dy*dy));
	}

	inline static double Angle(double x1,double y1,double x2,double y2)
	{
		double dx = x2 - x1;
		double dy = y2 - y1;
		if (dx == 0)
		{
			if (dy >= 0)
				return MATH_PI / 2;
			else
				return MATH_PI / 2 + MATH_PI;
		}
		else
		{
			double theta = atan(dy / dx);
			if (dx < 0)
				theta = MATH_PI - theta;
			if (theta < 0)
				theta = MATH_PI * 2 + theta;
			return theta;
		}
	}

};

_SE_END

#endif
