#ifndef _SE_ENGINE_H_
#define _SE_ENGINE_H_

#include "global.h"
#include "SEEnvironment.h"
#include "SEPointShapeContext.h"
#include "SEImageShapeContext.h"
#include "SEPointsMatrix.h"

_SE_BEGIN


class SEEngine
{
public:
	SEEngine(void);
public:
	virtual ~SEEngine(void);

public:
	void Initialize(void);
	void Initialize(int maxPointCount);
	void Destroy(void);

public:
	inline void CalImageShapeContext(int* x, int* y, int num)
	{
		_pointsMatrix.Create(num, _binSize, _shapeContextBuf);
		_imageShapeContext.CalPointsMatrix(x,y,num,_pointsMatrix);
	}

	inline double CalImageShapeContextDifference(SEPointsMatrix& matrix1, SEPointsMatrix& matrix2)
	{
		return _imageShapeContext.CalPointsDifference(matrix1, matrix2);
	}

public:
	inline int GetMaxCountSupport() { return _maxPointCount; };
	inline int  GetBinSize() { return _binSize; };
	inline int  GetShapeContextMaxBufferSize() { return _maxPointCount*_binSize; };
	inline int* GetShapeContextBuffer() { return _shapeContextBuf; };
	inline SEPointShapeContext& GetPointShapeContext() { return _pointShapeContext; };
	inline SEImageShapeContext& GetImageShapeContext() { return _imageShapeContext; };
	inline SEPointsMatrix& GetImageShapeContextMatrix() {  return _pointsMatrix; };

private:
	SEEnvironment       _env;
	SEPointShapeContext _pointShapeContext;
	SEImageShapeContext _imageShapeContext;
	SEPointsMatrix      _pointsMatrix;
	int                 _binSize;
	int                 _maxPointCount;
	int*                _shapeContextBuf;
	static const int    MAX_POINT_COUNT = 400*400;
};

_SE_END


#endif
