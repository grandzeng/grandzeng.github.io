#ifndef _SE_MATRIX_H_
#define _SE_MATRIX_H_

#include <cstdio>
#include "global.h"

_SE_BEGIN

template<class T>
class SEMatrix
{
public:
	SEMatrix()
	{
		_data = NULL;
	}

	SEMatrix(int w,int h)
	{
		_width  = w;
		_height = h;
		_data = new T[_width*_height];
		_newBuf = true;
	}

	SEMatrix(int w,int h, T* buf)
	{
		_width = w;
		_height = h;
		_data = buf;
		_newBuf = false;
	}

public:
	virtual ~SEMatrix(void)
	{
		if(_newBuf && _data != NULL)
			delete[] _data;
	}

public:
	inline void Create(int w,int h)
	{
		_width  = w;
		_height = h;
		_data = new T[_width*_height];
		_newBuf = true;
	}

	inline void Create(int w,int h, T* buf)
	{
		_width = w;
		_height = h;
		_data = buf;
		_newBuf = false;
	}

	inline void Destroy()
	{
		if(_newBuf && _data != NULL)
			delete[] _data;
	}

	inline bool isEmpty() { return _data == NULL; };
	inline T    GetAt(int x,int y) { return _data[y*_width + x]; };
	inline void SetAt(int x,int y, T val) { _data[y*_width + x] = val; };
	inline int  GetWidth() { return _width; };
	inline int  GetHeight() { return _height; };
	inline T*   GetRow(int y) { return _data+y*_width; };
	inline int  GetSize() { return _width*_height; };
	inline T*   GetData() { return _data; };

private:
	int  _width;
	int  _height;
	T*   _data;
	bool _newBuf;

};

_SE_END

#endif 
