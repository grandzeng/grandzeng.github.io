#include "SEImageShapeContext.h"
#include "SEPointShapeContext.h"
#include "SEMath.h"

_SE_BEGIN

SEImageShapeContext::SEImageShapeContext(void)
{
	_dummy_node =  DUMMY_NODE;
}

SEImageShapeContext::~SEImageShapeContext(void)
{
}

void SEImageShapeContext::Initialize(SEPointShapeContext* point_shapecontext)
{
	_point_shapecontext = point_shapecontext;
}

void SEImageShapeContext::CalDistMatrix( int* x,int* y,int num, SEMatrix<int>& matrix )
{
	double dist, logr;
	int bin;
	int i,j;
	for (i = 0; i < num -1; i++)
	{
		matrix.SetAt(i, j, 0);
		for (j = i + 1; j < num; j++)
		{
			dist = SEMath::Distance(x[i],y[i],x[j],y[j]);
			logr = log(dist) / log(2.0);
			bin = (int)(logr / _point_shapecontext->GetLogDistScale());
			matrix.SetAt(i, j, bin);
			matrix.SetAt(j, i, bin);
		}
	}
	matrix.SetAt(num - 1, num - 1, 0);
}

void SEImageShapeContext::CalThetaMatrix( int* x,int* y,int num, SEMatrix<int>& matrix )
{
	double angle;
	int bin;
	int i,j;
	for (i = 0; i < num - 1; i++)
	{
		matrix.SetAt(i, i, 0);
		for (j = i + 1; j < num; j++)
		{
			angle = SEMath::Angle(x[i], y[i], x[j], y[j]);
			bin = (int)(angle / _point_shapecontext->GetThetaScale());
			matrix.SetAt(i, j, bin);
			angle = SEMath::Angle(x[j], y[j], x[i], y[i]);
			bin = (int)(angle / _point_shapecontext->GetThetaScale());
			matrix.SetAt(j, i, bin);
		}
	}
	matrix.SetAt(num - 1, num - 1, 0.0);
}

void SEImageShapeContext::CalPointsMatrix( int* x,int* y,int num,SEPointsMatrix& retMatrix)
{
	SEMatrix<int> distMatrix(num,num);
	SEMatrix<int> angleMatrix(num,num);
	int  binsize;
	int  i;
	int* row;

	CalDistMatrix(x, y, num, distMatrix);
	CalThetaMatrix(x, y, num,angleMatrix);

	for(i=0;i<num;i++)
	{
		row = retMatrix.GetPointBins(i);
		_point_shapecontext->CalPointBins(row, x, y, num, i,distMatrix, angleMatrix);
	}
}

double SEImageShapeContext::CalPointsDifference( SEPointsMatrix& matrix1, SEPointsMatrix& matrix2 )
{
	/*if (image1.PointCount() > image2.PointCount())
	{
		ImageShapeContext temp = image1;
		image1 = image2;
		image2 = temp;
	}

	double difference = 0.0;
	double best, d;
	PointShapeContext p1, p2;

	for (int i = 0; i < image1.PointCount(); i++)
	{
		best = Double.MaxValue;
		p1 = image1.GetPointShapeContext(i);
		for (int j = 0; j < image2.PointCount(); j++)
		{
			p2 = image2.GetPointShapeContext(j);
			d = PointShapeContext.Difference(p1, p2) / ((double)image1.PointCount());
			if (d < best)
				best = d;
		}
		difference += best;
	}

	difference += (image2.PointCount() - image1.PointCount()) * (_DUMMY_NODE / ((double)image1.PointCount()));
	return difference;*/
	SEPointsMatrix& image1 = matrix1;
	SEPointsMatrix& image2 = matrix2;
	if(image1.GetPointsCount() > image2.GetPointsCount())
	{
		SEPointsMatrix& temp = image1;
		image1 = image2;
		image2 = temp;
	}

	double difference = 0.0;
	double best, d;
	int    i, j, num;
	int*   p1bin;
	int*   p2bin;

	num = _point_shapecontext->GetBinLength();
	for(i=0;i<image1.GetPointsCount(); i++)
	{
		best = MATH_DOUBLE_MAX;
		p1bin = image1.GetPointBins(i);
		for(j=0;j<image2.GetPointsCount();j++)
		{
			p2bin = image2.GetPointBins(j);
			d = _point_shapecontext->CalPointDifference(p1bin, p2bin, num) / ((double)image1.GetPointsCount());
			if( d < best)
				best = d;
		}
		difference += best;
	}

	difference += (image2.GetPointsCount() - image1.GetPointsCount()) * (_dummy_node  / (double)image1.GetPointsCount());
	return difference;
}

_SE_END
