#ifndef _SE_ENGINE_DLL_H_
#define _SE_ENGINE_DLL_H_

#include "global.h"

#define API_EXPORT extern "C" __declspec(dllexport)

API_EXPORT void*  CreateEngine();

API_EXPORT void   DestroyEngine(void* engine);

API_EXPORT int    CalImageShapeContext(void* engine, int* x, int* y, int num);

API_EXPORT int    GetImageShapeContextMaxBufSize(void* engine);

API_EXPORT void   GetImageShapeContext(void* engine, int* buf);

API_EXPORT double CalImageShapeContextDifference(void* engine, int* buf1,int count1, int* buf2, int count2);


#endif
