#ifndef _SE_POINTS_MATRIX_H_
#define _SE_POINTS_MATRIX_H_

#include "global.h"
#include "SEMatrix.h"

_SE_BEGIN

class SEPointsMatrix : public SEMatrix<int>
{

public:
	SEPointsMatrix()
	{
	}

	SEPointsMatrix(int count, int binsize)
		:SEMatrix<int>(binsize, count)
	{
	}

	SEPointsMatrix(int count,int binsize, int* buf)
		:SEMatrix<int>(binsize, count, buf)
	{
	}
		
	inline int* GetPointBins(int index) { return GetRow(index); };

	inline int GetPointsCount() { return GetHeight(); };

};

_SE_END

#endif
