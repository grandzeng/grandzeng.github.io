#include "SEEngineDLL.h"

#include <cstdio>

#include "global.h"
#include "SEImageShapeContext.h"
#include "SEPointShapeContext.h"
#include "SEEngine.h"
#include "SEPointsMatrix.h"

_SE_USE;

API_EXPORT void* CreateEngine()
{
	SEEngine* engine = new SEEngine();
	engine->Initialize();
	return (void*)engine;
}

API_EXPORT void DestroyEngine(void* engine)
{
	((SEEngine*)engine)->Destroy();
}

API_EXPORT int CalImageShapeContext(void* engine, int* x, int* y,int num)
{
	((SEEngine*)engine)->CalImageShapeContext(x,y,num);
	return ((SEEngine*)engine)->GetImageShapeContextMatrix().GetSize();
}

API_EXPORT int GetImageShapeContextMaxBufSize(void* engine)
{
	SEEngine* Engine = (SEEngine*)engine;
	return Engine->GetShapeContextMaxBufferSize();
}

API_EXPORT void GetImageShapeContext( void* engine, int* buf)
{
	SEEngine* Engine = (SEEngine*)engine;
	SEPointsMatrix& matrix = Engine->GetImageShapeContextMatrix();

	memcpy(buf, matrix.GetData(),  sizeof(int) * matrix.GetSize());
}

API_EXPORT double CalImageShapeContextDifference( void* engine, int* buf1,int count1, int* buf2, int count2 )
{
	SEEngine* Engine = (SEEngine*)engine;
	SEPointsMatrix matrix1(count1, Engine->GetBinSize(), buf1);
	SEPointsMatrix matrix2(count2, Engine->GetBinSize(), buf2);
	return Engine->CalImageShapeContextDifference(matrix1, matrix2);
}


