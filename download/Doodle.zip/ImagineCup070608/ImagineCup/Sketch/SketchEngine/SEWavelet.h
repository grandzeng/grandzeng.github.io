#ifndef _SE_WAVELET_H_
#define _SE_WAVELET_H_

#include "global.h"
#include <algorithm>
#include <iostream>

_SE_BEGIN

template <class T>
class SEWavelet
{
public:
	SEWavelet(void){};
public:
	~SEWavelet(void){};
public:
	
	inline static void Transform(T* data, int length)
	{
		T* temp = new T[length];
		Transform(data,temp,length);
		delete[] temp;
	}

	static void Transform(T* data, T* temp, int length);
};

template <class T>
void SEWavelet<T>::Transform( T* data, T* temp, int length )
{
	int i,len;
	T   d1,d2;

	if((length & 0x1) != 0)
		return;

	len = length;
	while(len >= 2)
	{
		len = len / 2;
		for(i=0; i<len; i++)
		{
			d1 = data[i*2];
			d2 = data[i*2+1];
			temp[i] = (d1 + d2) / 2;
			temp[i+len] = d1 - temp[i]; 
		}
		copy(temp,temp+len*2, data);
		for(i=0;i<length;i++)
			std::cout<<data[i]<<",";
		std::cout<<endl;

	}
}

_SE_END

#endif