﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Drawing.Imaging;

namespace TaZeLi.Sketch
{
    class ImagePointsConverter
    {

        public static bool ConvertToPoints(Image image,Color bgColor,int[] xs,int[] ys,ref int num, int max)
        {
            Bitmap bmp = new Bitmap(image);
            BitmapData bmpData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
            int  bgGrey = ColorToGrey(bgColor);
            int  index = 0;
            int  grey;
            bool overflow = false;
            unsafe
            {
                byte* p = (byte*)bmpData.Scan0.ToPointer();
                for (int y = 0; y < bmp.Height; y++)
                {
                    for (int x = 0; x < bmp.Width; x++)
                    {
                        grey = ColorToGrey(p[1], p[2], p[3]);
                        if(grey != bgGrey)
                        {
                            xs[index] = x;
                            ys[index] = y;
                            index++;
                            if (index > max)
                            {
                                overflow = true;
                                break;
                            }
                        }
                        p += 4;
                    }
                    p += bmpData.Stride - bmp.Width * 4;
                    if (overflow)
                        break;
                }
            }
            bmp.UnlockBits(bmpData);
            num = index;
            return overflow;
        }

        public static Image ConvertToImage(int[] xs, int[] ys, int num, int width, int height)
        {
            Bitmap bmp = new Bitmap(width, height);
            Graphics graphics = Graphics.FromImage(bmp);
            graphics.Clear(Color.White);
            graphics.Dispose();

            BitmapData bmpData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
            unsafe
            {
                byte* scan0 = (byte*)bmpData.Scan0.ToPointer();
                byte* p;
                for (int i = 0; i < num; i++)
                {
                    int x = xs[i];
                    int y = ys[i];
                    p = scan0 + bmpData.Stride * y + x * 4;
                    p[0] = 0;
                    p[1] = 0;
                    p[2] = 0;
                }
            }
            bmp.UnlockBits(bmpData);
            return bmp;
        }

        private static int ColorToGrey(byte R, byte G, byte B)
        {
            return (R + G + B) / 3;
        }

        private static int ColorToGrey(Color c)
        {
            return (c.R + c.G + c.B) / 3;
        }

    }
}
