﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Drawing;
using System.Collections;
using TaZeLi.Sketch.ShapeContext.Lib;

namespace TaZeLi.Sketch.ShapeContext
{
    public class SpatialFeatureDictionary : IEnumerable
    {

        private BucketDictionary _dict = null;

        public SpatialFeatureDictionary()
        {
        }

        public void Create(int max_feature, PointShapeContext[] points)
        {
            int feature;

            _dict = new BucketDictionary(max_feature);
            for (int i = 0; i < points.Length; i++)
            {
                feature = points[i].GetSpatialFeature();
                _dict.Add(feature, i);
            }
        }

        public ArrayList GetBuckets(int feature)
        {
            return _dict[feature];
        }

        public int GetBucketsCount()
        {
            return _dict.Count;
        }

        public void Clear()
        {
            _dict.Clear();
        }

        public void WriteStream(BinaryWriter writer)
        {
            writer.Write((Int32)_dict.Count);
            for (int i = 0; i < _dict.Count; i++)
            {
                writer.Write((Int32)_dict[i].Count);
                for(int j=0;j<_dict[i].Count;j++)
                    writer.Write((Int32)_dict[i][j]);
            }
        }

        public void ReadStream(BinaryReader reader)
        {
            int max_feature = reader.ReadInt32();
            _dict = new BucketDictionary(max_feature);
            for (int i = 0; i < _dict.Count; i++)
            {
                int count = reader.ReadInt32();
                _dict.ClearBucket(i);
                for (int j = 0; j < count; j++)
                    _dict.Add(j, reader.ReadInt32());
            }
        }

        public IEnumerator GetEnumerator()
        {
            return _dict.GetEnumerator();
        }

    }
}
