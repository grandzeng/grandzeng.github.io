﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.IO;

namespace TaZeLi.Sketch
{
    public class GenericImageRecord
    {
        private int[] _xs = null;
        private int[] _ys = null;
        private int _num = -1;
        private string _id = "";
        private int _support_width = 400;
        private int _support_height = 300;
        private Image _createdImage = null;

        public GenericImageRecord()
        {

        }

        public GenericImageRecord(string id)
        {
            _id = id;
        }

        public GenericImageRecord(string id, Image image, Color bg)
        {
            _id = id;
            Create(image, bg);
        }

        public GenericImageRecord(string id, int[] xs,int[] ys,int num)
        {
            _id = id;
            Create(xs, ys, num);
        }

        public void Create(Image image, Color bg)
        {
            int num = 0;
            _support_width  = image.Width;
            _support_height = image.Height;
            int max = _support_width * _support_height;
            int[] xs = new int[max];
            int[] ys = new int[max];
            ImagePointsConverter.ConvertToPoints(image, bg, xs, ys, ref num, max);
            Create(xs, ys, num);
        }

        public void Create(int[] xs,int[] ys,int num)
        {
            _num = num;
            _xs = new int[num];
            _ys = new int[num];
            Array.Copy(xs, _xs, num);
            Array.Copy(ys, _ys, num);
            _createdImage = null;
        }

        public int SupportWidth
        {
            get
            {
                return _support_width;
            }
            set
            {
                _support_width = value;
            }
        }

        public int SupportHeight
        {
            get
            {
                return _support_height;
            }
            set
            {
                _support_height = value;
            }
        }


        public string GetID()
        {
            return _id;
        }

        public void SetID(string id)
        {
            _id = id;
        }

        public int GetX(int index)
        {
            return _xs[index];
        }

        public int GetY(int index)
        {
            return _ys[index];
        }

        public int[] GetXArray()
        {
            return _xs;
        }

        public int[] GetYArray()
        {
            return _ys;
        }

        public Point GetPoint(int index)
        {
            return new Point(_xs[index], _ys[index]);
        }

        public int GetPointNum()
        {
            return _num;
        }

        public Image GetImage()
        {
            if(_createdImage == null)
                _createdImage = ImagePointsConverter.ConvertToImage(_xs, _ys, _num, _support_width, _support_height);
            return _createdImage;
        }

        public void WriteStream(BinaryWriter writer)
        {
            writer.Write(_id);
            WritePointsContent(writer);
        }

        public void WritePointsContent(BinaryWriter writer)
        {
            writer.Write((Int32)_num);
            for (int i = 0; i < _num; i++)
            {
                writer.Write((Int32)_xs[i]);
                writer.Write((Int32)_ys[i]);
            }
        }

        public void ReadStream(BinaryReader reader)
        {
            _id = reader.ReadString();
            ReadPointsContent(reader);
        }

        public void ReadPointsContent(BinaryReader reader)
        {
            _num = reader.ReadInt32();
            _xs = new int[_num];
            _ys = new int[_num];
            for(int i=0; i<_num; i++)
            {
                _xs[i] = reader.ReadInt32();
                _ys[i] = reader.ReadInt32();
            }
        }

        public void WriteReport(StreamWriter writer)
        {
            writer.WriteLine("ID : " + _id + " point num = "+_num);
            for(int i=0;i<_num;i++)
                writer.WriteLine(_xs[i] + "," + _ys[i]);
        }
    }
}
