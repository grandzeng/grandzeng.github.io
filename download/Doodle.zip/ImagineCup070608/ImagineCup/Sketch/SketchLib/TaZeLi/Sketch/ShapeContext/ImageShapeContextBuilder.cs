﻿using System;
using System.Collections.Generic;
using System.Text;
using TaZeLi.Sketch.ShapeContext.Lib;

namespace TaZeLi.Sketch.ShapeContext
{
    public class ImageShapeContextBuilder
    {
        private PointShapeContextBuilder _pointBuilder = null;
        private SpatialFeatureBuilder _featureBuilder = null;

        public ImageShapeContextBuilder()
        {
            _featureBuilder = new SpatialFeatureBuilder();
            _pointBuilder = new PointShapeContextBuilder(_featureBuilder);
        }

        public ImageShapeContextBuilder(PointShapeContextBuilder pointBuilder)
        {
            _pointBuilder = pointBuilder;
            _featureBuilder = pointBuilder.GetFeatureBuilder();
        }

        public ImageShapeContext BuildImageShapeContext(GenericImageRecord record)
        {
            ImageShapeContext image = new ImageShapeContext();

            DoubleMatrix distbin_matrix = CreateLogDistBinMatrix(record);
            DoubleMatrix anglebin_matrix = CreateAngleBinMatrix(record);

            PointShapeContext[] points = new PointShapeContext[record.GetPointNum()];
            for (int i = 0; i < record.GetPointNum(); i++)
            {
                points[i] = _pointBuilder.BuildPointShapeContext(record, i, distbin_matrix, anglebin_matrix);
            }

            int max_feature = _featureBuilder.GetMaxFeature();
            SpatialFeatureDictionary dict = new SpatialFeatureDictionary();
            dict.Create(max_feature, points);

            image.Create(points, dict);

            return image;
        }

        private DoubleMatrix CreateLogDistBinMatrix(GenericImageRecord record)
        {
            int count = record.GetPointNum();
            DoubleMatrix matrix = new DoubleMatrix(count, count);
            double dist, logr;
            int bin;
            double logr_scale  = _pointBuilder.GetLogRScale();
            for (int i = 0; i < count - 1; i++)
            {
                matrix.SetValue(i, i, 0.0);
                for (int j = i + 1; j < count; j++)
                {
                    dist = MathCalculation.Distance(record.GetPoint(i), record.GetPoint(j));
                    logr = Math.Log(dist, 2.0);
                    bin = (int)(logr / logr_scale);
                    matrix.SetValue(i, j, bin);
                    matrix.SetValue(j, i, bin);
                }
            }
            matrix.SetValue(count - 1, count - 1, 0.0);
            return matrix;
        }

        private DoubleMatrix CreateAngleBinMatrix(GenericImageRecord record)
        {
            int count = record.GetPointNum();
            DoubleMatrix matrix = new DoubleMatrix(count, count);
            double angle;
            int bin;
            double theta_scale = _pointBuilder.GetThetaScale();
            for (int i = 0; i < count - 1; i++)
            {
                matrix.SetValue(i, i, 0.0);
                for (int j = i + 1; j < count; j++)
                {
                    angle = MathCalculation.Angle(record.GetPoint(i), record.GetPoint(j));
                    bin = (int)(angle / theta_scale);
                    matrix.SetValue(i, j, bin);
                    angle = MathCalculation.Angle(record.GetPoint(j), record.GetPoint(i));
                    bin = (int)(angle / theta_scale);
                    matrix.SetValue(j, i, bin);
                }
            }
            matrix.SetValue(count - 1, count - 1, 0.0);

            return matrix;
        }
    }
}
