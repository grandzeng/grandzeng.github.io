﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Collections;

namespace TaZeLi.Sketch
{
    public interface IGenericImageDatabase
    {
        void Load(string path);

        void Save(string path);

        void Close();

        void Add(GenericImageRecord record);

        void RemoveAt(int index);

        void Clear();

        int Count();

        GenericImageRecord GetAt(int index);

        GenericImageRecord Query(GenericImageRecord query);

        GenericImageQueryResultSet Query(GenericImageRecord query, int top);

        void SetAttribute(string att, string val);

        void SetProperties(GenericProperties props);

        GenericProperties GetProperties();
    }
}
