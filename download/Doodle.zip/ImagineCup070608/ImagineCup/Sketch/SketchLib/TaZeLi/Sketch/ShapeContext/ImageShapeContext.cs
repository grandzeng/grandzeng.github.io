﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.IO;
using System.Collections;
using TaZeLi.Sketch.ShapeContext.Lib;

namespace TaZeLi.Sketch.ShapeContext
{
    public class ImageShapeContext
    {
        private PointShapeContext[] _point_shapecontexts = null;
        private SpatialFeatureDictionary _spatial_feature_hash = null;

        public ImageShapeContext()
        {
        }

        public void Create(PointShapeContext[] points, SpatialFeatureDictionary dict)
        {
            _point_shapecontexts = points;
            _spatial_feature_hash = dict;
        }

        public int GetPointCountOfSpatialFeature(int feature)
        {
            return _spatial_feature_hash.GetBuckets(feature).Count;
        }

        public int PointCount()
        {
            return _point_shapecontexts.Length;
        }

        public PointShapeContext GetPointShapeContext(int index)
        {
            return _point_shapecontexts[index];
        }

        public SpatialFeatureDictionary GetSpatialFeatureHash()
        {
            return _spatial_feature_hash;
        }

        public void WriteReport(StreamWriter writer)
        {
            writer.WriteLine();
            writer.WriteLine("Point Count = " + PointCount());
            for (int i = 0; i < _point_shapecontexts.Length; i++)
                _point_shapecontexts[i].WriteReport(writer);
            writer.WriteLine();
        }

        public void WriteStream(BinaryWriter writer)
        {
            writer.Write((Int32)_point_shapecontexts.Length);
            for (int i = 0; i < _point_shapecontexts.Length; i++)
                _point_shapecontexts[i].WriteStream(writer);
            _spatial_feature_hash.WriteStream(writer);
        }

        public void ReadStream(BinaryReader reader)
        {
            int count = reader.ReadInt32();
            _point_shapecontexts = new PointShapeContext[count];
            for (int i = 0; i < count; i++)
            {
                _point_shapecontexts[i] = new PointShapeContext();
                _point_shapecontexts[i].ReadStream(reader);
            }
            _spatial_feature_hash = new SpatialFeatureDictionary();
            _spatial_feature_hash.ReadStream(reader);
        }
    }
}
