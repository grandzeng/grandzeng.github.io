﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaZeLi.Sketch.ShapeContext
{
    interface IPointShapeContextCompare
    {
        double Compare(PointShapeContext p1, PointShapeContext p2);
    }
}
