﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;

namespace TaZeLi.Sketch.ShapeContext.Lib
{
    public class BucketDictionary : IEnumerable
    {
        private ArrayList[] _buckets = null;

        public BucketDictionary(int num)
        {
            _buckets = new ArrayList[num];
            for (int i = 0; i < _buckets.Length; i++)
                _buckets[i] = new ArrayList();
        }

        public void Add(int key, object value)
        {
            if (key < 0 || key >= _buckets.Length)
                throw new ArgumentNullException("key");
            _buckets[key].Add(value);
        }

        public int Count
        {
            get
            {
                return _buckets.Length;
            }
        }

        public ArrayList this[int key]
        {
            get
            {
                return _buckets[key];
            }
        }

        public void Clear()
        {
            for (int i = 0; i < _buckets.Length; i++)
                _buckets[i].Clear();
        }

        public void ClearBucket(int key)
        {
            _buckets[key].Clear();
        }

        private class BucketDictionaryEnumerator : IEnumerator
        {
            private int _bucket_index = 0;
            private int _element_index = -1;

            private BucketDictionary _dict = null;

            public BucketDictionaryEnumerator(BucketDictionary dict)
            {
                _dict = dict;
            }

            // 摘要:
            //     获取集合中的当前元素。
            //
            // 返回结果:
            //     集合中的当前元素。
            public object Current
            {
                get
                {
                    if (_bucket_index >= _dict.Count)
                        return null;
                    ArrayList bucket = _dict[_bucket_index];
                    if (_element_index >= bucket.Count)
                        return null;
                    return bucket[_element_index];
                }
            }

            // 摘要:
            //     将枚举数推进到集合的下一个元素。
            //
            // 返回结果:
            //     如果枚举数成功地推进到下一个元素，则为 true；如果枚举数越过集合的结尾，则为 false。
            public bool MoveNext()
            {
                _element_index++;
                while (_bucket_index < _dict.Count)
                {
                    ArrayList bucket = _dict[_bucket_index];
                    if (_element_index >= bucket.Count)
                    {
                        _bucket_index++;
                        _element_index = 0;
                    }
                    else
                    {
                        return true;
                    }
                }
                return false;

            }

            //
            // 摘要:
            //     将枚举数设置为其初始位置，该位置位于集合中第一个元素之前。
            public void Reset()
            {
                _bucket_index = 0;
                _element_index = -1;
            }
        }

        public IEnumerator GetEnumerator()
        {
            return new BucketDictionaryEnumerator(this);
        }

    }
}
