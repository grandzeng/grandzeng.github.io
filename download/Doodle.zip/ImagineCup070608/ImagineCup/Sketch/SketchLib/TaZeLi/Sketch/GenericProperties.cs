﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;

namespace TaZeLi.Sketch
{
    public class GenericProperties
    {
        private XmlDocument _doc = null;
        private XmlElement _root = null;
        private const string ROOT_NAME = "properties";
        private readonly char[] SPLIT_CHAR = new char[]{','};

        public GenericProperties()
        {
            _doc = new XmlDocument();
            _root = _doc.CreateElement(ROOT_NAME);
            _doc.AppendChild(_root);
        }

        public void Load(string filePath)
        {
            _doc.Load(filePath);
            _root = _doc[ROOT_NAME];
            if(_root == null)
                throw new Exception("Cannot find root element : " + ROOT_NAME);
        }

        public void Save(string filePath)
        {
            _doc.Save(filePath);
        }

        public XmlDocument PropDocument
        {
            get
            {
                return _doc;
            }
        }

        public bool ContainAttribute(string name)
        {
            XmlElement element = _root[name];
            if (element == null)
                return false;
            else
                return true;
        }

        public void ImportProperties(GenericProperties props)
        {
            string xml = props.PropDocument.InnerXml;
            _doc.LoadXml(xml);
            _root = _doc[ROOT_NAME];
            if (_root == null)
                throw new Exception("Cannot find root element : " + ROOT_NAME);
        }

        public void ImportProperties(string xml)
        {
            _doc.LoadXml(xml);
            _root = _doc[ROOT_NAME];
            if (_root == null)
                throw new Exception("Cannot find root element : " + ROOT_NAME);
        }

        public string ExportXml()
        {
            return _doc.InnerText;
        }

        public string GetAttribute(string name)
        {
            XmlElement element = _root[name];
            if (element == null)
                return null;
            else
                return element.InnerText;
        }

        public Int32 GetInt32(string name)
        {
            string strVal = GetAttribute(name);
            if (strVal == null)
                throw new Exception("Not found attribute");
            else
                return (Int32)Convert.ToInt32(strVal);
        }

        public double GetDouble(string name)
        {
            string strVal = GetAttribute(name);
            if (strVal == null)
                throw new Exception("Not found attribute");
            else
                return Convert.ToDouble(strVal);
        }

        public bool GetBoolean(string name)
        {
            string strVal = GetAttribute(name);
            if (strVal == null)
                throw new Exception("Not found attribute");
            return Convert.ToBoolean(strVal);
        }

        public string GetString(string name)
        {
            return GetAttribute(name);
        }

        public string[] GetStringArray(string name)
        {
            string strVal = GetAttribute(name);
            if(strVal == null)
                throw new Exception("Not found attribute");
            return strVal.Split(SPLIT_CHAR);
        }

        public int[] GetInt32Array(string name)
        {
            string[] strvals = GetStringArray(name);
            int[] intvals = new int[strvals.Length];
            for(int i=0;i<strvals.Length; i++)
            {
                intvals[i] = Convert.ToInt32(strvals[i]);
            }
            return intvals;
        }

        public double[] GetDoubleArray(string name)
        {
            string[] strvals = GetStringArray(name);
            double[] doublevals = new double[strvals.Length];
            for (int i = 0; i < strvals.Length; i++)
            {
                doublevals[i] = Convert.ToDouble(strvals[i]);
            }
            return doublevals;
        }

        public bool[] GetBooleanArray(string name)
        {
            string[] strvals = GetStringArray(name);
            bool[] boolvals = new bool[strvals.Length];
            for (int i = 0; i < strvals.Length; i++)
            {
                boolvals[i] = Convert.ToBoolean(strvals[i]);
            }
            return boolvals;
        }

        public void SetAttribute(string name, string val)
        {
            XmlElement element = _root[name];
            if(element == null)
            {
                XmlNode newNode = _doc.CreateElement(name);
                newNode.InnerText = val;
                _root.AppendChild(newNode);
            }
            else
            {
                element.InnerText = val;
            }
        }

        public void SetInt32(string name, Int32 val)
        {
            SetAttribute(name, "" + val);
        }

        public void SetDouble(string name, double val)
        {
            SetAttribute(name, "" + val);
        }

        public void SetBoolean(string name, bool val)
        {
            SetAttribute(name, "" + val);
        }

        public void SetString(string name, string val)
        {
            SetAttribute(name, val);
        }

        public void RemoveAttribute(string name)
        {
            XmlElement element = _root[name];
            if (element != null)
            {
                _root.RemoveChild(element);
            }
        }

    }
}
