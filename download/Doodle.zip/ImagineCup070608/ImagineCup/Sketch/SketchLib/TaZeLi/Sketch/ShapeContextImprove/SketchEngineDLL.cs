﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace TaZeLi.Sketch
{
    class SketchEngineDLL
    {
        [DllImport("SketchEngine.dll")]
        public static extern IntPtr CreateEngine();

        [DllImport("SketchEngine.dll")]
        public static extern void DestroyEngine(IntPtr engine);

        [DllImport("SketchEngine.dll")]
        public static extern int CalImageShapeContext(IntPtr engine, int[] x, int[] y, int num);

        [DllImport("SketchEngine.dll")]
        public static extern int GetImageShapeContextMaxBufSize(IntPtr engine);

        [DllImport("SketchEngine.dll")]
        public static extern void GetImageShapeContext(IntPtr engine, int[] buf);

        [DllImport("SketchEngine.dll")]
        public static extern double CalImageShapeContextDifference(IntPtr engine, int[] buf1, int count1, int[] buf2, int count2);
    }
}
