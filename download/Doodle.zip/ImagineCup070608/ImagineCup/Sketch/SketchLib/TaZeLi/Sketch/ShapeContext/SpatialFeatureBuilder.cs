﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaZeLi.Sketch.ShapeContext
{
    public class SpatialFeatureBuilder
    {
        private int _width_num_bin = 6;
        private int _height_num_bin = 1;
        private int[] _feature_level = new int[]{ 32, 80, 150};

        private int _max_level;
        private int _max_feature;
        private int _width_binsize_per_area;
        private int _height_binsize_per_area;

        private int[] _areas = null;

        public SpatialFeatureBuilder(int widthNumBin, int heightNumBin, int[] levels)
        {
            _width_num_bin = widthNumBin;
            _height_num_bin = heightNumBin;
            _feature_level = new int[levels.Length];
            Array.Copy(levels, _feature_level, levels.Length);
            Initialize();
        }

        public SpatialFeatureBuilder()
        {
            Initialize();
        }

        private void Initialize()
        {
            _max_level = _feature_level.Length + 1;
            _max_feature = (int)Math.Pow(_max_level, _width_num_bin * _height_num_bin);
            _areas = new int[_width_num_bin * _height_num_bin];
        }

        public int GetMaxFeature()
        {
            return _max_feature;
        }

        public int Calc(PointShapeContext p)
        {
            int area_x, area_y;
            int bin_x, bin_y, bin_index;

            _width_binsize_per_area = p._theta_binsize / _width_num_bin;
            _height_binsize_per_area = p._logr_binsize / _height_num_bin;

            Array.Clear(_areas, 0, _areas.Length);
            bin_index = 0;
            for (bin_y = 0; bin_y < p._logr_binsize; bin_y++)
            {
                area_y = bin_y / _height_binsize_per_area;
                for (bin_x = 0; bin_x < p._theta_binsize; bin_x++)
                {
                    area_x = bin_x / _width_binsize_per_area;
                    _areas[area_y * _width_num_bin + area_x] += p.GetBin(bin_index);
                    bin_index++;
                }
            }

            int feature = 0;
            int level = 0;
            int factor = _max_feature / _max_level;
            for (int i = 0; i < _areas.Length; i++)
            {
                //Console.WriteLine("areas[" + i + "] = " + areas[i]);
                level = CalcAreaFeatureLevel(_areas[i]);
                feature += level * factor;
                factor /= _max_level;
            }

            return feature;
        }

        private int CalcAreaFeatureLevel(int area)
        {
            for (int i = 0; i < _feature_level.Length; i++)
            {
                if (area < _feature_level[i])
                    return i;
            }
            return _feature_level.Length;
        }

    }
}
