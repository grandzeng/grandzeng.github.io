﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaZeLi.Sketch.ShapeContext.Lib
{
    public class DoubleMatrix
    {
        private double[] _array = null;
        private int _col;
        private int _row;

        public DoubleMatrix(int col, int row)
        {
            _array = new double[col * row];
            _col = col;
            _row = row;
        }

        public void SetValue(int col, int row, double value)
        {
            _array[row * _col + col] = value;
        }

        public double GetValue(int col, int row)
        {
            return _array[row * _col + col];
        }

        public int Row()
        {
            return _row;
        }

        public int Col()
        {
            return _col;
        }

    }
}
