﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace TaZeLi.Sketch.ShapeContext
{
   public  class ImageShapeContextHashCompare : IImageShapeContextCompare
    {
        private double _dummyNode = 250.0;
        private PointShapeContextCompare _pointCompare = new PointShapeContextCompare();

        public ImageShapeContextHashCompare()
        {

        }

        public double DummyNode
        {
            get
            {
                return _dummyNode;
            }
            set
            {
                _dummyNode = (double)value;
            }
        }

        public double Compare(ImageShapeContext image1, ImageShapeContext image2)
        {
            if (image1.PointCount() > image2.PointCount())
            {
                ImageShapeContext temp = image1;
                image1 = image2;
                image2 = temp;
            }

            double difference = 0.0;
            double best, d;
            PointShapeContext p1, p2;
            SpatialFeatureDictionary p2hash = image2.GetSpatialFeatureHash();
            ArrayList similarlist;

            for (int i = 0; i < image1.PointCount(); i++)
            {
                best = Double.MaxValue;
                p1 = image1.GetPointShapeContext(i);
                similarlist = p2hash.GetBuckets(p1.GetSpatialFeature());
                for (int j = 0; j < similarlist.Count; j++)
                {
                    p2 = image2.GetPointShapeContext((int)similarlist[j]);
                    d = _pointCompare.Compare(p1, p2) / ((double)image1.PointCount());
                    if (d < best)
                        best = d;
                }

                if (best == Double.MaxValue)
                    best = _dummyNode / ((double)image1.PointCount());
                difference += best;
            }

            difference += (image2.PointCount() - image1.PointCount()) * (_dummyNode / ((double)image1.PointCount()));
            return difference;
        }
    }
}
