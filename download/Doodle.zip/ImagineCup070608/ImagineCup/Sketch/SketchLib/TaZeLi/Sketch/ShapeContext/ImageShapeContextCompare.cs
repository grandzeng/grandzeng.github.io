﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaZeLi.Sketch.ShapeContext
{
    public class ImageShapeContextCompare : IImageShapeContextCompare
    {
        private double _dummyNode = 250.0;
        private PointShapeContextCompare _pointCompare = new PointShapeContextCompare();

        public ImageShapeContextCompare()
        {

        }

        public double DummyNode
        {
            get
            {
                return _dummyNode;
            }
            set
            {
                _dummyNode = (double)value;
            }
        }

        public double Compare(ImageShapeContext image1, ImageShapeContext image2)
        {
            if (image1.PointCount() > image2.PointCount())
            {
                ImageShapeContext temp = image1;
                image1 = image2;
                image2 = temp;
            }

            double difference = 0.0;
            double best, d;
            PointShapeContext p1, p2;

            for (int i = 0; i < image1.PointCount(); i++)
            {
                best = Double.MaxValue;
                p1 = image1.GetPointShapeContext(i);
                for (int j = 0; j < image2.PointCount(); j++)
                {
                    p2 = image2.GetPointShapeContext(j);
                    d = _pointCompare.Compare(p1, p2) / ((double)image1.PointCount());
                    if (d < best)
                        best = d;
                }
                difference += best;
            }

            difference += (image2.PointCount() - image1.PointCount()) * (_dummyNode / ((double)image1.PointCount()));
            return difference;
        }
    }
}
