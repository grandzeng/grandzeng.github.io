﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.IO;
using System.Collections;
using TaZeLi.Sketch;

namespace TaZeLi.Sketch.ShapeContext
{
    class SimpleImageDatabase : IGenericImageDatabase
    {
        private ArrayList _list;
        private ArrayList _shapecontext_list;
        private StreamWriter _report_writer;
        private GenericProperties _props = null;
        private const string SPATIALHASH = "spatialhash";
        private ImageShapeContextBuilder _imageShapeContextBuilder;
        private IImageShapeContextCompare _imageShapeContextCompare;

        public SimpleImageDatabase()
        {
            _list = new ArrayList();
            _shapecontext_list = new ArrayList();
            _report_writer = new StreamWriter("report.txt");
            _props = new GenericProperties();
            _imageShapeContextBuilder = new ImageShapeContextBuilder();
            _imageShapeContextCompare = new ImageShapeContextHashCompare();
        }

        public void Load(string path)
        {
            FileStream fstream = new FileStream(path, FileMode.Open);
            BinaryReader reader = new BinaryReader(fstream);
            int count = reader.ReadInt32();
            _list = new ArrayList(count);
            for (int i = 0; i < count; i++)
            {
                GenericImageRecord record = new GenericImageRecord();
                record.ReadStream(reader);
                _list.Add(record);
            }
            fstream.Close();
            ReportAllRecords();

        }

        public void Save(string path)
        {
            FileStream fstream = new FileStream(path, FileMode.Create);
            BinaryWriter writer = new BinaryWriter(fstream);
            writer.Write((Int32)_list.Count);
            for (int i = 0; i < _list.Count; i++)
                GetAt(i).WriteStream(writer);
            fstream.Close();
        }

        public void Close()
        {
            _report_writer.Close();
        }

        public void Add(GenericImageRecord record)
        {
            ImageShapeContext shapecontext = _imageShapeContextBuilder.BuildImageShapeContext(record);
            _list.Add(record);
            _shapecontext_list.Add(shapecontext);
        }

        public void RemoveAt(int index)
        {
            _report_writer.WriteLine("Remove index = " + index + " ID = " + GetAt(index).GetID());
            _list.RemoveAt(index);
            _shapecontext_list.RemoveAt(index);
        }

        public void Clear()
        {
            _list.Clear();
            _shapecontext_list.Clear();
        }

        public int Count()
        {
            return _list.Count;
        }

        public GenericImageRecord GetAt(int index)
        {
            return (GenericImageRecord)_list[index];
        }

        public void SetAttribute(string att, string val)
        {
            _props.SetAttribute(att, val);
        }

        public GenericImageRecord Query(GenericImageRecord record)
        {
            GenericImageQueryResultSet rets = Query(record, 1);
            if (rets == null || rets.Count() == 0)
                return null;
            else
                return rets.GetRecord(0);
        }

        public GenericImageQueryResultSet Query(GenericImageRecord record, int top)
        {
            DateTime starttime = DateTime.Now;
            GenericImageRecord[] top_rets = new GenericImageRecord[top];
            double[] top_scores = new double[top];
            double difference;
            int insertindex;
            int i, j;
            bool useHash = true;

            if (_props.ContainAttribute(SPATIALHASH))
                useHash = _props.GetBoolean(SPATIALHASH);
            if (useHash)
                _imageShapeContextCompare = new ImageShapeContextHashCompare();
            else
                _imageShapeContextCompare = new ImageShapeContextCompare();

            for (i = 0; i < top; i++)
            {
                top_rets[i] = null;
                top_scores[i] = Double.MaxValue;
            }

            ImageShapeContext shapecontext1;
            ImageShapeContext shapecontext2;

            shapecontext1 = _imageShapeContextBuilder.BuildImageShapeContext(record);

            for (i = 0; i < _list.Count; i++)
            {
                shapecontext2 = (ImageShapeContext)_shapecontext_list[i];
                // 比较两张图片的差异度
                difference = _imageShapeContextCompare.Compare(shapecontext1, shapecontext2);
                // 查找应该插入的top数组空位索引
                insertindex = -1;
                for (j = top - 1; j >= 0; j--)
                {
                    if (difference >= top_scores[j])
                        break;
                    insertindex = j;
                }
                if (insertindex >= 0)
                {
                    // 插入top数组
                    for (j = top - 1; j >= insertindex + 1; j--)
                    {
                        top_scores[j] = top_scores[j - 1];
                        top_rets[j] = top_rets[j - 1];
                    }
                    // 插入新的对象
                    top_scores[insertindex] = difference;
                    top_rets[insertindex] = GetAt(i);
                }
            }

            GenericImageQueryResultSet results = new GenericImageQueryResultSet();
            for (i = 0; i < top_rets.Length; i++)
            {
                if (top_rets[i] == null)
                    break;
                results.Add(top_rets[i], top_scores[i]);
            }

            DateTime endtime = DateTime.Now;
            TimeSpan span = endtime.Subtract(starttime);
            double time = span.TotalMilliseconds;
            _report_writer.WriteLine("Execute Querying : Query Image point count = " + record.GetPointNum());
            _report_writer.WriteLine("Execute Querying time = " + time + " ms");
            _report_writer.WriteLine();
            return results;
        }

        public void SetUseSpatialHash(bool use)
        {
            _props.SetBoolean(SPATIALHASH, use);
            if (use)
                _report_writer.WriteLine("Change Spatial Hash : USE!");
            else
                _report_writer.WriteLine("Change Spatial Hash : NOT USE!");
            _report_writer.WriteLine();
        }

        private void ReportAllRecords()
        {
            _report_writer.WriteLine("Imagedatabase : count = " + _list.Count);
            for (int i = 0; i < _list.Count; i++)
                ((GenericImageRecord)_list[i]).WriteReport(_report_writer);
        }

        public void SetProperties(GenericProperties props)
        {
            _props.ImportProperties(props);
        }

        public GenericProperties GetProperties()
        {
            return _props;
        }
        
    }
}
