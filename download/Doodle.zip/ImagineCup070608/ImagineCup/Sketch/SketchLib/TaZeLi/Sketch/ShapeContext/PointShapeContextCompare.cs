﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaZeLi.Sketch.ShapeContext
{
    class PointShapeContextCompare : IPointShapeContextCompare
    {
        public PointShapeContextCompare()
        {

        }

        public double Compare(PointShapeContext p1, PointShapeContext p2)
        {
            double d = 0.0;
            double t;
            int binsize = p1.GetBinSize();
            for (int i = 0; i < binsize; i++)
            {
                if (p1.GetBin(i) == p2.GetBin(i))
                    continue;
                t = (double)(p1.GetBin(i) - p2.GetBin(i));
                t *= t;
                t /= (double)(p1.GetBin(i) + p2.GetBin(i));
                d += t;
            }

            return d / 2.0;
        }
    }
}
