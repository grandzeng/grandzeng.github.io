﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.IO;
using TaZeLi.Sketch;
using TaZeLi.Sketch.ShapeContext.Lib;

namespace TaZeLi.Sketch.ShapeContext
{
    public class PointShapeContext
    {
        public int[] _bins;
        public Point _center;
        public int _spatial_feature;
        public int _max_dist;
        public int _logr_binsize;
        public int _theta_binsize;

        
        public Point GetCenter()
        {
            return _center;
        }

        public int GetBinSize()
        {
            if (_bins == null)
                return 0;
            else
                return _bins.Length;
        }

        public int GetBin(int index)
        {
            return _bins[index];
        }

        public int GetSpatialFeature()
        {
            return _spatial_feature;
        }

        public void WriteReport(StreamWriter writer)
        {
            writer.WriteLine();
            writer.WriteLine("Max R = " + _max_dist + " LogR Bin Size = " + _logr_binsize + " Theta Bin Size = " + _theta_binsize);
            writer.WriteLine("Center Point = (" + _center.X + ", " + _center.Y + ")");
            for (int i = 0; i < _logr_binsize; i++)
            {
                for (int j = 0; j < _theta_binsize; j++)
                    writer.Write(" " + _bins[i * _theta_binsize + j]);
                writer.WriteLine();
            }
            writer.WriteLine("Spatial Feature = " + _spatial_feature);
            writer.WriteLine();
        }

        public void WriteStream(BinaryWriter writer)
        {
            writer.Write((Int32)_center.X);
            writer.Write((Int32)_center.Y);
   
            writer.Write((Int32)_logr_binsize);
            writer.Write((Int32)_theta_binsize);
            writer.Write((Int32)_bins.Length);
            for(int i=0;i<_bins.Length;i++)
                writer.Write((Int32)_bins[i]);
            writer.Write((Int32)_spatial_feature);
        }

        public void ReadStream(BinaryReader reader)
        {
            _center.X = reader.ReadInt32();
            _center.Y = reader.ReadInt32();
          
            _logr_binsize = reader.ReadInt32();
            _theta_binsize = reader.ReadInt32();
            int len = reader.ReadInt32();
            //_bins = new int[(_logr_binsize + 1) * (_theta_binsize + 1)];
            _bins = new int[len];
            for (int i = 0; i < _bins.Length; i++)
                _bins[i] = reader.ReadInt32();

            _spatial_feature = reader.ReadInt32();
        }


    }
}
