﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Drawing;

namespace TaZeLi.Sketch.ShapeContext
{
    class CommandProcessor
    {
        private static readonly int _version = 20070104;
        private static readonly string _CMD_VERISON = "version";
        private static readonly string _CMD_CREATE = "create";
        private static readonly string _CMD_LOAD = "load";
        private static readonly string _CMD_EXIT = "exit";
        private static readonly string _CMD_SAVE = "save";
        private static readonly string _CMD_ADD = "add";
        private static readonly string _CMD_QUERY = "query";
        private static readonly string _CMD_LIST = "list";
        private static readonly string _CMD_REMOVE = "remove";

        private enum _ERRORCODE
        {
            NOT_ENOUGH_ARGUMENT,
            FILE_NOT_FOUND,
        };

        private SimpleImageDatabase _db = null;
        private string _db_path = null;

        public CommandProcessor()
        {
            _db = new SimpleImageDatabase();
        }

        public void Run()
        {
            string cmd;
            bool bContinue = true;
            while (bContinue)
            {
                Console.Write("TaZeLi: ");
                cmd = Console.ReadLine();
                bContinue = ProcessCommand(cmd);
            }
        }

        private bool ProcessCommand(string cmd)
        {
            string[] args = cmd.Split(new char[]{' '});            
            if(args == null || args.Length == 0)
                return false;

            if (args[0].Equals(_CMD_VERISON))
                return Cmd_Version(args);
            else if (args[0].Equals(_CMD_CREATE))
                return Cmd_Create(args);
            else if (args[0].Equals(_CMD_LOAD))
                return Cmd_Load(args);
            else if (args[0].Equals(_CMD_EXIT))
                return Cmd_Exit(args);
            else if (args[0].Equals(_CMD_SAVE))
                return Cmd_Save(args);
            else if (args[0].Equals(_CMD_ADD))
                return Cmd_Add(args);
            else if (args[0].Equals(_CMD_QUERY))
                return Cmd_Query(args);
            else if (args[0].Equals(_CMD_LIST))
                return Cmd_List(args);
            else if (args[0].Equals(_CMD_REMOVE))
                return Cmd_Remove(args);

            return true;
        }

        private bool Cmd_Version(string[] args)
        {
            Prompt("ImageDatabase Commands Program : " + _version);
            return true;
        }

        private bool Cmd_Create(string[] args)
        {
            _db = new SimpleImageDatabase();
            Prompt("Create OK!");
            return true;
        }

        private bool Cmd_Load(string[] args)
        {
            if (args.Length == 1 && _db_path == null)
            {
                ErrorPrompt(_ERRORCODE.NOT_ENOUGH_ARGUMENT);
                return true;
            }

            if(args.Length > 1)
                _db_path = args[1];
            _db = new SimpleImageDatabase();
            try
            {
                _db.Load(_db_path);
            }
            catch (FileNotFoundException)
            {
                ErrorPrompt(_ERRORCODE.FILE_NOT_FOUND);
                return true;
            }

            Prompt("Load image database (size = " + _db.Count() + ") OK!");
            return true;
        }

        private bool Cmd_Save(string[] args)
        {
            if (args.Length == 1 && _db_path == null)
            {
                ErrorPrompt(_ERRORCODE.NOT_ENOUGH_ARGUMENT);
                return true;
            }

            if (args.Length > 1)
                _db_path = args[1];
            _db.Save(_db_path);
            Prompt("Save to file : " + _db_path + " OK!");
            return true;
        }

        private bool Cmd_Exit(string[] args)
        {
            return false;
        }

        private bool Cmd_Add(string[] args)
        {
            if (args.Length < 2)
            {
                ErrorPrompt(_ERRORCODE.NOT_ENOUGH_ARGUMENT);
                return true;
            }

            GenericImageRecord record = new GenericImageRecord();
            Image image = Image.FromFile(args[1]);
            record.Create(image, Color.White);
            _db.Add(record);
            Prompt("Image : " + args[1] + " added OK!");
            return true;
        }

        private bool Cmd_Query(string[] args)
        {
            if (args.Length < 2)
            {
                ErrorPrompt(_ERRORCODE.NOT_ENOUGH_ARGUMENT);
                return true;
            }

            string ret_path = "result.bmp";
            if (args.Length >= 3)
                ret_path = args[2];
            
            GenericImageRecord queryRecord = new GenericImageRecord();
            Image queryImage = Image.FromFile(args[1]);
            queryRecord.Create(queryImage, Color.White);
            
            GenericImageRecord retRecord = _db.Query(queryRecord);
            Image retImage = retRecord.GetImage();
            retImage.Save(ret_path);
            Prompt("Result image ID = "+retRecord.GetID());
            Prompt("Save result image to file : " + ret_path);
            return true;
        }

        private bool Cmd_List(string[] args)
        {
            Prompt("Image record count = " + _db.Count());
            for (int i = 0; i < _db.Count(); i++)
            {
                string imageid = _db.GetAt(i).GetID();
                Prompt("image record ID = " + imageid+",   index = "+i);
            }
            return true;
        }

        private bool Cmd_Remove(string[] args)
        {
            if (args.Length < 2)
            {
                ErrorPrompt(_ERRORCODE.NOT_ENOUGH_ARGUMENT);
                return true;
            }

            for (int i = 0; i < _db.Count(); i++)
            {
                if (args[1].Equals(_db.GetAt(i).GetID()))
                {
                    _db.RemoveAt(i);
                    break;
                }
            }
            Prompt("Image record ID = " + args[1] + " was removed OK!");
            return true;
        }

        private void ErrorPrompt(_ERRORCODE error)
        {
            switch (error)
            {
                case _ERRORCODE.NOT_ENOUGH_ARGUMENT:
                    Console.WriteLine("Not enough arguments");
                    break;
                case _ERRORCODE.FILE_NOT_FOUND:
                    Console.WriteLine("File not found!");
                    break;
            }
        }

        private void Prompt(string msg)
        {
            Console.WriteLine(msg);
        }

    }
}
