﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace TaZeLi.Sketch.ShapeContext.Lib
{
    class MathCalculation
    {
        /// <summary>
        /// 求平面上两个点之间的笛卡尔距离
        /// </summary>
        /// <param name="p1"></param>
        /// <param name="p2"></param>
        /// <returns></returns>
        public static double Distance(PointF p1, PointF p2)
        {
            return Math.Sqrt((p2.X - p1.X) * (p2.X - p1.X) + (p2.Y - p1.Y) * (p2.Y - p1.Y));
        }

        /// <summary>
        /// 求平面上两个点之间的笛卡尔距离
        /// </summary>
        /// <param name="p1"></param>
        /// <param name="p2"></param>
        /// <returns></returns>
        public static double Distance(Point p1, Point p2)
        {
            return Math.Sqrt((double)((p2.X - p1.X) * (p2.X - p1.X) + (p2.Y - p1.Y) * (p2.Y - p1.Y)));
        }

        /// <summary>
        /// 计算P1到P2向量的夹角,[0,2*PI)
        /// </summary>
        /// <param name="p1"></param>
        /// <param name="p2"></param>
        /// <returns></returns>
        public static double Angle(Point p1, Point p2)
        {
            double dx = p2.X - p1.X;
            double dy = p2.Y - p1.Y;
            if (dx == 0)
            {
                if (dy >= 0)
                    return Math.PI / 2;
                else
                    return Math.PI / 2 + Math.PI;
            }
            else
            {
                double theta = Math.Atan(dy / dx);
                if (dx < 0)
                    theta = Math.PI - theta;
                if (theta < 0)
                    theta = Math.PI * 2 + theta;
                return theta;
            }
        }


        /// <summary>
        /// 计算P1到P2向量的夹角,[0,2*PI)
        /// </summary>
        /// <param name="p1"></param>
        /// <param name="p2"></param>
        /// <returns></returns>
        public static double Angle(PointF p1, PointF p2)
        {
            double dx = p2.X - p1.X;
            double dy = p2.Y - p1.Y;
            if (dx == 0)
            {
                if (dy >= 0)
                    return Math.PI / 2;
                else
                    return Math.PI / 2 + Math.PI;
            }
            else
            {
                double theta = Math.Atan(dy / dx);
                if (dx < 0)
                    theta = Math.PI - theta;
                if (theta < 0)
                    theta = Math.PI * 2 + theta;
                return theta;
            }
        }

        public static double AngleMiniDistance(double a1, double a2)
        {
            double d = Math.Abs(a2 - a1);
            if (d > Math.PI)
                return Math.PI * 2 - d;
            else
                return d;
        }

    }
}
