﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Collections;
using TaZeLi.Sketch;

namespace TaZeLi.Sketch.ShapeContextImprove
{
    public class SketchEngineDatabase : IGenericImageDatabase
    {
        private IntPtr _engine = IntPtr.Zero;
        private ArrayList _recordList = null;
        private ArrayList _shapeContextList = null;
        private GenericProperties _props = null;

        public SketchEngineDatabase()
        {
            _engine = SketchEngineDLL.CreateEngine();
            _props = new GenericProperties();
        }

        ~SketchEngineDatabase()
        {
            SketchEngineDLL.DestroyEngine(_engine);
        }

        public void Load(string path)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public void Save(string path) 
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public void Close()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public void Add(GenericImageRecord record)
        {
            int bufSize = SketchEngineDLL.CalImageShapeContext(_engine, record.GetXArray(), record.GetYArray(), record.GetPointNum());
            Int32[] shapeContextBuf = new Int32[bufSize];
            SketchEngineDLL.GetImageShapeContext(_engine, shapeContextBuf);
            _recordList.Add(record);
            _shapeContextList.Add(shapeContextBuf);
        }

        public void RemoveAt(int index)
        {
            _recordList.RemoveAt(index);
            _shapeContextList.RemoveAt(index);
        }

        public void Clear()
        {
            _recordList.Clear();
            _shapeContextList.Clear();
        }

        public int Count()
        {
            return _recordList.Count;
        }

        public GenericImageRecord GetAt(int index)
        {
            return _recordList[index] as GenericImageRecord;
        }

        public GenericImageRecord Query(GenericImageRecord query)
        {
            GenericImageQueryResultSet rets = Query(query, 1);
            if (rets == null || rets.Count() == 0)
                return null;
            else
                return rets.GetRecord(0);
        }

        public GenericImageQueryResultSet Query(GenericImageRecord query, int top)
        {
            DateTime starttime = DateTime.Now;
            GenericImageRecord[] top_rets = new GenericImageRecord[top];
            double[] top_scores = new double[top];
            double difference;
            int insertindex;
            int i, j;
            int bufSize = 0;
            int count1,count2;

            for (i = 0; i < top; i++)
            {
                top_rets[i] = null;
                top_scores[i] = Double.MaxValue;
            }

            Int32[] shapecontext1 = null;
            Int32[] shapecontext2 = null;
            
            count1 = query.GetPointNum();
            bufSize = SketchEngineDLL.CalImageShapeContext(_engine, query.GetXArray(), query.GetYArray(), count1);
            shapecontext1 = new Int32[bufSize];
            SketchEngineDLL.GetImageShapeContext(_engine, shapecontext1);

            for (i = 0; i < _recordList.Count; i++)
            {
                shapecontext2 = (Int32[])_shapeContextList[i];
                count2 = GetAt(i).GetPointNum();
                // 比较两张图片的差异度
                difference = SketchEngineDLL.CalImageShapeContextDifference(_engine, shapecontext1, count1, shapecontext2, count2);
                // 查找应该插入的top数组空位索引
                insertindex = -1;
                for (j = top - 1; j >= 0; j--)
                {
                    if (difference >= top_scores[j])
                        break;
                    insertindex = j;
                }
                if (insertindex >= 0)
                {
                    // 插入top数组
                    for (j = top - 1; j >= insertindex + 1; j--)
                    {
                        top_scores[j] = top_scores[j - 1];
                        top_rets[j] = top_rets[j - 1];
                    }
                    // 插入新的对象
                    top_scores[insertindex] = difference;
                    top_rets[insertindex] = GetAt(i);
                }
            }

            GenericImageQueryResultSet results = new GenericImageQueryResultSet();
            for (i = 0; i < top_rets.Length; i++)
            {
                if (top_rets[i] == null)
                    break;
                results.Add(top_rets[i], top_scores[i]);
            }

            DateTime endtime = DateTime.Now;
            TimeSpan span = endtime.Subtract(starttime);
            double time = span.TotalMilliseconds;
            return results;
        }

        public void SetAttribute(string att, string val)
        {
        }

        public void SetProperties(GenericProperties props)
        {
            _props.ImportProperties(props);
        }

        public GenericProperties GetProperties()
        {
            return _props;
        }

    }
}
