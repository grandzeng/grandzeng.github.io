﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Drawing.Imaging;

namespace TaZeLi.Sketch.ShapeContext.Lib
{
    class GreyMatrix
    {
        private int[] _matrix = null; 
        private int _width;
        private int _height;

        public GreyMatrix(Image image)
        {
            Create(image);
        }

        private void Create(Image image)
        {
            Bitmap bmp = new Bitmap(image);
            BitmapData bmpData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);

            _matrix = new int[bmp.Width * bmp.Height];
            _width = bmp.Width;
            _height = bmp.Height;

            unsafe
            {
                byte* p = (byte*)bmpData.Scan0.ToPointer();
                for (int y = 0; y < bmp.Height; y++)
                {
                    for (int x = 0; x < bmp.Width; x++)
                    {
                        _matrix[y * _width + x] = ColorToGrey(p[1],p[2],p[3]);
                        p += 4;
                    }
                    p += bmpData.Stride - bmp.Width * 4;
                }
            }

            bmp.UnlockBits(bmpData);
        }


        public int GetWidth()
        {
            return _width;
        }

        public int GetHeight()
        {
            return _height;
        }

        public int GetPixel(int x, int y)
        {
            return _matrix[y * _width + x];
        }

        public void SetPixel(int x, int y,int grey)
        {
            _matrix[y * _width + x] = grey;
        }

        public static int ColorToGrey(byte R,byte G,byte B)
        {
            return (R + G + B) / 3;
        }

        public static int ColorToGrey(Color c)
        {
            return (c.R + c.G + c.B) / 3;
        }
    }
}
