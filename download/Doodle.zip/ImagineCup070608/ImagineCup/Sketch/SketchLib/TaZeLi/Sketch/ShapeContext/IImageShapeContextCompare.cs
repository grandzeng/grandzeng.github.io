﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaZeLi.Sketch.ShapeContext
{
    public interface IImageShapeContextCompare
    {
        double Compare(ImageShapeContext image1, ImageShapeContext image2);
    }
}
