﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.IO;
using System.Text;

namespace TaZeLi.Sketch.ShapeContext.Lib
{
    public class HistogramTree
    {
        private int _levelCount;
        private int _areaCount;
        private int _numBinPerNode = 0;
        private HistogramTreeNode _root = null;

        public HistogramTree(int levelCount, int areaCount)
        {
            _levelCount = levelCount;
            _areaCount = areaCount;

            _numBinPerNode = 1;
            for (int i = 0; i < _areaCount; i++)
                _numBinPerNode *= _levelCount;
        }

        public int LevelCount
        {
            get
            {
                return _levelCount;
            }
        }

        public int AreaCount
        {
            get
            {
                return _areaCount;
            }
        }

        private void CreateRoot()
        {
            _root = new HistogramTreeNode(_numBinPerNode);
        }

        private class HistogramTreeNode
        {
            private HistogramTreeNode[] _children = null;
            private int _numBin;
            private object _value;

            public HistogramTreeNode(int numBin)
            {
                _numBin = numBin;
                _children = new HistogramTreeNode[numBin];
            }

            public HistogramTreeNode Search(int[] key)
            {
                return null;
            }

            public HistogramTreeNode[] Children
            {
                get
                {
                    return _children;
                }
            }

            public object Value
            {
                get
                {
                    return _value;
                }

                set
                {
                    _value = value;
                }
            }

            public void SetChild(int index, HistogramTreeNode child)
            {
                _children[index] = child;
            }

            public HistogramTreeNode GetChild(int index)
            {
                return _children[index];
            }

            public int GetChildrenCount()
            {
                return _children.Length;
            }

        }



    }
}
