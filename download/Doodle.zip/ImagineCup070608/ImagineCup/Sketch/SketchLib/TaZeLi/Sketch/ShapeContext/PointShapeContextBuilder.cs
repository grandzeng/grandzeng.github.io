﻿using System;
using System.Collections.Generic;
using System.Text;
using TaZeLi.Sketch.ShapeContext.Lib;

namespace TaZeLi.Sketch.ShapeContext
{
   public class PointShapeContextBuilder
    {
        private double _max_dist = 128.0;
        private int _logr_binsize = 6;
        private int _theta_binsize = 12;

        private double _logr_scale;
        private double _theta_scale;

        private SpatialFeatureBuilder _featureBuilder = null;

        public PointShapeContextBuilder(double maxDist, int distBinSize, int thetaBinSize, SpatialFeatureBuilder builder)
        {
            _max_dist = maxDist;
            _logr_binsize = distBinSize;
            _logr_scale = Math.Log(_max_dist, 2.0) / ((double)_logr_binsize);
            _theta_binsize = thetaBinSize;
            _theta_scale = Math.PI * 2 / ((double)_theta_binsize);
            Initialize(builder);
        }

        public PointShapeContextBuilder(SpatialFeatureBuilder builder)
        {
            Initialize(builder);
        }

        private void Initialize(SpatialFeatureBuilder builder)
        {
            _logr_scale = Math.Log(_max_dist, 2.0) / ((double)_logr_binsize);
            _theta_scale = Math.PI * 2 / ((double)_theta_binsize);
            _featureBuilder = builder;
        }

        public int GetLogRBinSize() 
        {
            return _logr_binsize;
        }

        public int GetThetaBinSize()
        {
            return _theta_binsize;
        }

        public double GetLogRScale()
        {
            return _logr_scale;
        }

        public double GetThetaScale()
        {
            return _theta_scale;
        }

        public SpatialFeatureBuilder GetFeatureBuilder()
        {
            return _featureBuilder;
        }

        public PointShapeContext BuildPointShapeContext(GenericImageRecord record, int index, DoubleMatrix dist, DoubleMatrix angle)
        {
            PointShapeContext point = new PointShapeContext();
            int binsize = (_logr_binsize + 1) * (_theta_binsize + 1);
            int rbin, thetabin;

            point._logr_binsize = _logr_binsize;
            point._theta_binsize = _theta_binsize;
            point._max_dist = (int)_max_dist;
            point._bins = new int[binsize];

            for (int i = 0; i < binsize; i++)
                point._bins[i] = 0;

            point._center = record.GetPoint(index);
            for (int i = 0; i < record.GetPointNum(); i++)
            {
                if (i == index)
                    continue;

                rbin = (int)dist.GetValue(index, i);
                thetabin = (int)angle.GetValue(index, i);
                if (rbin > _logr_binsize)
                    continue;

                point._bins[rbin * _theta_binsize + thetabin]++;
            }

            point._spatial_feature = _featureBuilder.Calc(point);
            return point;
        }

    }
}
