﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaZeLi.Sketch.Lib
{
    class Histogram<T>
    {
        private T[] _key = null;
        
        public Histogram(T[] key)
        {
            _key = new T[key.Length];
            Array.Copy(key, _key, key.Length);
        }

        public T[] Key
        {
            get
            {
                return _key;
            }
        }

        public T GetKeyAt(int index)
        {
            return _key[index];
        }

        public int GetKeyCount()
        {
            return _key.Length;
        }


    }
}
