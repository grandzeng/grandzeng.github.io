﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Collections;

namespace TaZeLi.Sketch.ShapeContext
{
    class ImageSpatialFeatureTree
    {

        public ImageSpatialFeatureTree(int num_lv, int num_area)
        {
        }

        public void Insert(ImageShapeContext image)
        {

        }

        public void Remove(ImageShapeContext image)
        {

        }


    }
}
