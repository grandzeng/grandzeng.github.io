﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Drawing;

namespace TaZeLi.Sketch
{
    public class GenericImageQueryResultSet
    {
        private ArrayList _record_list;
        private ArrayList _difference_list;

        public GenericImageQueryResultSet()
        {
            _record_list = new ArrayList();
            _difference_list = new ArrayList();
        }

        public void Add(GenericImageRecord record, double difference)
        {
            _record_list.Add(record);
            _difference_list.Add(difference);
        }

        public GenericImageRecord GetRecord(int index)
        {
            return (GenericImageRecord)_record_list[index];
        }

        public double GetDifference(int index)
        {
            return (double)_difference_list[index];
        }

        public int Count()
        {
            return _record_list.Count;
        }

    }
}
