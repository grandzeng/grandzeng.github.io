﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Collections;

namespace TaZeLi.Sketch
{
    public class GenericImageDatabaseFactory
    {
        public static IGenericImageDatabase CreateShapeContextDB()
        {
            return new TaZeLi.Sketch.ShapeContext.SimpleImageDatabase();
        }

        public static IGenericImageDatabase CreateImprovedShapeContextDB()
        {
            return new TaZeLi.Sketch.ShapeContextImprove.SketchEngineDatabase();
        }
    }
}
