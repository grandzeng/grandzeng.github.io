using System;
using System.Collections.Generic;
using System.Text;

namespace SketchDatabase.Core
{
   public class DoodleFeature
    {
        //_id-->doodleID
        private int _id;

        private byte[] _feature;

        public DoodleFeature(){}

        public DoodleFeature(int id, byte[] feature)
        {
            _id = id;
            _feature = feature;
        }

        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }

        public byte[] Feature
        {
            get { return _feature; }
            set { _feature = value; }
        }

        public byte this[int index]
        {
            get 
            {
               
                return _feature[index];
            }
            set 
            {
                if (_feature == null)
                    return;
                if (index < 0 || index >= _feature.Length)
                    return ;
                _feature[index] = value;
            }
        }
    }
}
