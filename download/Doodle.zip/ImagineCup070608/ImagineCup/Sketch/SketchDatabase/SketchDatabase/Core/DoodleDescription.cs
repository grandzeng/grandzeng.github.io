using System;
using System.Collections.Generic;
using System.Text;

namespace SketchDatabase.Core
{
    public class DoodleDescription
    {
        //_id-->doodleID
        private int _id;
        //
        private string _text;

        public DoodleDescription() { }

        public DoodleDescription(int id, string text)
        {
            _id = id;
            _text = text;
        }

        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }

        public string Text
        {
            get { return _text; }
            set { _text = value; }
        }
    }
}
