using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace SketchDatabase.Core
{
   public class Doodle
    {
        //doodleID
        private int _id=0;

        private string _title="";

        private int _userid;

       private string _userName = "";

        private byte[] _content;

        private int _reply=0;

        private DateTime _publication;

       private DoodleDescription _description;

        public Doodle() { }

        public Doodle(string title, int userid, byte[] content, int reply)
        {
            _title = title;
            _userid = userid;
            _content = content;
            _reply = reply;
        }
        public Doodle(int id,string title,int userid,byte[] content,int reply,DateTime publication)
        {
            _id = id;
            _title = title;
            _userid = userid;
            _reply = reply;
            _content = content;
            _publication = publication;
        }

        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }

        public int UserID
        {
            get { return _userid; }
            set { _userid = value; }
        }

       public string UserName
       {
            get{return _userName;}
           set{_userName=value;}
       }
        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }

        public int Reply
        {
            get { return _reply; }
            set { _reply = value; }
        }

        public DateTime Publication
        {
            get { return _publication; }
            set { _publication = value; }
        }

        public byte[] Content
        {
            get { return _content; }
            set { _content = value; }
        }

        public byte this[int index]
        {
            get 
            {
                return _content[index]; 
            }
            set 
            {
                if (_content == null)
                    return;
                if (index < 0 || index >= _content.Length)
                    return;
                _content[index] = value;
            }
        }
       public DoodleDescription Description
       {
           get { return _description; }
           set { _description = value; }
       }
    }
}
