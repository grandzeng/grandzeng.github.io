using System;
using System.Collections.Generic;
using System.Text;

namespace SketchDatabase.Core
{
   public  class IDScore
    {
        private Int32 _id;
        private double _score;

        public IDScore() { }

        public IDScore(Int32 id, double score)
        {
            _id = id;
            _score = score;
        }

        public Int32 _ID
        {
            get { return _id; }
            set { _id = value; }
        }
        public double _Score
        {
            get { return _score; }
            set { _score = value; }
        }
    }
}
