using System;
using System.Collections.Generic;
using System.Text;

namespace SketchDatabase.Core
{
    public class User
    {
        //userID
        private int _id;

        private string _name="";

        private string _password="";

        private string _qq="";

        private string _email="";

        private string _homepage="";

        private string _sex = "male";

        public User() { }

        public User(int id,string name,string password,string qq,string email,string homepage)
        {
            _id = id;
            _name = name;
            _password = password;
            _qq = qq;
            _email = email;
            _homepage = homepage;
        }

        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string Password
        {
            get { return _password; }
            set { _password=value; }
        }

        public string QQ
        {
            get { return _qq; }
            set { _qq = value; }
        }

        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }

        public string Homepage
        {
            get { return _homepage; }
            set { _homepage = value; }
        }
        public string Sex
        {
            get { return _sex; }
            set { _sex = value; }
        }
    }
}
