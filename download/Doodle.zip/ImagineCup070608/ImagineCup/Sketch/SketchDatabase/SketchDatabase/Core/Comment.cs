using System;
using System.Collections.Generic;
using System.Text;

namespace SketchDatabase.Core
{
    public class Comment:IComparable<Comment>
    {
        //commentID
        private int _id;
        //title for each comment
        private string _title="";
        //content for comment
        private string _text="";

        private DateTime _commentTime;

        private string _username;

        private int _doodleID;

        public Comment() { }

        public Comment(int id,int doodleID,string title,string text,DateTime commentTime,string username) 
        {
            _id = id;
            _doodleID = doodleID;
            _title = title;
            _text = text;
            _commentTime = commentTime;
            _username = username;
        }

        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }

        public int DoodleID
        {
            get { return _doodleID; }
            set { _doodleID = value; }
        }
        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }
        public string Text
        {
            get { return _text; }
            set { _text = value; }
        }
        public DateTime CommentTime
        {
            get { return _commentTime; }
            set { _commentTime = value; }
        }
        public string UserName
        {
            get { return _username; }
            set { _username = value; }
        }

        public int CompareTo(Comment com)
        {
            return this._id.CompareTo(com._id);
        }
        public bool Equals(Comment com)
        {
            return this._id.Equals(com._id);
        }
    }
}
