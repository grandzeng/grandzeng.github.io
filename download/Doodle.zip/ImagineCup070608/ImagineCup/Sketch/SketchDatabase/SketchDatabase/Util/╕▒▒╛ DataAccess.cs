using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using SketchDatabase.Core;
using TaZeLi.Sketch;
using TaZeLi.Sketch.ShapeContext;
using TaZeLi.Sketch.ShapeContextImprove;
using TaZeLi.Sketch.ShapeContext.Lib;
using System.IO;
namespace SketchDatabase.Util
{
   public class DataAccess
    {
        private ImageShapeContextBuilder _imageShapeContextBuilder=new ImageShapeContextBuilder();
        private IImageShapeContextCompare _imageShapeContextCompare=new ImageShapeContextHashCompare();
        private List<Int32> _IDlist = new List<Int32>();
        private List<double> _difference = new List<double>();

       public DataAccess()
       { 
            
       }

        public bool IsUserExists(User user)
        {
            string query = "select * from doodleuser where userName=@userName";
            bool value=false;
            try
            {
                SqlConnection conn = DataSource.Connection;
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.Add(new SqlParameter("@userName", SqlDbType.NVarChar, 30, "userName"));
                cmd.Parameters[0].Value = user.Name;
                SqlDataReader aReader = cmd.ExecuteReader();
                 value= aReader.Read();
                aReader.Close();
                return value;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return value;
            }
            
        }
        public void AddUser(User user) 
        {
            string insertQuery = "insert into doodleuser(userName,userPassword,userQQ,userEmail,userHomepage,userSex)" +
            "values(@userName,@userPassword,@userQQ,@userEmail,@userHomepage,@userSex)";
            try
            {
                SqlConnection conn = DataSource.Connection;
                SqlCommand cmd = new SqlCommand(insertQuery, conn);
                cmd.Parameters.Add(new SqlParameter("@userName", SqlDbType.NVarChar, 30, "userName"));
                cmd.Parameters.Add(new SqlParameter("@userPassword", SqlDbType.VarChar, 40, "userPassword"));
                cmd.Parameters.Add(new SqlParameter("@userQQ", SqlDbType.VarChar, 20, "userQQ"));
                cmd.Parameters.Add(new SqlParameter("@userEmail", SqlDbType.VarChar, 40, "userEmail"));
                cmd.Parameters.Add(new SqlParameter("@userHomepage", SqlDbType.VarChar, 45, "userHomepage"));
                cmd.Parameters.Add(new SqlParameter("@userSex", SqlDbType.VarChar, 8, "userSex"));
                cmd.Parameters[0].Value = user.Name;
                cmd.Parameters[1].Value = user.Password;
                cmd.Parameters[2].Value = user.QQ;
                cmd.Parameters[3].Value = user.Email;
                cmd.Parameters[4].Value = user.Homepage;
                cmd.Parameters[5].Value = user.Sex;

                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            
        }
        public void UpdateUser(User user)
        {
            string updateQuery = "update doodleuser set userPassword=@userPassword,userQQ=@userQQ,userEmail=@userEmail,userHomepage=@userHomePage,userSex=@userSex" +
                "where userName=@userName";
            try
            {
                SqlConnection conn = DataSource.Connection;
                SqlCommand cmd = new SqlCommand(updateQuery, conn);
                cmd.Parameters.Add(new SqlParameter("@userName", SqlDbType.NVarChar, 30, "userName"));
                cmd.Parameters.Add(new SqlParameter("@userPassword", SqlDbType.VarChar, 40, "userPassword"));
                cmd.Parameters.Add(new SqlParameter("@userQQ", SqlDbType.VarChar, 20, "userQQ"));
                cmd.Parameters.Add(new SqlParameter("@userEmail", SqlDbType.VarChar, 40, "userEmail"));
                cmd.Parameters.Add(new SqlParameter("@userHomepage", SqlDbType.VarChar, 45, "userHomepage"));
                cmd.Parameters.Add(new SqlParameter("@userSex", SqlDbType.VarChar, 8, "userSex"));
                cmd.Parameters[0].Value = user.Name;
                cmd.Parameters[1].Value = user.Password;
                cmd.Parameters[2].Value = user.QQ;
                cmd.Parameters[3].Value = user.Email;
                cmd.Parameters[4].Value = user.Homepage;
                cmd.Parameters[5].Value = user.Sex;

                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
        public User FindUser(string name)
        {
            string query = "select userID,userName,userPassword,userQQ,userEmail,userHomepage,userSex from doodleuser where userName='" + name + "'";
            User user = null;
            try
            {
                SqlConnection con = DataSource.Connection;
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader aReader = cmd.ExecuteReader();
                if (aReader.Read())
                {
                    user = new User();
                    if(!aReader.IsDBNull(0))
                    user.ID = aReader.GetInt32(0);
                    if (!aReader.IsDBNull(1))
                    user.Name = aReader.GetString(1);
                    if (!aReader.IsDBNull(2))
                    user.Password=aReader.GetString(2);
                    if (!aReader.IsDBNull(3))
                    user.QQ=aReader.GetString(3);
                    if (!aReader.IsDBNull(4))
                    user.Email = aReader.GetString(4);
                    if (!aReader.IsDBNull(5))
                    user.Homepage =aReader.GetString(5);
                    if (!aReader.IsDBNull(6))
                    user.Sex = aReader.GetString(6);
                }
                aReader.Close();
                //con.Close();
                return user;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return user;
            }
            
        }
       public void AddDoodle(Int32[] xs, Int32[] ys, Int32 num,Int32 userID) 
       {
           GenericImageRecord record = new GenericImageRecord(null, xs, ys, num);
           ImageShapeContext context= _imageShapeContextBuilder.BuildImageShapeContext(record);
           Doodle doodle = Convertor.ToDoodle(record);
           doodle.UserID = userID;
           DoodleFeature df = Convertor.ToDoodleFeature(context);
           doodle.Description = null;
           AddDoodle(doodle, df);
       }
       public void AddDoodle(Int32[] xs, Int32[] ys, Int32 num, string title,string text,Int32 userID)
       {
           GenericImageRecord record = new GenericImageRecord("", xs, ys, num);
           ImageShapeContext context = _imageShapeContextBuilder.BuildImageShapeContext(record);
           Doodle doodle = Convertor.ToDoodle(record);
           doodle.UserID = userID;
           DoodleFeature df = Convertor.ToDoodleFeature(context);
           DoodleDescription dd = new DoodleDescription();
           dd.Text=text;
           doodle.Description = dd;
           doodle.Title = title;
           AddDoodle(doodle, df);
       }
        public void AddDoodle(Doodle doodle,DoodleFeature doodleFeature)
        {
            string insertQuery = "insert into doodle (doodleContent,userID,doodleTitle) "+
                "values(@doodleContent,@userID,@doodleTitle)";

            string selectQuery = "select Max(doodleID) from doodle";

            string insertFeature = "insert into doodleFeature (doodleID,feature)" +
                "values(@doodleID,@feature)";
            string insertDescription = "insert into doodleDescription(doodleID,DescriptionContent)" +
                "values(@doodleID,@DescriptionContent)";
            try
            {
                //for test
                int ms=DateTime.Now.Millisecond;

                SqlConnection con = DataSource.Connection;

                SqlTransaction sqlTransaction = con.BeginTransaction();

                SqlCommand icmd = new SqlCommand(insertQuery, con, sqlTransaction);
                icmd.Parameters.Add(new SqlParameter("@doodleContent", SqlDbType.Image, 0, "doodleContent"));
                icmd.Parameters.Add(new SqlParameter("@userID", SqlDbType.Int, 0, "userID"));
                icmd.Parameters.Add(new SqlParameter("@doodleTitle", SqlDbType.NVarChar, 100, "doodleTitle"));
                icmd.Parameters[0].Value = doodle.Content;
                icmd.Parameters[1].Value = doodle.UserID;
                icmd.Parameters[2].Value = doodle.Title;
                icmd.ExecuteNonQuery();
                icmd.CommandText = selectQuery;
                SqlDataReader aReader = icmd.ExecuteReader();
                if (aReader.Read() && !aReader.IsDBNull(0))
                {
                    icmd.Parameters.Add(new SqlParameter("@doodleID", SqlDbType.Int, 0, "doodleID"));
                    icmd.Parameters.Add(new SqlParameter("@feature", SqlDbType.Image, 0, "doodleFeature"));
                    Int32 id = aReader.GetInt32(0);
                    aReader.Close();
                    icmd.Parameters[3].Value = id;
                    icmd.Parameters[4].Value = doodleFeature.Feature;
                    icmd.CommandText = insertFeature;
                    icmd.ExecuteNonQuery();
                    if (doodle.Description != null)
                    {
                        icmd.Parameters.Add(new SqlParameter("@DescriptionContent", SqlDbType.NText, 0, "DescriptionContent"));
                        icmd.Parameters[5].Value = doodle.Description.Text;
                        icmd.CommandText = insertDescription;
                        icmd.ExecuteNonQuery();
                    }
                }
                else
                {
                    if (!aReader.IsClosed)
                        aReader.Close();
                    sqlTransaction.Rollback();
                    return;
                }

                sqlTransaction.Commit();
                //for test
                System.Console.WriteLine(DateTime.Now.Millisecond-ms);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            
        }
       public void AddComment(Comment comment)
       {
           string insertQuery = "insert into doodleComment(commentTitle,commentContent,userName,doodleID)" +
               "values(@commentTitle,@commentContent,@userName,@doodleID)";

           string updateQuery = "update doodle set doodleReply=doodleReply+1 where doodleID=@doodleID";

           try
           {
               SqlConnection con = DataSource.Connection;
               SqlTransaction tx = con.BeginTransaction();
               SqlCommand cmd = new SqlCommand(insertQuery, con,tx);
               cmd.Parameters.Add(new SqlParameter("@commentTitle",SqlDbType.NVarChar,100,"commentTitle"));
               cmd.Parameters.Add(new SqlParameter("@commentContent",SqlDbType.NText,0,"commentContent"));
               cmd.Parameters.Add(new SqlParameter("@userName",SqlDbType.NVarChar,30,"userName"));
               cmd.Parameters.Add(new SqlParameter("@doodleID",SqlDbType.Int,0,"doodleID"));
               cmd.Parameters[0].Value = comment.Title;
               cmd.Parameters[1].Value = comment.Text;
               cmd.Parameters[2].Value = comment.UserName;
               cmd.Parameters[3].Value = comment.DoodleID;
               cmd.ExecuteNonQuery();
               cmd.CommandText = updateQuery;
               cmd.ExecuteNonQuery();
               tx.Commit();
           }
           catch (Exception ex)
           {
               Console.WriteLine(ex);
           }
       }

       public Doodle FindDoodleButContent(int id)
       {
           string doodleQuery = "select userID,doodleTitle,doodleReply,doodlePublicatetime " +
              "from doodle where doodleID=" + id + "";
           string desQuery = "select DescriptionContent from doodleDescription where doodleID='" + id + "'";
           Doodle doodle = new Doodle();
           doodle.ID = id;
           DoodleDescription doodleDescription = new DoodleDescription();
           doodleDescription.ID = id;

           try
           {
               char[] charbuffer = null;
               SqlConnection con = DataSource.Connection;
               SqlCommand cmd = new SqlCommand(doodleQuery, con);
               SqlDataReader aReader = cmd.ExecuteReader();
               if (aReader.Read())
               {
                  
                   doodle.UserID = aReader.GetInt32(0);
                   doodle.Title = aReader.GetString(1);
                   doodle.Reply = aReader.GetInt32(2);
                   doodle.Publication = aReader.GetDateTime(3);
                   aReader.Close();

               }
               else
               {
                   if (!aReader.IsClosed)
                       aReader.Close();
                   return null;
               }
               cmd.CommandText = desQuery;
               aReader = cmd.ExecuteReader();
               if (aReader.Read())
               {
                   long len = aReader.GetChars(0, 0, charbuffer, 0, 1);
                   charbuffer = new char[len];
                   aReader.GetChars(0, 0, charbuffer, 0, (int)len);
                   doodleDescription.Text = new string(charbuffer);
                   aReader.Close();
                   doodle.Description = doodleDescription;
               }
               else
               {
                   if (!aReader.IsClosed)
                       aReader.Close();
                   return doodle;
               }
               return doodle;
           }
           catch (Exception e)
           {
               //Console.WriteLine(e);
               return null;
           }
       }
       public Doodle FindDoodle(int id)
       {
           string doodleQuery = "select doodleContent,userID,doodleTitle,doodleReply,doodlePublicatetime "+
               "from doodle where doodleID="+id+"";
           string desQuery = "select DescriptionContent from doodleDescription where doodleID='"+id+"'";
           Doodle doodle = new Doodle();
           doodle.ID = id;
           DoodleDescription doodleDescription = new DoodleDescription();
           doodleDescription.ID = id;

           try
           {
               byte[] buffer = null;
               char[] charbuffer = null;
               SqlConnection con = DataSource.Connection;
               //SqlTransaction tx = con.BeginTransaction();
               SqlCommand cmd = new SqlCommand(doodleQuery, con);
               SqlDataReader aReader = cmd.ExecuteReader();
               if (aReader.Read())
               {
                   long len = aReader.GetBytes(0, 0, buffer, 0, 1);
                   buffer = new byte[len];
                   aReader.GetBytes(0, 0, buffer, 0, (int)len);
                   doodle.Content = buffer;
                   doodle.UserID = aReader.GetInt32(1);
                   doodle.Title = aReader.GetString(2);
                   doodle.Reply = aReader.GetInt32(3);
                   doodle.Publication = aReader.GetDateTime(4);
                   aReader.Close();
                   
               }
               else
               {
                   if (!aReader.IsClosed)
                       aReader.Close();
                   //tx.Rollback();
                   return null;
               }
               cmd.CommandText = desQuery;
               aReader = cmd.ExecuteReader();
               if (aReader.Read())
               {
                   long len = aReader.GetChars(0, 0, charbuffer, 0, 1);
                   charbuffer = new char[len];
                   aReader.GetChars(0, 0, charbuffer, 0, (int)len);
                   doodleDescription.Text = new string(charbuffer);
                   aReader.Close();
                   doodle.Description = doodleDescription;
               }
               else
               {
                   if (!aReader.IsClosed)
                       aReader.Close();
                  // tx.Rollback();
                   return doodle;
               }
              // tx.Commit();
               return doodle;
           }
           catch (Exception e)
           {
               Console.WriteLine(e);
               return null;
           }
           
       }
       public List<Int32> GetPopID(Int32 top)
       {
           string query = "select doodleID,doodleReply from doodle";
           List<Int32> _IDs = new List<Int32>();
           List<Int32> _Replys = new List<Int32>();
           Int32[] _topID = new Int32[top];
           List<Int32> _resultID=new List<Int32>();
           for (int i = 0; i < top; i++)
           {
               _topID[i] = -1;
           }

           try
           {
               SqlConnection con = DataSource.Connection;
               SqlCommand cmd = new SqlCommand(query, con);
               SqlDataReader aReader = cmd.ExecuteReader();
               while (aReader.Read())
               {
                   Int32 id = aReader.GetInt32(0);
                   Int32 reply = aReader.GetInt32(1);
                   _IDs.Add(id);
                   _Replys.Add(reply);
               }
               aReader.Close();
               int count = _Replys.Count;
               for (int i = 0; i < top; i++)
               {
                   Int32 temp = i;
                   for (int j = i; j < count; j++)
                   {
                       if (_Replys[j] > _Replys[temp])
                           temp = j;
                   }
                   Int32 vID = _IDs[i];
                   Int32 vReply = _Replys[i];
                   _IDs[i] = _IDs[temp];
                   _Replys[i] = _Replys[temp];
                   _IDs[temp] = vID;
                   _Replys[temp] = vReply;
                   _topID[i] = _IDs[i];
               }
               for (int k = 0; k < top; k++)
               {
                   if (_topID[k] == -1)
                       continue;
                   else
                   {
                       _resultID.Add(_topID[k]);
                   }
               }

               return _resultID;
           }
           catch (Exception ex)
           {
               return _resultID;
           }
       }
       public List<Doodle> GetPopDoodle(Int32 top) 
       {
           string query = "select doodleID,doodleReply from doodle";
           List<Int32> _IDs = new List<Int32>();
           List<Int32> _Replys = new List<Int32>();
           List<Doodle> _doodles = new List<Doodle>();
           Int32[] _topID = new Int32[top];
           for (int i = 0; i < top; i++)
           {
               _topID[i] = -1;
           }

               try
               {
                   SqlConnection con = DataSource.Connection;
                   SqlCommand cmd = new SqlCommand(query, con);
                   SqlDataReader aReader = cmd.ExecuteReader();
                   while (aReader.Read())
                   {
                       Int32 id = aReader.GetInt32(0);
                       Int32 reply = aReader.GetInt32(1);
                       _IDs.Add(id);
                       _Replys.Add(reply);
                   }
                   aReader.Close();
                   int count=_Replys.Count;
                   for (int i = 0; i < top;i++ )
                   {
                       Int32 temp = i;
                       for (int j = i; j < count; j++) 
                       {
                           if (_Replys[j] > _Replys[temp])
                               temp = j;
                       }
                       Int32 vID = _IDs[i];
                       Int32 vReply = _Replys[i];
                       _IDs[i]=_IDs[temp];
                       _Replys[i]=_Replys[temp];
                       _IDs[temp] = vID;
                       _Replys[temp] = vReply;
                       _topID[i] = _IDs[i];
                   }
                   for (int k = 0; k < top; k++)
                   {
                       if (_topID[k] == -1)
                           continue;
                       else 
                       {
                           _doodles.Add(FindDoodle(_topID[k]));
                       }
                   }

                   return _doodles;
               }
               catch (Exception ex)
               {
                   return _doodles;
               }
       }
       //��ȡ�����е�ͿѻID����Ӧ����
       public List<DoodleFeature> GetAllFeature() 
       {
           string query = "select doodleID,feature from doodleFeature";

           List<DoodleFeature> array = new List<DoodleFeature>();

           try
           {
               SqlConnection con = DataSource.Connection;
               SqlCommand cmd = new SqlCommand(query, con);
               SqlDataReader aReader = cmd.ExecuteReader();
               while (aReader.Read())
               {

                   byte[] buffer = null;
                   int id;
                   DoodleFeature df = new DoodleFeature();
                   id=aReader.GetInt32(0);
                   long len = aReader.GetBytes(1, 0, buffer, 0, 1);
                   buffer = new byte[len];
                   aReader.GetBytes(1,0,buffer,0,(int)len);
                   df.Feature = buffer;
                   df.ID=id;
                   array.Add(df);
               }
               aReader.Close();
               return array;
           }
           catch (Exception ex)
           {
               Console.WriteLine(ex);
               return array;
           }
       }

       public GenericImageQueryResultSet Query(Int32[] xs, Int32[] ys, int num, int top)
       {
           GenericImageRecord record = new  GenericImageRecord(null,xs, ys, num);
           return Query(record, top);

       }
       public List<Doodle> QueryDoodles(Int32[] xs, Int32[] ys, int num, int top)
       {
           GenericImageRecord record = new GenericImageRecord(null, xs, ys, num);
           return QueryDoodles(record, top);
       }
       public List<IDScore> QueryID(Int32[] xs, Int32[] ys, int num, int top)
       {
           GenericImageRecord record = new GenericImageRecord(null, xs, ys, num);
           return QueryID(record, top);

       }
       public GenericImageQueryResultSet Query(Doodle doodle, int top)
       {
           GenericImageRecord record = Convertor.ToGenericImageRecord(doodle);
           return Query(record, top);
       }
       public List<Doodle> QueryDoodles(GenericImageRecord record, int top)
       {
           List<DoodleFeature> list = GetAllFeature();
           Int32[] top_ids = new Int32[top];
           double[] top_scores = new double[top];
           double difference;
           int insertindex;
           int i, j;
           for (i = 0; i < top; i++)
           {
               top_ids[i] = -1;
               top_scores[i] = Double.MaxValue;
           }

           ImageShapeContext shapecontext1;
           ImageShapeContext shapecontext2;

           shapecontext1 = _imageShapeContextBuilder.BuildImageShapeContext(record);
           int count = list.Count;
           for (i = 0; i < count; i++)
           {
               shapecontext2 = Convertor.ToImageShapeContext((DoodleFeature)list[i]);

               // �Ƚ�����ͼƬ�Ĳ����
               difference = _imageShapeContextCompare.Compare(shapecontext1, shapecontext2);
               // ����Ӧ�ò����top�����λ����
               insertindex = -1;
               for (j = top - 1; j >= 0; j--)
               {
                   if (difference >= top_scores[j])
                       break;
                   insertindex = j;
               }
               if (insertindex >= 0)
               {
                   // ����top����
                   for (j = top - 1; j >= insertindex + 1; j--)
                   {
                       top_scores[j] = top_scores[j - 1];
                       top_ids[j] = top_ids[j - 1];
                   }
                   // �����µĶ���
                   top_scores[insertindex] = difference;
                   top_ids[insertindex] = ((DoodleFeature)list[i]).ID;
               }
           }

           List<Doodle> doodles = new List<Doodle>();
           for (i = 0; i < top_ids.Length; i++)
           {
               if (top_ids[i] == -1)
                   break;
               Doodle d = FindDoodle(top_ids[i]);
               doodles.Add(d);
           }

           return doodles;
       }
       public  GenericImageQueryResultSet Query(GenericImageRecord record,int top)
       {
          // 
          
           List<DoodleFeature> list = GetAllFeature();
           Int32[] top_ids = new Int32[top];
           double[] top_scores = new double[top];
           double difference;
           int insertindex;
           int i, j;
           for (i = 0; i < top; i++)
           {
               top_ids[i] = -1;
               top_scores[i] = Double.MaxValue;
           }

           ImageShapeContext shapecontext1;
           ImageShapeContext shapecontext2;

           shapecontext1 = _imageShapeContextBuilder.BuildImageShapeContext(record);
          int count=list.Count;
           for (i = 0; i < count; i++)
           {
               shapecontext2 = Convertor.ToImageShapeContext((DoodleFeature)list[i]);
                
               // �Ƚ�����ͼƬ�Ĳ����
               difference = _imageShapeContextCompare.Compare(shapecontext1, shapecontext2);
               // ����Ӧ�ò����top�����λ����
               insertindex = -1;
               for (j = top - 1; j >= 0; j--)
               {
                   if (difference >= top_scores[j])
                       break;
                   insertindex = j;
               }
               if (insertindex >= 0)
               {
                   // ����top����
                   for (j = top - 1; j >= insertindex + 1; j--)
                   {
                       top_scores[j] = top_scores[j - 1];
                       top_ids[j] = top_ids[j - 1];
                   }
                   // �����µĶ���
                   top_scores[insertindex] = difference;
                   top_ids[insertindex] = ((DoodleFeature)list[i]).ID;
               }
           }
           GenericImageQueryResultSet results = new GenericImageQueryResultSet();
           for (i = 0; i < top_ids.Length; i++)
           {
               if (top_ids[i] == -1)
                   break;
               Doodle d = FindDoodle(top_ids[i]);
               GenericImageRecord r = Convertor.ToGenericImageRecord(d);
               results.Add(r, top_scores[i]);
           }
           
           return results;
       }

       public List<IDScore> QueryID(GenericImageRecord record, int top)
       {
           // 

           List<DoodleFeature> list = GetAllFeature();
           Int32[] top_ids = new Int32[top];
           double[] top_scores = new double[top];
           double difference;
           int insertindex;
           int i, j;
           for (i = 0; i < top; i++)
           {
               top_ids[i] = -1;
               top_scores[i] = Double.MaxValue;
           }

           ImageShapeContext shapecontext1;
           ImageShapeContext shapecontext2;

           shapecontext1 = _imageShapeContextBuilder.BuildImageShapeContext(record);
           int count = list.Count;
           for (i = 0; i < count; i++)
           {
               shapecontext2 = Convertor.ToImageShapeContext((DoodleFeature)list[i]);

               // �Ƚ�����ͼƬ�Ĳ����
               difference = _imageShapeContextCompare.Compare(shapecontext1, shapecontext2);
               // ����Ӧ�ò����top�����λ����
               insertindex = -1;
               for (j = top - 1; j >= 0; j--)
               {
                   if (difference >= top_scores[j])
                       break;
                   insertindex = j;
               }
               if (insertindex >= 0)
               {
                   // ����top����
                   for (j = top - 1; j >= insertindex + 1; j--)
                   {
                       top_scores[j] = top_scores[j - 1];
                       top_ids[j] = top_ids[j - 1];
                   }
                   // �����µĶ���
                   top_scores[insertindex] = difference;
                   top_ids[insertindex] = ((DoodleFeature)list[i]).ID;
               }
           }
           List<IDScore> l = new List<IDScore>();
           for (i = 0; i < top_ids.Length; i++)
           {
               if (top_ids[i] == -1)
                   break;
               l.Add(new IDScore(top_ids[i], top_scores[i]));
           }

           return l;
       }
       
    }
}
