using System;
using System.Collections.Generic;
using System.Text;
using SketchDatabase.Core;
using TaZeLi.Sketch;
using TaZeLi.Sketch.Lib;
using TaZeLi.Sketch.ShapeContext;
using TaZeLi.Sketch.ShapeContext.Lib;
using TaZeLi.Sketch.ShapeContextImprove;
using System.IO;

namespace SketchDatabase.Util
{
    public class Convertor
    {
        public static Doodle ToDoodle(GenericImageRecord record) 
        {
            Doodle doodle=new Doodle();
            MemoryStream ms=new MemoryStream();
            BinaryWriter bw=new BinaryWriter(ms);
            record.WriteStream(bw);
            ms.Position = 0;
            BinaryReader br=new BinaryReader(ms);
            
            doodle.Content=br.ReadBytes((Int32)ms.Length);
            br.Close();
            bw.Close();
            ms.Close();

            return doodle;
        }

        public static GenericImageRecord ToGenericImageRecord(Doodle doodle)
        { 
            GenericImageRecord record=new GenericImageRecord();
            MemoryStream ms=new MemoryStream(doodle.Content);
            BinaryReader reader=new BinaryReader(ms);
            record.ReadStream(reader);
            ms.Close();
            reader.Close();
            return record;
        }

        public static DoodleFeature ToDoodleFeature(ImageShapeContext context)
        { 
            DoodleFeature df=new DoodleFeature();

            MemoryStream ms =new MemoryStream();
            ms.Position = 0;
            BinaryWriter br=new BinaryWriter(ms);
            context.WriteStream(br);
            ms.Position = 0;
            BinaryReader reader=new BinaryReader(ms);
            df.Feature=reader.ReadBytes((Int32)ms.Length);

            reader.Close();
            br.Close();
            ms.Close();
            return df;
        }

        public static ImageShapeContext ToImageShapeContext(DoodleFeature df)
        {
            ImageShapeContext isc = new ImageShapeContext();
            MemoryStream ms = new MemoryStream(df.Feature);
            ms.Position = 0;
            BinaryReader r = new BinaryReader(ms);
            isc.ReadStream(r);
            ms.Close();
            r.Close();
            return isc;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
        }

    }
}
