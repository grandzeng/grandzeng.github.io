using System;
using System.Data;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.IO;


namespace SketchDatabase.Util
{
    public class DataSource
    {
        string defaultSource = "Data Source=localhost;Initial Catalog=5760;User ID=5760;Password=y6Wu6$0;";

        private static string _user = "sa";

        private static string _pwd = "1983920";

        private static string _host = "192.168.1.111";

        private static string _database = "doodle";

        private static string _connectsource;

        private static bool _isInit = false;
       // Data Source=".\SQLEXPRESS;AttachDbFilename=|DataDirectory|\doodle.mdf;Integrated Security=True;User Instance=True";

        private static SqlConnection _connection;

        public  DataSource() { }

        public DataSource(string host, string database, string user, string pwd)
        {
            _host = host;
            _database = database;
            _user = user;
            _pwd = pwd;
        }

        public static string User
        {
            get { return _user; }
            set { _user = value; }
        }

        public static string Pwd
        {
            get { return _pwd; }
            set { _pwd = value; }
        }
        public static string Host
        {
            get { return _host; }
            set { _host = value; }
        }

        public static string Database
        {
            get { return _database; }
            set { _database = value; }
        }
        public static string ConnectionSource
        {
            get
            {
                /*_connectsource ="server=" + _host +
                    ";database=" + _database + 
                    ";uid=" + _user + 
                    ";pwd=" + _pwd;*/
                _connectsource="Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\doodle.mdf;Integrated Security=True;User Instance=True";
                return _connectsource;
            }
            set { _connectsource = value; }
        }

        public static SqlConnection Connection 
        {
            get 
            {
                ReadConfiguration();
                if (_connection == null)
                    _connection = new SqlConnection(ConnectionSource);
                if (_connection.State == ConnectionState.Closed)
                    _connection.Open();
                return _connection;

            }
        }
        public static void ReadConfiguration()
        {
            try
            {
                if (_isInit == true)
                    return;
                FileStream aFile = new FileStream("database.ini", FileMode.OpenOrCreate);
               string name= System.IO.Directory.GetCurrentDirectory();
                StreamWriter sw = new StreamWriter(aFile);
                sw.WriteLine(_host);
                sw.WriteLine(_database);
                sw.WriteLine(_user);
                sw.WriteLine(_pwd);
                sw.Flush();
                _isInit = true;
                sw.Close();
                aFile.Close();
            }
            catch (Exception ex)
            { 
            
            }
        }

    }
}
