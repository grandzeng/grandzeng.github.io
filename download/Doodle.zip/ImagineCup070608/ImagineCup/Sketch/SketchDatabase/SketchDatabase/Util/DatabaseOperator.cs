using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using SketchDatabase.Core;


namespace SketchDatabase.Util
{
    public interface DatabaseOperator
    {
        //User FindUser(string username);

        //void UpdateUser(User user);

       // bool IsUserExists(User user);

        //void AddUser(User user);

       // void AddDoodle(Doodle doodle,DoodleFeature df);

        //--void UpdateDoodle(Doodle doodle);

       //--Doodle FindDoodle(int id);

        //--ArrayList FindDoodle(Doodle doodle);

        ArrayList QueryDoodles(DoodleFeature df,int top);

        ArrayList FindDoodle(Doodle doodle, int Top);

        ArrayList FindDoodleByUser(string username);

        ArrayList FindDoodleByTitle(string title);

       // void AddComment(Comment comment);
    }
}
