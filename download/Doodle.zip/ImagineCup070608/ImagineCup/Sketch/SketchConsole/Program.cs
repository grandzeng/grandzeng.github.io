using System;
using System.Collections.Generic;
using System.Text;
using SketchDatabase.Core;
using SketchDatabase.Util;

namespace SketchConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            SketchDatabase.Util.DataAccess dataAccess = new SketchDatabase.Util.DataAccess();
            User user = new User();
            user.Name = "zengchunqiu";
            user.Password = "***";
            user.QQ = "12345";
            user.Email = "zengchunqiu@cs.scu.edu.cn";
            user.Homepage = "http://cs.scu.edu.cn/~zengchunqiu";
            if (dataAccess.IsUserExists(user))
                Console.WriteLine("exist");
            //dataAccess.AddUser(user);
            user.Password = "123";
            dataAccess.UpdateUser(user);
            user = dataAccess.FindUser("grand");
            System.Console.WriteLine(user.ID+user.Name+user.QQ);

           
            byte [] b1=new byte[3];
            b1[0]=(byte)0;
            b1[1] = (byte)1;
            b1[2] = (byte)2;
            Doodle d = new Doodle("test", 1, b1, 0);
            DoodleDescription dp = new DoodleDescription();
            dp.Text = "for the first time";
            d.Description = dp;
            DoodleFeature df = new DoodleFeature();
            df.Feature = b1;
            dataAccess.AddDoodle(d, df);
            System.Console.WriteLine(d.Content);

            Comment comment = new Comment();
            comment.DoodleID = 2;
            comment.Title = "";
            comment.Text = "good";
            comment.UserName = "zengchunqiu";
            dataAccess.AddComment(comment);
            System.Console.ReadLine();
            Doodle dd = dataAccess.FindDoodle(66);
        }
    }
}
