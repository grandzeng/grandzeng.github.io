﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using pageOperation;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using SketchDatabase.Util;
using SketchDatabase.Core;
using TaZeLi.Sketch;
using System.IO;

public partial class _Default : System.Web.UI.Page
{
    public static readonly int TOP = 5;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            tbIndex.Visible = true;
            tbSearch.Visible = false;
            tbPublish.Visible = false;

            //load hottest image
            DataAccess dataAccess = new DataAccess();
            List<Int32> list = dataAccess.GetPopID(TOP);
            for (int i = 0; i < list.Count; i++)
            {
                string hotimg = "hotImg" + Convert.ToString(i + 1);
                string Hlink = "HLink" + Convert.ToString(i + 1);
                ((HyperLink)(tbIndex.FindControl(Hlink))).NavigateUrl = "DoodleView.aspx?id=" + list[i];
                ((HtmlImage)(tbIndex.FindControl(hotimg))).Src = "Handler.ashx?id=" + list[i];
            }
        }
    }
    protected void ImageBtPublish_Click(object sender, ImageClickEventArgs e)
    {
        tbIndex.Visible = false;
        tbSearch.Visible = false;
        tbPublish.Visible = true;
    }
    protected void ImageBtSearch_Click(object sender, ImageClickEventArgs e)
    {
        tbIndex.Visible = false;
        tbSearch.Visible = true;
        tbPublish.Visible = false;

        if (Request.Form["hiInput"] == null || Request.Form["hiInput"].Equals(""))
            return;

        tbSearch.Rows.Clear();
        
        HtmlImage htImg = new HtmlImage();
        htImg.Src = "image/searchTop.jpg";
        htImg.Alt = "";
        htImg.Height = 19;
        htImg.Width = 576;
        HtmlTableCell htCell = new HtmlTableCell();
        htCell.Attributes.Add("ColSpan", "4");
        htCell.Attributes.Add("style", "border-bottom:dashed 1px blue;");
        htCell.Controls.Add(htImg);
        HtmlTableRow htRow = new HtmlTableRow();
        htRow.Cells.Add(htCell);
        tbSearch.Rows.Add(htRow);

        HtmlTableCell htCellSpace = new HtmlTableCell();
        htCellSpace.Attributes.Add("ColSpan", "4");
        htCellSpace.InnerHtml = "<div style='width:100%; height:10px;'></div>";
        HtmlTableRow htRowSpace = new HtmlTableRow();
        htRowSpace.Cells.Add(htCellSpace);
        tbSearch.Rows.Add(htRowSpace);



        List<Point> points = ArraryStringToInt.stringOperation(Request.Form["hiInput"]);
        Int32 num = points.Count;
        Int32[] xs = new Int32[num];
        Int32[] ys = new Int32[num];
        for (int i = 0; i < num; i++)
        {
            Point p = points[i];
            xs[i] = p.X;
            ys[i] = p.Y;
        }
        DataAccess dataAccess = new DataAccess();
        List<Doodle> doodleResult = dataAccess.QueryDoodles(xs, ys, num, 5);
        if (doodleResult.Count > 0)
        {
            for (int i = 0; i < doodleResult.Count; i++)
            {
                HtmlTableCell htCellImg = new HtmlTableCell();
                htCellImg.Attributes.Add("rowspan", "3");
                htCellImg.Attributes.Add("class", "searchResultImg");
                htCellImg.InnerHtml = "<a href='DoodleView.aspx?id=" + Convert.ToString(doodleResult[i].ID) + "'><img src='Handler.ashx?id=" + doodleResult[i].ID + "' class='searchResultImg' /></a>";
                HtmlTableCell htCellWriter = new HtmlTableCell();
                htCellWriter.Attributes.Add("class", "tdWriter");
                htCellWriter.InnerText = "UserID: " + doodleResult[i].UserName;
                HtmlTableCell htCellDate = new HtmlTableCell();
                htCellDate.Attributes.Add("class", "tdDate");
                htCellDate.InnerText = "" + doodleResult[i].Publication;
                HtmlTableCell htCellReply = new HtmlTableCell();
                htCellReply.Attributes.Add("class", "tdReply");
                htCellReply.InnerText = "Reply: " + doodleResult[i].Reply;

                HtmlTableRow htRowIWDR = new HtmlTableRow();
                htRowIWDR.Cells.Add(htCellImg);
                htRowIWDR.Cells.Add(htCellWriter);
                htRowIWDR.Cells.Add(htCellDate);
                htRowIWDR.Cells.Add(htCellReply);

                tbSearch.Rows.Add(htRowIWDR);

                HtmlTableCell htCellTitle = new HtmlTableCell();
                htCellTitle.Attributes.Add("class", "tdTitle");
                htCellTitle.Attributes.Add("colspan", "3");
                htCellTitle.InnerText = ""+doodleResult[i].Title;
                HtmlTableRow htRowTitle = new HtmlTableRow();
                htRowTitle.Cells.Add(htCellTitle);

                tbSearch.Rows.Add(htRowTitle);

                HtmlTableCell htCellDes = new HtmlTableCell();
                htCellDes.Attributes.Add("class", "tdDes");
                htCellDes.Attributes.Add("colspan", "3");
                htCellDes.InnerText = "" + doodleResult[i].Description.Text;
                HtmlTableRow htRowDes = new HtmlTableRow();
                htRowDes.Cells.Add(htCellDes);

                tbSearch.Rows.Add(htRowDes);
            }
        }

    }
    protected void btPublish_Click(object sender, EventArgs e)
    {
        if (Session["user"] == null)
        {
            Session["InfoPage"] = "login first in the first page!";
            Response.Redirect("InfoPage.aspx");
            //return;
        }
            
        List<Point> points = ArraryStringToInt.stringOperation(Request.Form["hiInput"]);
        Int32 num = points.Count;
        Int32[] xs = new Int32[num];
        Int32[] ys = new Int32[num];
        for (int i = 0; i < num; i++)
        {
            Point p = points[i];
            xs[i] = p.X;
            ys[i] = p.Y;
        }

        DataAccess dataAccess = new DataAccess();
        //Int32 userId = Convert.ToInt32(Session["userId"]);
        User user = (User)Session["user"];
        int userId = user.ID;
        string title = Request.Form["textTitle"];
        string contents = Request.Form["textAreaContents"];
        Int32 idVaule=dataAccess.AddDoodle(xs, ys, num, title, contents, userId);
        if (idVaule > 0)
        {
            string strurl = "DoodleView.aspx?id=" + Convert.ToString(idVaule);
            Response.Redirect(strurl);
        }
        else
        {
            tbIndex.Visible = false;
            tbSearch.Visible = false;
            tbPublish.Visible = true;
            labelError.Text = "Insert failed,Please try again!";
            labelError.Visible = true;
        }
    }
}
