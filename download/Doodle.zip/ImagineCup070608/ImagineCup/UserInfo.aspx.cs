﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using SketchDatabase.Util;
using SketchDatabase.Core;

public partial class UserInfo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString["op"] == "edit")
            {
                User user = (User)Session["user"];
                uiName.Text = user.Name;
                uiName.ReadOnly = true;
                uiPWD.Attributes.Add("value", user.Password);
                TextBox3.Attributes.Add("value", user.Password);
                uiQQ.Text = user.QQ;
                uiEmail.Text = user.Email;
                uiHomePage.Text = user.Homepage;
                uiSex.SelectedValue = user.Sex;
                userInfoSubmit.Disabled = false;
            }
        }
        operationInfo.Text = "";
    }
    protected void userInfoSubmit_ServerClick(object sender, EventArgs e)
    {
        string userName = uiName.Text.Trim();
        string password = uiPWD.Text.Trim();
        string sex = uiSex.SelectedItem.Value;
        string qq = uiQQ.Text.Trim();
        string email = uiEmail.Text.Trim();
        string homePage = uiHomePage.Text.Trim();

        DataAccess da = new DataAccess();
        User userDb = new User();
        userDb.Name = userName;
        userDb.Password = password;
        userDb.Sex = sex;
        userDb.QQ = qq;
        userDb.Email = email;
        userDb.Homepage = homePage;

        if (Session["user"] == null)
        {
            if (!da.IsUserExists(userDb))
            {
                userDb.Password = password;
                userDb.Name = userName;
                userDb.Sex = sex;
                userDb.QQ = qq;
                userDb.Email = email;
                userDb.Homepage = homePage;
                da.AddUser(userDb);
                Session["InfoPage"] = "Register success!";
            }
            else
            {
                operationInfo.Text = "register failed,try again!";
                return;
            }
        }
        else
        {
            da.UpdateUser(userDb);
            Session.Remove("user");
            Session.Add("user", userDb);
            Session["InfoPage"] = "Update success!";
        }
        Response.Redirect("InfoPage.aspx");
    }
   
}
