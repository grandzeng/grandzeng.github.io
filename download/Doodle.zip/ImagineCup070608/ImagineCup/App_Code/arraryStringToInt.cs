﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Drawing;
using System.Collections.Generic;

/// <summary>
/// arraryStringToInt 的摘要说明
/// </summary>
namespace pageOperation
{
    public class ArraryStringToInt
    {
        public ArraryStringToInt()
        {
        }
         public static List<Point> stringOperation(string strSource)
        {
            List<Point> points = new List<Point>();
            if (strSource==null||strSource.Length == 0)
                return points;
            strSource=strSource.Substring(1,strSource.Length-1);
            string[] strArray1;
            strArray1 = strSource.Split(new char[] { '#' });
            for (int i = 0; i < strArray1.Length; i++)
            {
                strArray1[i] = strArray1[i].Trim();
            }
            int len=strArray1.Length;
            for (int i = 0; i < len; i++)
            {
                string []str = strArray1[i].Split(new char[] { ',' });
                Point previous=new Point(0,0);
                if (str.Length >= 0)
                {
                    previous = new Point(Convert.ToInt32(str[0]), Convert.ToInt32(str[1]));
                    points.Add(previous);
                }
                for (int j = 2; j < str.Length; j+=2)
                {
                    int x = Convert.ToInt32(str[j]);
                    int y = Convert.ToInt32(str[j+1]);
                    Point current = new Point(x, y);
                    List<Point> temp=getNearestPoint(previous, current);
                    if (temp[0].X == previous.X && temp[0].Y == previous.Y)
                    {
                        for (Int32 t = 1; t < temp.Count; t++)
                        {
                            points.Add(temp[t]);
                        }
                    }
                    else if (temp[temp.Count - 1].X == previous.X && temp[temp.Count - 1].Y == previous.Y)
                    {
                        for (Int32 t = temp.Count - 2; t >= 0; t--)
                        {
                            points.Add(temp[t]);
                        }
                    }
                    else
                    {
                        for (Int32 t = temp.Count - 1; t >= 0; t--)
                        {
                            points.Add(temp[t]);
                        }
                    }
                    previous = current;
                }
            }
            return points;
        }

        //add some points between two point
        public static List<Point> getNearestPoint(Point start, Point end)
        {
            List<Point> list = new List<Point>();
            Int32 xStart = start.X;
            Int32 yStart = start.Y;
            Int32 xEnd = end.X;
            Int32 yEnd = end.Y;
            int xDistance = Math.Abs(xStart - xEnd);
            int yDistance = Math.Abs(yStart - yEnd);

            if (xStart == xEnd)
            {
                if (yEnd < yStart)
                {
                    for (Int32 t = yStart; t >= yEnd; t--)
                        list.Add(new Point(xStart, t));
                    return list;
                }
                else
                {
                    for (Int32 t = yStart; t <= yEnd; t++)
                        list.Add(new Point(xStart, t));
                    return list;
                }
            }
            if (yStart == yEnd)
            {
                if (xEnd < xStart)
                {
                    for (Int32 t = xStart; t >= xEnd; t--)
                        list.Add(new Point(t, yStart));
                    return list;
                }
                else
                {
                    for (Int32 t = xStart; t <= xEnd; t++)
                        list.Add(new Point(t, yStart));
                    return list;
                }
            }


            if (xDistance >= yDistance)
            {
                if (xStart > xEnd)
                {
                    xStart = end.X;
                    yStart = end.Y;
                    xEnd = start.X;
                    yEnd = start.Y;
                }
                for (int t = xStart; t <= xEnd; t++)
                {
                    float result = (float)(yEnd - yStart) / (float)(xEnd - xStart) * (t - xStart) + yStart;
                    if ((result - (Int32)result) < 0.5)
                        list.Add(new Point(t, (Int32)result));
                    else
                        list.Add(new Point(t, ((Int32)result) + 1));
                }
            }
            else
            {
                if (yStart > yEnd)
                {
                    xStart = end.X;
                    yStart = end.Y;
                    xEnd = start.X;
                    yEnd = start.Y;
                }
                for (int t = yStart; t <= yEnd; t++)
                {
                    float result = (float)(xEnd - xStart) / (float)(yEnd - yStart) * (t - yStart) + xStart;
                    if ((result - (Int32)result) < 0.5)
                        list.Add(new Point((Int32)result,t));
                    else
                        list.Add(new Point(((Int32)result) + 1,t));
                }
            }
            return list;

        }
    }
}