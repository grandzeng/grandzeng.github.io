﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using pageOperation;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using SketchDatabase.Util;
using SketchDatabase.Core;
using TaZeLi.Sketch;
using System.IO;

public partial class DoodleView : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string doodleId = Request.QueryString["id"];
        if (doodleId == null || doodleId.Equals(""))
            return;
        Int32 idValue = Convert.ToInt32(doodleId);
        DataAccess dataAccess=new DataAccess ();
        Doodle doodle= dataAccess.FindDoodle(idValue);
        if (doodle == null)
        {
            Session["doodleIdDetail"]="";
            return;
        }

        doodlePicImg.Src = "Handler.ashx?id=" + doodle.ID;
        labelWriter.Text = doodle.UserName;
        labelDate.Text = "" + doodle.Publication;
        labelReply.Text = "" + doodle.Reply;
        labelTitle.Text = doodle.Title;
        labelDes.Text = doodle.Description.Text;
        Session["doodleIdDetail"] = Convert.ToString(doodle.ID);

        List<Comment>list= dataAccess.FindComment(doodle.ID);
        if (list.Count > 0)
        {
            tbResponse.Rows.Clear();
            for (int i = 0; i < list.Count; i++)
            {
                HtmlTableCell htCellResponseUser = new HtmlTableCell();
                htCellResponseUser.Attributes.Add("class", "tdResponseUser");
                htCellResponseUser.InnerText=list[i].UserName;
                HtmlTableCell htCellResponseDate = new HtmlTableCell();
                htCellResponseDate.Attributes.Add("class", "tdResponseDate");
                htCellResponseDate.InnerText = ""+list[i].CommentTime;

                HtmlTableRow htRowResponseUD = new HtmlTableRow();
                htRowResponseUD.Cells.Add(htCellResponseUser);
                htRowResponseUD.Cells.Add(htCellResponseDate);

                HtmlTableCell htCellResponseContent = new HtmlTableCell();
                htCellResponseContent.Attributes.Add("colspan", "2");
                htCellResponseContent.Attributes.Add("class", "tdResponseContent");
                htCellResponseContent.InnerHtml = "<pre>"+list[i].Text+"</pre>";

                HtmlTableRow htRowResponseC = new HtmlTableRow();
                htRowResponseC.Cells.Add(htCellResponseContent);

                tbResponse.Rows.Add(htRowResponseUD);
                tbResponse.Rows.Add(htRowResponseC);
            }
        }

    }
    protected void btAddResponse_ServerClick(object sender, EventArgs e)
    {

        if (Session["user"] == null)
        {
            Session["InfoPage"] = "login first in the first page!";
            Response.Redirect("InfoPage.aspx");
        } 
        string Use;
        DataAccess dataAccess = new DataAccess();
        Comment comment = new Comment();
        User user = (User)Session["user"];
        comment.UserName = user.Name;
        comment.Text = Request.Form["TextAreaResponse"];
        string sessionDoodleId =(string) Session["doodleIdDetail"];
        if (sessionDoodleId == null || sessionDoodleId.Equals(""))
            return;
        comment.DoodleID = Convert.ToInt32(sessionDoodleId);
        dataAccess.AddComment(comment);
        Response.Redirect("DoodleView.aspx?id=" + Convert.ToString(sessionDoodleId));
    }
}
