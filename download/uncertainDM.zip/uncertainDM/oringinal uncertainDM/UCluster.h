#ifndef		UCLUSTER_H
#define		UCLUSTER_H
#include	<vector>
#include	"UTuple.h"

using namespace std;
typedef	std::vector<unsigned int> uintvector;	

class UCluster
{
public:
	UCluster(void);
	virtual ~UCluster(void);
	UCluster(const UCluster& other);

	UCluster&				operator=(const UCluster& other);

	inline	double			getCost()const;
	inline	void			setCost(double c);
	inline	void			increaseCost(double inc);
	inline	void			decreaseCost(double inc);
	inline	const UTuple&	getCenter()const;
	inline	void			setCenter(const UTuple& tuple);
	inline	unsigned int	getMemberNum()const;
	inline	void			pushBackMember(unsigned int mem);
	inline	void			clearMembers();
	unsigned int&			operator[](const unsigned int index);
	const unsigned int&		operator[](const unsigned int index)const;
	
	bool					search(unsigned int mem)const;

private:
	uintvector	members;
	UTuple		center;
	double		cost;
};

double			UCluster::getCost() const
{
	return cost;
}

void			UCluster::setCost(double c)
{
	cost = c;
}

void			UCluster::increaseCost(double inc)
{
	cost += inc;
}

void			UCluster::decreaseCost(double dec)
{
	cost -= dec;
	if(cost < 0.0)
		cost = 0.0;
}

unsigned int	UCluster::getMemberNum()const
{
	return members.size();
}

void		UCluster::pushBackMember(unsigned int mem)
{
	members.push_back(mem);
}

void		UCluster::clearMembers()
{
	members.clear();
}

const UTuple&			UCluster::getCenter() const
{
	return center;
}

void			UCluster::setCenter(const UTuple &tuple)
{
	center = tuple;
}

#endif
