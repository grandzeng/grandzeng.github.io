#ifndef		UDATA_H
#define		UDATA_H
#include	<fstream>
#include	"UObject.h"
class UData
{
public:
	UData(const char* file_name);
	virtual ~UData(void);
public:
	UObject&		next(UObject& object);
	bool			moreNext();
	void			seekBegin();

	inline unsigned int get_num_object()const;
	inline unsigned int get_dimension()const;

private:
	ifstream udatastream;
	unsigned int num_object;
	unsigned int dimension;
	ios::pos_type begin;
	unsigned int cur_pos;

private:
	//forbidden copy constructor
	UData(const UData& udata);

};

unsigned int UData::get_dimension() const
{
	return dimension;
}

unsigned int UData::get_num_object() const
{
	return num_object;
}

#endif
