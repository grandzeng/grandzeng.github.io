#include <iostream>
#include <fstream>
#include <string>
#include "UTuple.h"
#include "UObject.h"
#include "UData.h"
#include "UKMeans.h"

using namespace std;

string file_data;
string file_real;
string file_rand;
unsigned int k;
string ret_file;

void init()
{
	ifstream in("rundm.ini");
	in>>file_data;
	in>>file_real;
	in>>file_rand;
	in.close();
	ifstream kstream ("k");
	kstream>>k;
	kstream.close();
}

int main()
{
	init();
	
	ofstream iniout("runv.ini");
	UData udata(file_data.c_str());
	ret_file = file_data + ".ret";
	ofstream ret_data(ret_file.c_str());
	iniout<<ret_file<<endl;

	UKMeans ukmeans(k);

	ukmeans.runAlgorithmA(udata);
	ukmeans.showCluster(ret_data,udata);
	ret_data.close();

	UData realdata(file_real.c_str());
	ret_file = file_real + ".ret";
	ofstream ret_real(ret_file.c_str());
	iniout<<ret_file<<endl;

	UKMeans realukmeans(k);

	realukmeans.runAlgorithmA(realdata);
	realukmeans.showCluster(ret_real,realdata);
	ret_real.close();

	UData randdata(file_rand.c_str());
	ret_file = file_rand + ".ret";
	ofstream ret_rand(ret_file.c_str());
	iniout<<ret_file<<endl;

	UKMeans randukmeans(k);

	randukmeans.runAlgorithmA(randdata);
	randukmeans.showCluster(ret_rand,randdata);
	ret_rand.close();

	iniout.close();
	
	/*
	unsigned int num = udata.get_num_object();
	unsigned int dim = udata.get_dimension();
	UObject object(dim);
	cout << "the Number of UObject:" <<num << endl;
	cout << "the Dimension of UObject:"<<dim<<endl;
	getchar();
	while (udata.moreNext())
	{
		udata.next(object);
		cout << object;
		getchar();
	}*/
	//getchar();
	return 0;
}