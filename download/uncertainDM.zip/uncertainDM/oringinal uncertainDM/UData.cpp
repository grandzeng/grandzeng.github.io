#include "UData.h"

UData::UData(const char* file_name)
{
	udatastream.open(file_name);
	if(!udatastream)
		exit(-1);
	udatastream >> num_object;
	udatastream >> dimension;
	cur_pos = 0;
	begin = udatastream.tellg();
}

UData::~UData(void)
{
	udatastream.close();
}

void UData::seekBegin()
{
	udatastream.seekg(begin,ios::beg);
	cur_pos =0;
}

bool UData::moreNext()
{
	if(cur_pos < num_object)
		return true;
	else
		return false;
}

UObject& UData::next(UObject &object)
{
	object.setDim(dimension);
	udatastream >> object;
	cur_pos ++;
	return object;
}
