#ifndef		UTUPLE_H
#define		UTUPLE_H

#include	<iostream>

#define RANGE_IN(index) if(index >= size){ exit(-1);}

using namespace std;

class UTuple
{

private:
	unsigned int	id;
	// The probility of the current tuple existence
	double			probility;
	// the size of the tuple
	unsigned int	size;
	// the data that a tuple contain
	float*			col_data;

public:
	UTuple(unsigned int s =0,unsigned int i =0);

	UTuple(const UTuple& other);

	UTuple& operator= (const UTuple& other);

	virtual ~UTuple(void);

	inline unsigned int get_id()const;

	inline void			set_id(unsigned int id);

	inline unsigned int	get_size()const;

	inline void			set_size(size_t s);
	
	inline double		get_probility()const;

	inline void			set_probility(double p);
	
	void				clear();

	float				get_col(size_t index) const;

	void				set_col(size_t index, float value);

	float&				operator[] (const size_t index);

	const float&		operator[] (const size_t index) const;

	friend ostream&		operator<< (ostream& os, const UTuple& object);
	
	friend istream&		operator>> (istream& is, UTuple& object);

	//when all the data in the col_data is equal, then return ture. otherwise return false
	friend bool			operator == (const UTuple& first,const UTuple& second);
	friend bool			operator != (const UTuple& first,const UTuple& second);

	//when all the data int col_data is equal and the probility is equal, then return true. otherwise return false
	bool				equals(const UTuple& object)const;


};

unsigned int UTuple::get_id()const
{
	return id;
}

void UTuple::set_id(unsigned int id)
{
	this->id =id;
}

unsigned int UTuple::get_size()const
{
	return size;
}

void UTuple::set_size(unsigned int s)
{
	if(size == s)
		return ;
	else if(size == 0)
		col_data = new float[s];
	else
	{
		delete [] col_data;
		col_data = new float[s];
	}
	size = s;
}

double UTuple::get_probility()const
{
	return probility;
}

void UTuple::set_probility(double p)
{
	probility = p;
}
#endif