#include "UTuple.h"

UTuple::UTuple(unsigned int s,unsigned int i)
: probility(1.0),size(s),id(i)
{
	if(size <= 0)
		col_data = NULL;
	else
		col_data = new float[size];

}


UTuple::~UTuple(void)
{
	if(col_data != NULL)
		delete [] col_data;
}

UTuple::UTuple(const UTuple &other)
{
	probility = other.probility;

	size = other.size;
	
	id = other.id;
	col_data = new float [size];

	for(size_t index = 0; index < size; index++)
		col_data[index] = other.col_data[index];
}

UTuple& UTuple::operator =(const UTuple &other)
{
	probility = other.probility;
	id = other.id;

	if(size != other.size)
	{
		if(size !=0)
			delete [] col_data;
		col_data = new float[other.size];
		size = other.size;
	}
	
	if(col_data == NULL)
		exit(1);

	for(size_t index = 0; index < size; index++)
		col_data[index] = other.col_data[index];

	return *this;
}

void UTuple::clear()
{
	size = 0;
	delete []col_data;
	col_data = NULL;
}

float UTuple::get_col(unsigned int index) const
{
	return (*this)[index];
}

void UTuple::set_col(unsigned int index, float value)
{
	(*this)[index] = value;
}

float& UTuple::operator [](const unsigned int index)
{
	RANGE_IN(index);
	return col_data[index];
}

const float& UTuple::operator [](const unsigned int index) const
{
	RANGE_IN(index);
	return col_data[index];
}

ostream& operator<< (ostream& os, const UTuple& object)
{
	
	os << object.id <<"\t";
	for(size_t index = 0; index < object.size; index++)
		os<< object[index] <<" ";
	os << object.probility;
	os << endl;
	
	/*
	os.write((char*)(object.col_data),object.size * sizeof(float));
	os.write((char*)(&(object.probility)),sizeof(double));
	*/

	return os;
}

istream& operator >> (istream& is, UTuple& object)
{
	is>> object.id;
	for(size_t index = 0; index < object.size; index++)
		is>> object[index];
	is >> object.probility;
	
	/*
	is.read((char*)(object.col_data),object.size * sizeof(float));
	is.read((char*)(&(object.probility)),sizeof(double));
	*/
	return is;
}

bool	operator == (const UTuple& first,const UTuple& second)
{
	if(first.size != second.size)
		return false;
	if(first.size == 0)
		return true;

	unsigned int usize,index;
	usize = first.size;
	for(index = 0; index < usize; index ++)
	{
		if(first[index] != second[index])
			return false;
	}

	return true;
}

bool	operator != (const UTuple& first,const UTuple& second)
{
	return ! (first == second);
}

bool	UTuple::equals(const UTuple &object) const
{
	if(*this != object)
		return false;

	if(this ->probility != object.probility)
		return false;
	if(this->id != object.id)
		return false;

	return true;
}