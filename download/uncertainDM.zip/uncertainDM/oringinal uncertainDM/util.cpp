#include	"UTuple.h"
#include	"UData.h"
#include	<cmath>
#include	"util.h"

/*������ƽ����*/
double	caculateDisSQ(const UTuple& first,const UTuple& second,unsigned int norm)
{
	if(first.get_size() != second.get_size())
		return -1.0;

	double distance = 0.0;
	unsigned int usize = first.get_size();
	unsigned int index;
	double help = 0.0;
	for(index =0; index < usize; index++)
	{
		help = abs(first[index] - second[index]);
		help = pow(help,(int)norm);
		distance += help;
	}
	
	return distance ;
}
/*������ƽ���͵Ŀ���*/
double	caculateDistance(const UTuple& first,const UTuple& second,unsigned int norm)
{
	double help;
	double distance;

	distance = caculateDisSQ(first,second,norm);
	help = 1.0 / norm;
	distance = pow(distance,help);

	return distance ;

}

double	caculateDisSQ(const UObject& first,const UTuple& second,unsigned int norm)
{
	
	double distance =0;
	unsigned int num = first.getNum();
	for(size_t index =0; index< num;index++)
	{
		distance += caculateDisSQ(first[index],second,norm) * (first[index].get_probility());
	}

	return distance;
}

double	caculateDistance(const UObject& first,const UTuple& second,unsigned int norm)
{
	double distance =0;
	unsigned int num = first.getNum();
	for(size_t index=0;index<num;index++)
	{
		distance += caculateDistance(first[index],second,norm)* first[index].get_probility();
	}

	return distance;
}