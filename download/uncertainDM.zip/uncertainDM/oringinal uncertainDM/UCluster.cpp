#include "UCluster.h"
#include	<algorithm>

UCluster::UCluster(void):
cost(0),center(0,0)
{
}

UCluster::UCluster(const UCluster& other)
{
	cost = other.cost;
	center = other.center;
	members.clear();
	unsigned int size = other.getMemberNum();
	unsigned int index;
	for(index = 0; index < size; index++)
	{
		members.push_back(other[index]);
	}

}


UCluster::~UCluster(void)
{
	members.clear();
}

bool	UCluster::search(unsigned int mem)const
{
	return binary_search(members.begin(),members.end(),mem);
}

unsigned int& UCluster::operator [](const unsigned int index)
{
	return members[index];
}

const unsigned int& UCluster::operator [](const unsigned index)const
{
	return members[index];
}

UCluster& UCluster::operator=(const UCluster& other)
{
	cost = other.cost;
	center = other.center;
	members.clear();
	unsigned int size = other.getMemberNum();
	unsigned int index;
	for(index = 0; index < size; index++)
	{
		members.push_back(other[index]);
	}

	return *this;
}



