#ifndef		UTIL_H
#define		UTIL_H

#include	"UTuple.h"
#include	"UData.h"
#include	<cmath>
using namespace std;

double	caculateDistance(const UTuple& first,const UTuple& second,unsigned int norm��2);

double	caculateDisSQ(const UTuple& first,const UTuple& second,unsigned int norm��2);

double	caculateDistance(const UObject& first,const UTuple& second,unsigned int norm��2);

double	caculateDisSQ(const UObject& first,const UTuple& second,unsigned int norm��2);

#endif