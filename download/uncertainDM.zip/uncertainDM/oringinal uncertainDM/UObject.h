#ifndef		UOBJECT_H
#define		UOBJECT_H
#include	"UTuple.h"
#define RANGE_IN_UOBJECT(index) if(index >= num){ exit(-1);}
class UObject
{
private:
	double					prob;
	unsigned int			uid;
	unsigned int			num;
	unsigned int			dim;
	UTuple *				tuples;

public:
	UObject(unsigned int d =0, unsigned int n =0, unsigned int id=0,double p = 1.0);
	UObject(const UObject& uo);

	UObject& operator=(const UObject& uo);
	virtual ~UObject();

public:
	inline double			getProb()const;
	inline void				setProb(double p);
	inline unsigned int		getUID()const;
	inline void				setUID(unsigned int id);
	inline unsigned int		getNum()const;
	inline void				setNum(unsigned int n);
	inline unsigned int		getDim()const;
	inline void				setDim(unsigned int d);


	void					clear();
	UTuple					getTuple(const size_t index)const;
	void					setTuple(const size_t index,const UTuple& tuple);
	UTuple&					operator[](const size_t index);
	const UTuple&			operator[](const size_t index)const;
	friend ostream&		operator<< (ostream& os, const UObject& object);
	
	friend istream&		operator>> (istream& is, UObject& object);

};

double UObject::getProb() const
{
	return this->prob;
}

void UObject::setProb(double p)
{
	this->prob = p;
}

unsigned int UObject::getUID() const
{
	return this->uid;
}

void UObject::setUID(unsigned int id)
{
	this->uid = id;
}

unsigned int UObject::getNum() const
{
	return this->num;
}

void UObject::setNum(unsigned int n)
{
	if(num == n)
		return ;
	else if(num == 0)
		tuples = new UTuple[n];
	else
	{
		delete [] tuples;
		tuples = new UTuple[n];
	}
	num = n;

	if(dim !=0)
	{
		for(size_t index =0; index < num; index++)
			tuples[index].set_size(dim);
	}
}

unsigned int UObject::getDim() const
{
	return this->dim;
}

void UObject::setDim(unsigned int d)
{
	if(dim == d)
		return;
	else if(num !=0)
	{
		for(size_t index =0;index<num;index++)
			tuples[index].set_size(d);
	}
	dim = d;
}

#endif