#include "UObject.h"

UObject::UObject(unsigned int d, unsigned int n, unsigned int id,double p ):
prob(p),dim(d),uid(id),num(n)
{
	if(d == 0 || n == 0)
		tuples = NULL;
	else
	{
		tuples = new UTuple[num];
		for(size_t index =0; index < num; index++)
			tuples[index].set_size(dim);
	}

}

UObject::UObject(const UObject &uo)
{
	prob = uo.prob;
	uid = uo.uid;
	dim = uo.dim;
	num = uo.num;

	tuples = new UTuple[num];
	for(size_t index =0;index < num; index++)
		tuples[index] = uo.tuples[index];
}

UObject& UObject::operator=(const UObject& uo)
{
	prob = uo.prob;
	uid = uo.uid;

	if(num != uo.num)
	{
		if(num !=0)
			delete [] tuples;
		tuples = new UTuple[uo.num];
		num = uo.num;
	}
	
	if(tuples == NULL)
		exit(1);

	for(size_t index = 0; index < num; index++)
		tuples[index] = uo.tuples[index];

	return *this;
}

UObject::~UObject(void)
{
	if(tuples != NULL)
		delete [] tuples;
}

void UObject::clear()
{
	num =0;
	delete [] tuples;
	tuples = NULL;
}

UTuple UObject::getTuple(const size_t index) const
{
	return (*this)[index];
}

void UObject::setTuple(const size_t index, const UTuple &tuple)
{
	(*this)[index] = tuple;
}

UTuple& UObject::operator [](const size_t index)
{
	RANGE_IN_UOBJECT(index);
	return tuples[index];
}

const UTuple& UObject::operator [](const size_t index)const
{
	RANGE_IN_UOBJECT(index);
	return tuples[index];
}

ostream& operator << (ostream& os,const UObject& uo)
{
	os << uo.uid <<" ";
	os << uo.num <<" ";
	os << uo.prob << endl;
	for(size_t index =0; index < uo.num;index++)
		os<< uo.tuples[index];
	return os;
}

istream& operator >> (istream& is, UObject& uo)
{
	unsigned int n;
	is>>uo.uid;
	is>> n;
	uo.setNum(n);
	is>>uo.prob;

	for(size_t index =0; index < uo.num;index++)
		is >> uo.tuples[index];

	return is;
}
