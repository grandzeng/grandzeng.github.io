#ifndef		REALGEN_H
#define		REALGEN_H

unsigned int	dim;
unsigned int	numOb;
double			range;
void generateUObject();



#endif