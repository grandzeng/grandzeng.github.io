#ifndef		UKMEANS_H
#define		UKMEANS_H

#include	"UCluster.h"
#include	"UData.h"
#include	"UTuple.h"
#include	"UObject.h"

#define		NORM_1	1
#define		NORM_2	2
#define		MAX		0xFFFFFFFF
class UKMeans
{
public:
	UKMeans(unsigned int k = 0);
	virtual ~UKMeans(void);
	
	inline	unsigned int	getNumClusters()const;
	inline	void			setNumClusters(unsigned int v);
	inline	double			getCost()const;
	inline	void			setCost(double v);

	void					showCluster(ostream& os,UData& udata);

	void					runAlgorithm(UData& udata);
	void					runAlgorithmA(UData& udata);
	void					runAlgorithmP(UData& udata);
//protected:
	void					initClusters(UData& udata);

	//distribute all the utuple in the udata, if any cluster produce some changes, return true. otherwise, return false
	bool					distributeUData(UData& udata);
	bool					AdistributeUData(UData& udata);
	bool					AdistributeUDataP(UData& udata);
	//return the index of the cluster which the tuple should belong to.
	unsigned int			distributeUTuple(UTuple& tuple);

	unsigned int			distributeUObject(UObject& object);
	unsigned int			distributeUObjectP(UObject& object);

	unsigned int			searchCluster(unsigned int tid)const;



private:
	unsigned int	numClusters;
	double			totalCost;
	UCluster*		clusters;

};

unsigned int	UKMeans::getNumClusters() const
{
	return numClusters;
}

void			UKMeans::setNumClusters(unsigned int v)
{
	if(numClusters == v)
		return ;
	else
	{
		if(clusters != NULL)
			delete [] clusters;
		clusters = new UCluster[v];
	}

	numClusters = v;
}

double			UKMeans::getCost() const
{
	return totalCost;
}

void			UKMeans::setCost(double v)
{
	totalCost = v;
}

#endif
