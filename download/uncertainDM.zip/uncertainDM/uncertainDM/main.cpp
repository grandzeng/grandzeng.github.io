#include <iostream>
#include <fstream>
#include <string>
#include <ctime>
#include "UTuple.h"
#include "UObject.h"
#include "UData.h"
#include "UKMeans.h"

using namespace std;

string file_data;
string file_real;
string file_rand;
unsigned int k;
string ret_file;

void init()
{
	ifstream in("rundm.ini");
	in>>file_data;
	in.close();
	ifstream kstream ("k");
	kstream>>k;
	kstream.close();
}

int main()
{
	init();
	
	//ofstream iniout("runv.ini");
	UData udata(file_data.c_str());
	ret_file = file_data + "M.ret";
	ofstream ret_data(ret_file.c_str());
	//iniout<<ret_file<<endl;

	UKMeans ukmeans(k);
	clock_t previous;
	clock_t current;
	previous = clock();
	ukmeans.runAlgorithmM(udata);
	current = clock();
	cout<<"time slash:"<<current - previous<<endl;
	ukmeans.showCluster(ret_data,udata);
	ret_data.close();


	//iniout.close();
	
	/*
	unsigned int num = udata.get_num_object();
	unsigned int dim = udata.get_dimension();
	UObject object(dim);
	cout << "the Number of UObject:" <<num << endl;
	cout << "the Dimension of UObject:"<<dim<<endl;
	getchar();
	while (udata.moreNext())
	{
		udata.next(object);
		cout << object;
		getchar();
	}*/
	//getchar();
	return 0;
}