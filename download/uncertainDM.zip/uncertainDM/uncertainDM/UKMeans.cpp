#include	"UKMeans.h"
#include	"util.h"
#include	<vector>

using namespace std;


static UTuple** pre=NULL;
static double** dists = NULL;
static unsigned int prun =0;
static UTuple* mu=NULL;
static double* baseCost = NULL;


UKMeans::UKMeans(unsigned int k):
totalCost(0.0),numClusters(k)
{
	if(numClusters == 0)
		clusters = NULL;
	else
		clusters = new UCluster[numClusters];
}

UKMeans::~UKMeans(void)
{
	if(clusters != NULL)//;
		delete [] clusters;
	//cout<<"delete [ ] clusters" <<endl;
}

unsigned int UKMeans::searchCluster(unsigned int tid)const
{
	unsigned int pos;

	for(pos =0 ; pos < numClusters;pos++)
	{
		if(clusters[pos].search(tid))
			break;
	}

	return pos;
}

void UKMeans::showCluster(std::ostream &os, UData &udata)
{
	os << udata.get_num_object() << '\t';
	os << udata.get_dimension() << '\t';
	os << numClusters <<"\t"<<totalCost<<endl;
	const UTuple center;
	for(unsigned int i=0;i<numClusters;i++)
	{
		os << "C" << i << '\t' << clusters[i].getCost()<<"\t";
		for(size_t j =0; j<udata.get_dimension();j++)
			os<<(clusters[i].getCenter())[j]<<"\t";
		os<<endl;
	}

	unsigned int udata_pos = 0;
	unsigned int cluster_pos = 0;
	UTuple tuple;
	UObject object;
	udata.seekBegin();
	while(udata.moreNext())
	{
		udata_pos ++;
		object = udata.next(object);
		os << object.getUID() <<"\t";
		os << object.getNum() <<"\t";
		os << object.getProb() << endl;
		for(size_t index =0; index < object.getNum();index++)
		{
			tuple = object[index];
			cluster_pos = searchCluster(tuple.get_id());
			os<<"\t" << cluster_pos<<"\t";
			os<<tuple.get_id()<<"\t";
			for(size_t tindex=0;tindex<object.getDim();tindex++)
				os<<tuple[tindex]<<"\t";
			os<<tuple.get_probility();
			os<<endl;
		}
	}
}

void UKMeans::initClusters(UData &udata)
{
	UTuple tuple;
	UObject object;
	unsigned int initNum =0;
	unsigned int index;
	bool help_break = false;

	udata.seekBegin();

	while(udata.moreNext())
	{
		help_break = false;
		if(initNum >= numClusters)
			break;
		object = udata.next(object);
		tuple = object[0];
		for(index =0;index <initNum; index ++)
		{
			if(tuple == clusters[index].getCenter())
			{
				help_break = true;
				break;
			}
		}

		if(!help_break)
		{
			clusters[index].setCenter(tuple);
			initNum ++;
		}
	}

	if(initNum != numClusters)
	{
		UCluster * help_clusters = new UCluster[initNum];
		for(index = 0; index < initNum; index ++)
		{
			help_clusters[index].setCenter(clusters[index].getCenter());
		}

		numClusters = initNum;
		delete [] clusters;
		clusters = help_clusters;
		help_clusters = NULL;
	}

}

unsigned int UKMeans::distributeUTuple(UTuple &tuple)
{
	unsigned int index, index_cluster ;
	double distance,help_distance;
	distance = caculateDisSQ(clusters[0].getCenter(),tuple,2)* tuple.get_probility();
	index_cluster = 0;

	for(index =1; index < numClusters; index++)
	{
		help_distance = caculateDisSQ(clusters[index].getCenter(),tuple,2)* tuple.get_probility();
		if(help_distance < distance )
		{
			distance = help_distance ;
			index_cluster = index;
		}
	}

	clusters[index_cluster].increaseCost(distance);
	clusters[index_cluster].pushBackMember(tuple.get_id());
	return index_cluster;
}

unsigned int	UKMeans::distributeUObject(UObject& object)
{
	unsigned int index, index_cluster;
	double distance, help_distance;
	distance = caculateDisSQ(object,clusters[0].getCenter(),2);
	index_cluster =0;
	for(index =1;index<numClusters;index++)
	{
		help_distance = caculateDisSQ(object,clusters[index].getCenter(),2);
		if(help_distance < distance )
		{
			distance = help_distance;
			index_cluster = index;
		}
	}

	clusters[index_cluster].increaseCost(distance);
	for(index =0;index < object.getNum();index++)
	{
		clusters[index_cluster].pushBackMember(object[index].get_id());
	}
	
	return index_cluster;
}


unsigned int	UKMeans::distributeUObjectM(UObject& object)
{
	unsigned int index, index_cluster;
	double distance, help_distance;
	unsigned int uid = object.getUID();
	distance = caculateDisSQ(mu[uid],clusters[0].getCenter(),2);
	index_cluster =0;
	for(index =1;index<numClusters;index++)
	{
		help_distance = caculateDisSQ(mu[uid],clusters[index].getCenter(),2);
		if(help_distance < distance )
		{
			distance = help_distance;
			index_cluster = index;
		}
	}

	clusters[index_cluster].increaseCost(distance*object.getProb()+baseCost[uid]);
	for(index =0;index < object.getNum();index++)
	{
		clusters[index_cluster].pushBackMember(object[index].get_id());
	}
	
	return index_cluster;
}

unsigned int	UKMeans::distributeUObjectP(UObject& object)
{
	double min_upper = MAX;
	vector<unsigned int> c_list;
	unsigned int uid = object.getUID();
	unsigned int index, index_cluster;
	double distance, help_distance;
	double upper;
	double lower;
	double dp2p;
	for(size_t i=0;i<numClusters;i++)
	{
		dp2p=caculateDistance(pre[uid][i],clusters[i].getCenter(),2);
		upper = dists[uid][i] + dp2p;
		if(min_upper>upper)
			min_upper = upper;
	}

	for(size_t j=0;j<numClusters;j++)
	{
		lower = (dists[uid][j] -dp2p)>0?(dists[uid][j] -dp2p):0;
		if(lower>min_upper)
		{
			prun++;
		}
		else
			c_list.push_back(j);
	}

	distance = MAX;
	index_cluster = c_list[0];

	for(index =0;index<c_list.size();index++)
	{
		help_distance = caculateDistance(object,clusters[c_list[index]].getCenter(),2);
		dists[uid][c_list[index]] = help_distance;
		pre[uid][c_list[index]] = clusters[c_list[index]].getCenter();
		
		if(help_distance < distance )
		{
			distance = help_distance;
			index_cluster = c_list[index];
		}

		
	}

	clusters[index_cluster].increaseCost(distance);
	for(index =0;index < object.getNum();index++)
	{
		clusters[index_cluster].pushBackMember(object[index].get_id());
	}
	
	return index_cluster;

}

bool UKMeans::distributeUData(UData& udata)
{
	bool changed = false;
	unsigned int dim = udata.get_dimension();
	unsigned int index;
	UTuple help_tuple;
	UObject object;

	//clear all the data in the col_data of tuple
	UTuple* help_tuples = new UTuple[numClusters];
	for(index=0; index < numClusters; index++ )
	{
		help_tuples[index].set_size(dim);

		for(unsigned int i =0; i < dim; i++)
		{
			help_tuples[index][i] = 0.0;
		}
		help_tuples[index].set_id(0);
		help_tuples[index].set_probility(1.0);

		clusters[index].setCost(0.0);
		clusters[index].clearMembers();
	}

	udata.seekBegin();
	
	while(udata.moreNext())
	{
		object = udata.next(object);
		for(size_t d=0;d<object.getNum();d++)
		{
			help_tuple = object[d];
			index = distributeUTuple(help_tuple);
			for(unsigned int j = 0; j<dim;j++)
			{
				help_tuples[index][j] += help_tuple[j];
			}
		}
	}
	
	unsigned int count;
	for(index = 0; index< numClusters; index++)
	{
		count = clusters[index].getMemberNum();
		for(unsigned int t =0; t< dim; t++)
		{
			help_tuples[index][t] = help_tuples[index][t] / count;
		}
	}

	for(index =0; index < numClusters; index++)
	{
		if(help_tuples[index] == clusters[index].getCenter())
			continue;
		else
		{
			clusters[index].setCenter(help_tuples[index]);
			changed = true;
		}
	}

	delete [] help_tuples;

	return changed;
}

bool	UKMeans::AdistributeUData(UData& udata)
{
	bool changed = false;
	unsigned int dim = udata.get_dimension();
	unsigned int index;
	UTuple help_tuple;
	UObject object;

	//clear all the data in the col_data of tuple
	UTuple* help_tuples = new UTuple[numClusters];
	for(index=0; index < numClusters; index++ )
	{
		help_tuples[index].set_size(dim);

		for(unsigned int i =0; i < dim; i++)
		{
			help_tuples[index][i] = 0.0;
		}
		help_tuples[index].set_id(0);
		help_tuples[index].set_probility(1.0);

		clusters[index].setCost(0.0);
		clusters[index].clearMembers();
	}

	udata.seekBegin();
	
	while(udata.moreNext())
	{
		object = udata.next(object);
		//for(size_t d=0;d<object.getNum();d++)
		//{
			index = distributeUObject(object);
			for(unsigned int w =0;w<object.getNum();w++)
			{
				help_tuple = object[w];
				for(unsigned int j = 0; j<dim;j++)
				{
					help_tuples[index][j] += help_tuple[j];
				}
			}
		//}
	}
	
	unsigned int count;
	for(index = 0; index< numClusters; index++)
	{
		count = clusters[index].getMemberNum();
		for(unsigned int t =0; t< dim; t++)
		{
			help_tuples[index][t] = help_tuples[index][t] / count;
		}
	}

	for(index =0; index < numClusters; index++)
	{
		if(help_tuples[index] == clusters[index].getCenter())
			continue;
		else
		{
			clusters[index].setCenter(help_tuples[index]);
			changed = true;
		}
	}

	delete [] help_tuples;

	return changed;
}

bool	UKMeans::AdistributeUDataM(UData& udata)
{
	bool changed = false;
	unsigned int dim = udata.get_dimension();
	unsigned int index;
	UTuple help_tuple;
	UObject object;

	//clear all the data in the col_data of tuple
	UTuple* help_tuples = new UTuple[numClusters];
	for(index=0; index < numClusters; index++ )
	{
		help_tuples[index].set_size(dim);

		for(unsigned int i =0; i < dim; i++)
		{
			help_tuples[index][i] = 0.0;
		}
		help_tuples[index].set_id(0);
		help_tuples[index].set_probility(1.0);

		clusters[index].setCost(0.0);
		clusters[index].clearMembers();
	}

	udata.seekBegin();
	
	while(udata.moreNext())
	{
		object = udata.next(object);
		//for(size_t d=0;d<object.getNum();d++)
		//{
			index = distributeUObjectM(object);
			for(unsigned int w =0;w<object.getNum();w++)
			{
				help_tuple = object[w];
				for(unsigned int j = 0; j<dim;j++)
				{
					help_tuples[index][j] += help_tuple[j];
				}
			}
		//}
	}
	
	unsigned int count;
	for(index = 0; index< numClusters; index++)
	{
		count = clusters[index].getMemberNum();
		for(unsigned int t =0; t< dim; t++)
		{
			help_tuples[index][t] = help_tuples[index][t] / count;
		}
	}

	for(index =0; index < numClusters; index++)
	{
		if(help_tuples[index] == clusters[index].getCenter())
			continue;
		else
		{
			clusters[index].setCenter(help_tuples[index]);
			changed = true;
		}
	}

	delete [] help_tuples;

	return changed;
}

bool	UKMeans::AdistributeUDataP(UData& udata)
{
	bool changed = false;
	unsigned int dim = udata.get_dimension();
	unsigned int index;
	UTuple help_tuple;
	UObject object;

	//clear all the data in the col_data of tuple
	UTuple* help_tuples = new UTuple[numClusters];
	for(index=0; index < numClusters; index++ )
	{
		help_tuples[index].set_size(dim);

		for(unsigned int i =0; i < dim; i++)
		{
			help_tuples[index][i] = 0.0;
		}
		help_tuples[index].set_id(0);
		help_tuples[index].set_probility(1.0);

		clusters[index].setCost(0.0);
		clusters[index].clearMembers();
	}

	udata.seekBegin();
	
	while(udata.moreNext())
	{
		object = udata.next(object);
		//for(size_t d=0;d<object.getNum();d++)
		//{
			index = distributeUObjectP(object);
			for(unsigned int w =0;w<object.getNum();w++)
			{
				help_tuple = object[w];
				for(unsigned int j = 0; j<dim;j++)
				{
					help_tuples[index][j] += help_tuple[j];
				}
			}
		//}
	}
	
	unsigned int count;
	for(index = 0; index< numClusters; index++)
	{
		count = clusters[index].getMemberNum();
		for(unsigned int t =0; t< dim; t++)
		{
			help_tuples[index][t] = help_tuples[index][t] / count;
		}
	}

	for(index =0; index < numClusters; index++)
	{
		if(help_tuples[index] == clusters[index].getCenter())
			continue;
		else
		{
			clusters[index].setCenter(help_tuples[index]);
			changed = true;
		}
	}

	delete [] help_tuples;

	return changed;
}
void UKMeans::runAlgorithm(UData &udata)
{

	initClusters(udata);
	while(distributeUData(udata));
	unsigned int index;
	for(index = 0;index<numClusters;index++)
	{
		totalCost += clusters[index].getCost();
	}
}

void UKMeans::runAlgorithmA(UData &udata)
{
	initClusters(udata);
	while(AdistributeUData(udata));
	unsigned int index;
	for(index = 0;index<numClusters;index++)
	{
		totalCost += clusters[index].getCost();
	}
}

void UKMeans::runAlgorithmP(UData& udata)
{
	size_t index;
	initClusters(udata);
	unsigned int numOb = udata.get_num_object();
	pre = new UTuple* [numOb];
	dists = new double* [numOb];
	prun=0;
	UObject uo;
	index=0;
	udata.seekBegin();
	while(udata.moreNext())
	{
		uo= udata.next(uo);
		dists[index] = new double[numClusters];
		pre[index] = new UTuple[numClusters];
		for(size_t i = 0; i<numClusters;i++)
		{
			dists[index][i] = caculateDistance(uo,clusters[i].getCenter(),2);
			pre[index][i] = clusters[i].getCenter();
		}
		index++;
	}
	

	while(AdistributeUDataP(udata));
	
	for(index = 0;index<numClusters;index++)
	{
		totalCost += clusters[index].getCost();
	}
	cout<<"prun:"<<prun<<endl;
	
	
	for(index =0; index<numOb;index++)
	{
		delete [] dists[index];
		delete [] pre[index];
	}
	delete [] dists;
	delete [] pre;

}

void	UKMeans::runAlgorithmM(UData& udata)
{
	unsigned numOb; 
	unsigned dimension;
	unsigned int index;
	initClusters(udata);

	numOb= udata.get_num_object();
	dimension = udata.get_dimension();
	mu = new UTuple[numOb];
	baseCost = new double[numOb];
	UObject uo;
	UTuple help;

	udata.seekBegin();
	index =0;
	while(udata.moreNext())
	{
		mu[index].set_size(dimension);
		for(unsigned int t=0;t<dimension;t++)
		{
			mu[index][t] = 0.0;
		}
		uo = udata.next(uo);
		for(size_t i =0;i<uo.getNum();i++)
		{
			for(size_t j=0;j<dimension;j++)
			{
				mu[index][j] +=(float)( uo[i][j]*(uo[i].get_probility()/uo.getProb()));
			}
		}

		

		baseCost[index] = caculateDisSQ(uo,mu[index],2);

		index++;

	}

	while(AdistributeUDataM(udata));
	
	for(index = 0;index<numClusters;index++)
	{
		totalCost += clusters[index].getCost();
	}

}