#include	<iostream>
#include	<fstream>
#include	<ctime>

using namespace std;

int main()
{

	ifstream in("iris.arff");
	in.close();
	//clock_t pretime;
	//clock_t lasttime;
	//pretime=clock();
	//getchar();
	//lasttime=clock();
	//cout<<"pretime:"<<pretime<<endl;
	//cout<<"lasttime:"<<lasttime<<endl;
	//cout<<"span:"<<lasttime - pretime<<endl;

	cout << sizeof(unsigned long)<<endl;

	getchar();

	return 0;
}