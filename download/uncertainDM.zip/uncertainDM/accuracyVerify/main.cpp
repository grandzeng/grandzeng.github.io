#include	<iostream>
#include	<fstream>
#include	<sstream>
#include	<string>
#include	<vector>

using namespace std;

unsigned int numOb;
unsigned int dim;
unsigned int numClu;
double		 dtrush;
string		 strush;
typedef vector<double>		 dvector;
typedef vector<unsigned int> uvector;
typedef vector<uvector>		 table;
uvector		crieterion;

uvector		crieterion_map;
uvector		test_map;
uvector		rand_map;

double total;
double accuracy;

int greater(dvector left,dvector right)
{
	unsigned int dimension = left.size();
	size_t index=0;
	while(index<dimension)
	{
		if(left[index]<right[index])
			return -1;
		if(left[index]>right[index])
			return 1;
		else
			index++;
	}
	return 0;
}

void init(ifstream& in,uvector& map)
{
	in>>numOb;
	in>>dim;
	in>>numClu;
	in>>dtrush;
	size_t index;

	vector<dvector> clusters;
	size_t uhelp;
	dvector vhelp;
	map.clear();
	for(index =0;index<numClu;index++)
	{
		map.push_back(index);
	}

	for(index=0;index<numClu;index++)
	{
		in>>strush;
		in>>dtrush;
		vhelp.clear();
		for(size_t t=0;t<dim;t++)
		{
			in>>dtrush;
			vhelp.push_back(dtrush);
		}
		uhelp = index;
		while(uhelp>0)
		{
			if(greater(clusters[uhelp-1],vhelp)>0)
				uhelp--;
			else
				break;
		}
		clusters.insert(clusters.begin()+uhelp,1,vhelp);
		map[index]=map[uhelp];
		map[uhelp]=index; 
	}
}

void initcrieterion(ifstream& in)
{
	unsigned int uid;
	unsigned int numT;
	unsigned int inClust;

	total =0;
	for(size_t index=0; index < numOb;index++)
	{
		in >> uid;
		in >> numT;
		in >> dtrush;
		total += dtrush;
		in>>inClust;
		crieterion.push_back(inClust);
		for(size_t i =0;i<dim+2;i++)
			in>>dtrush;
	}
}

double getAccuracy(ifstream& in)
{
	unsigned int uid;
	unsigned int numT;
	unsigned int inClust;
	unsigned int tid;
	accuracy =0;

	for(size_t index=0;index<numOb;index++)
	{
		in>>uid;
		in>>numT;
		in>>dtrush;
		for(size_t i=0;i<numT;i++)
		{
			in>>inClust;
			in>>tid;
			for(size_t j=0;j<dim;j++)
				in>>dtrush;
			in>>dtrush;
			if(test_map[inClust] == crieterion_map[crieterion[index]])
				accuracy += dtrush;
		}
	}

	return accuracy;
}
string file_data;
string file_real;
string file_rand;
void init()
{
	ifstream in("runv.ini");
	in>>file_data;
	in>>file_real;
	in>>file_rand;
	in.close();
}
int main()
{
	init();
	ifstream in_real(file_real.c_str());
	ifstream in_test(file_data.c_str());
	ifstream in_rand(file_rand.c_str());

	init(in_real,crieterion_map);
	initcrieterion(in_real);
	init(in_test,test_map);
	init(in_rand,rand_map);
	double acc_test=getAccuracy(in_test);
	double acc_rand = getAccuracy(in_rand);
	in_test.close();
	in_real.close();
	in_rand.close();
	cout<<"test:"<<acc_test/total<<endl;
	cout<<"rand:"<<acc_rand/total<<endl;
	

	//cout<<accuracy/total<<endl;

	//getchar();
	return 0;
}