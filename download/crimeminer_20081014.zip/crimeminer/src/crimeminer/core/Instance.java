package crimeminer.core;

public class Instance {

	public final static double MISS_VALUE = Double.NaN;

	private Instances m_dataset;

	private double[] m_attributeValues;

	public Instance() {
		m_dataset = new Instances();
		m_attributeValues = new double[0];
	}

	public Instance(Instances data) {

		if (data == null) {
			m_dataset = new Instances();
			m_attributeValues = new double[0];
		} else {
			m_dataset = data;
			int size = data.getAttributesNum();
			m_attributeValues = new double[size];
		}
	}

	public Instances getDataset() {
		return m_dataset;
	}

	public void setDataset(Instances dataset) {
		m_dataset = dataset;
	}

	public double[] getAttributeValues() {
		return m_attributeValues;
	}

	public void setAttributeValues(double[] values) {
		m_attributeValues = values;
	}

	public double getValueAt(int index) {
		return m_attributeValues[index];
	}

	public void setValueAt(int index, double value) {
		m_attributeValues[index] = value;
	}

	public int getAttributeNum() {
		return m_attributeValues.length;
	}

	public void removeAttribute(int index) {
		if (index < 0 || index >= m_attributeValues.length)
			return;
		double[] attributes = new double[m_attributeValues.length - 1];

		for (int i = 0, count = 0; i < m_attributeValues.length; i++) {
			if (i != index) {
				attributes[count] = m_attributeValues[i];
				count++;
			}
		}

		m_attributeValues = attributes;

	}

	public void removeLastAttribute() {
		removeAttribute(m_attributeValues.length - 1);
	}

	public boolean isMissing(int index) {

		if (m_attributeValues[index] == MISS_VALUE)
			return true;

		return false;
	}
	// public String toString(){
	//		
	// }
}
