package crimeminer.core;

import java.util.*;

public class Attribute {

	public final static int NULL_TYPE = 0;

	public final static int NUMERIC_TYPE = 1;

	public final static int NOMINAL_TYPE = 2;

	public final static int DATE_TYPE = 3;
	
	//public final static int DATETIME_TYPE = 4;

	private String m_name;

	private Hashtable m_hashtable;

	private int m_type;

	// index >=0
	private int m_index;

	public Attribute() {
		m_hashtable = new Hashtable();
		m_type = NULL_TYPE;
		m_name = "";
		m_index = 0;
	}

	public Attribute(String name) {
		m_name = name;
		m_type = NULL_TYPE;
		m_hashtable = new Hashtable();
		m_index = 0;
	}

	public Attribute(String name, int type) {
		m_name = name;
		m_type = type;
		m_hashtable = new Hashtable();
		m_index = 0;
	}

	public Attribute(String name, int type, Hashtable hashtable) {
		m_name = name;
		m_type = type;
		m_index = 0;
		if (hashtable == null)
			m_hashtable.clear();
		else {
			Enumeration enumeration = hashtable.keys();

			while (enumeration.hasMoreElements()) {
				Object key = enumeration.nextElement();
				if (m_hashtable.containsKey(key))
					continue;
				Object value = new Integer(m_hashtable.size() + 1);
				m_hashtable.put(key, value);
			}
		}
	}

	public String getName() {
		return m_name;
	}

	public void setName(String name) {
		m_name = name;
	}

	public int getType() {
		return m_type;
	}

	public String getTypeName() {
		switch (m_type) {
		case NUMERIC_TYPE:
			return "NUMERIC";
		case NOMINAL_TYPE:
			return "NOMINAL";
		case DATE_TYPE:
			return "DATE";
		//case DATETIME_TYPE:
			//return "DATETIME";
		default:
			return "NULL";
		}
	}

	public void setType(int type) {
		m_type = type;
	}

	public int getIndex() {
		return m_index;
	}

	public void setIndex(int index) {
		m_index = index;
	}

	public boolean isNumericType() {
		return m_type == NUMERIC_TYPE;
	}

	public boolean isNominalType() {
		return m_type == NOMINAL_TYPE;
	}

	public boolean isDateType() {
		return m_type == DATE_TYPE;
	}
	
//	public boolean isDateTimeType(){
//		return m_type == DATETIME_TYPE;
//	}
	public boolean isNullType() {
		return m_type == NULL_TYPE;
	}

	public Integer addAttributeValue(Object value) {
		if (m_hashtable.containsKey(value))
			return (Integer) m_hashtable.get(value);
		Object v = new Integer(m_hashtable.size() + 1);
		m_hashtable.put(value, v);
		return (Integer) v;
	}

	public void removeAttributeValue(Object value) {
		if (!m_hashtable.containsKey(value))
			return;
		m_hashtable.remove(value);
		Hashtable help = new Hashtable();

		Enumeration enumeration = m_hashtable.keys();
		while (enumeration.hasMoreElements()) {
			Object key = enumeration.nextElement();
			Object v = new Integer(help.size() + 1);
			help.put(key, v);
		}
		m_hashtable.clear();
		m_hashtable = help;
	}

	public int MapToIndex(Object key) {
		Integer integer = (Integer) m_hashtable.get(key);
		if (integer == null)
			return 0;
		return integer.intValue();
	}

	public Object MapToValue(int index) {
		if (!m_hashtable.contains(new Integer(index)))
			return null;
		Enumeration enumeration = m_hashtable.keys();
		while (enumeration.hasMoreElements()) {
			Object key = enumeration.nextElement();
			Integer value = (Integer) m_hashtable.get(key);
			if (value.intValue() == index)
				return key;
		}
		return null;
	}

	@Override
	public String toString() {
		return "Attribute[" + m_index + "]:" + m_name + "(type:"
				+ getTypeName() + ")";
	}

	public int getNominalCount() {
		if (isNominalType()||isDateType())
			return m_hashtable.size();
		else
			return -1;
	}
	
	public Attribute copy(){
		Attribute ret = new Attribute();
		ret.m_type = this.m_type;
		ret.m_index = this.m_index;
		ret.m_name = this.m_name;
		
		ret.m_hashtable = (Hashtable)this.m_hashtable.clone();
		return ret;
	}
}
