package crimeminer.core;

public class ResultData {

}
