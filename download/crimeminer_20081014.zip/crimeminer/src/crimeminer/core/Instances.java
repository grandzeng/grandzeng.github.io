package crimeminer.core;

import java.util.*;

public class Instances {

	private String m_relationName;

	private ArrayList<Attribute> m_attributes;

	private ArrayList<Instance> m_instances;

	private int m_classIndex;

	public Instances() {
		// empty string
		m_relationName = "";
		// an arraylist of size 0
		m_attributes = new ArrayList<Attribute>();
		// an arraylist of size 0
		m_instances = new ArrayList<Instance>();
		// invalid index value
		m_classIndex = -1;
	}

	public Instances(String name, ArrayList<Attribute> attributes) {
		m_relationName = name;
		m_attributes = new ArrayList<Attribute>();
		if (attributes != null)
			for (int i = 0; i < attributes.size(); i++) {
				m_attributes.add(attributes.get(i));
			}
		m_instances = new ArrayList<Instance>();
		m_classIndex = -1;
	}

	public Instances(String name, ArrayList<Attribute> attributes,
			ArrayList<Instance> instances) {
		m_relationName = name;
		if (attributes == null)
			m_attributes = new ArrayList<Attribute>();
		else
			for (int i = 0; i < attributes.size(); i++) {
				m_attributes.add(attributes.get(i));
			}
		if (instances == null)
			m_instances = new ArrayList<Instance>();
		else
			for (int index = 0; index < instances.size(); index++) {
				m_instances.add(instances.get(index));
			}
		m_classIndex = -1;
	}

	public void addAttribute(Attribute attribute) {
		if (attribute == null)
			return;
		m_attributes.add(attribute);
	}

	public void removeAttributeAt(int index) {
		if (index < 0 || index >= m_attributes.size())
			return;
		m_attributes.remove(index);
		for(int i =0; i<m_instances.size();i++){
			Instance instance = m_instances.get(i);
			instance.removeAttribute(index);
		}
		for(int j =0; j<m_attributes.size();j++)
			m_attributes.get(j).setIndex(j);
	}

	public void removeLastAttribute() {
		if (m_attributes == null || m_attributes.size() == 0)
			return;
		else
			m_attributes.remove(m_attributes.size() - 1);
	}

	public int getAttributesNum() {
		if (m_attributes == null)
			return 0;
		return m_attributes.size();
	}

	public Attribute getAttributeAt(int index) {
		if (index < 0 || index >= m_attributes.size())
			return null;
		return m_attributes.get(index);
	}

	public void setAttributeAt(int index, Attribute attribute) {
		if (index < 0 || index >= m_attributes.size())
			return;
		m_attributes.set(index, attribute);
	}

	public ArrayList<Attribute> getAttributes() {
		return m_attributes;
	}

	public void setAttributes(ArrayList<Attribute> attributes) {
		m_attributes.clear();
		if (attributes == null)
			return;
		for (int index = 0; index < attributes.size(); index++) {
			m_attributes.add(attributes.get(index));
		}
	}

	public void addInstance(Instance instance) {
		if (instance == null)
			return;
		m_instances.add(instance);
	}

	public void removeInstanceAt(int index) {
		if (index < 0 || index >= m_instances.size())
			return;
		m_instances.remove(index);
	}

	public void removeLastInstance() {
		if (m_instances == null || m_instances.size() == 0)
			return;
		else
			m_instances.remove(m_instances.size() - 1);
	}

	public int getInstancesNum() {
		if (m_instances == null)
			return 0;
		return m_instances.size();
	}

	public Instance getInstanceAt(int index) {
		if (index < 0 || index >= m_instances.size())
			return null;
		return m_instances.get(index);
	}

	public void setInstanceAt(int index, Instance instance) {
		if (index < 0 || index >= m_instances.size())
			return;
		m_instances.set(index, instance);
	}

	public ArrayList<Instance> getInstances() {
		return m_instances;
	}

	public void setInstances(ArrayList<Instance> instances) {
		m_instances.clear();

		if (instances == null)
			return;
		for (int index = 0; index < instances.size(); index++) {
			m_instances.add(instances.get(index));
		}
	}

	public String getRelationName() {
		return m_relationName;
	}

	public void setRelationName(String name) {
		if (name == null)
			m_relationName = "";
		else
			m_relationName = name;
	}

	public int getClassIndex() {
		return m_classIndex;
	}

	public void setClassIndex(int index) {
		if (index < 0)
			m_classIndex = -1;
		else
			m_classIndex = index;
	}
	
	//this method is used for nominal type
//	public int NominalStatistic(){
//		
//	}
	
}
