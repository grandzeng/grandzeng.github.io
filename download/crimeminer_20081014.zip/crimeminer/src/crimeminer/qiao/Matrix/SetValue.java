package crimeminer.qiao.Matrix;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import crimeminer.qiao.com.swtdesigner.SWTResourceManager;

public class SetValue {

	private Text text_21;
	private Text text_20;
	private Text text_19;
	private Text text_18;
	private Text text_17;
	private Text text_1;
	private Text text_15;
	private Text text_14;
	private Text text_13;
	private Text text_12;
	private Text text_11;
	private Text text_10;
	private Text text_9;
	private Text text_8;
	private Text text_7;
	private Text text_6;
	private Text text_5;
	private Text text_4;
	private Text text_3;
	private Text text_2;
	private Text text;
	protected Shell shell;

	/**
	 * Launch the application
	 * @param args
	 */
	/*public static void main(String[] args) {
		try {
			SetValue window = new SetValue();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}*/

	/**
	 * Open the window
	 */
	public void open() {
		final Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
	}

	/**
	 * Create contents of the window
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setBackground(SWTResourceManager.getColor(128, 255, 255));
		shell.setSize(590, 612);
		shell.setText("SWT Application");

		final Label label = new Label(shell, SWT.NONE);
		label.setBackground(SWTResourceManager.getColor(128, 255, 255));
		label.setText("��Ⱥ��-->�ȶ���");
		label.setBounds(53, 68, 127, 17);

		text = new Text(shell, SWT.BORDER);
		text.setBounds(214, 65, 80, 25);

		final Label label_1 = new Label(shell, SWT.NONE);
		label_1.setText("�������ƶ�");
		label_1.setBounds(250, 21, 86, 17);

		final Label label_2 = new Label(shell, SWT.NONE);
		label_2.setBackground(SWTResourceManager.getColor(128, 255, 255));
		label_2.setBounds(53, 109, 127, 17);
		label_2.setText("��Ⱥ��-->�˷���");

		text_2 = new Text(shell, SWT.BORDER);
		text_2.setBounds(214, 106, 80, 25);

		final Label label_3 = new Label(shell, SWT.NONE);
		label_3.setBackground(SWTResourceManager.getColor(128, 255, 255));
		label_3.setBounds(53, 161, 127, 17);
		label_3.setText("��Ⱥ��-->�к���");

		text_3 = new Text(shell, SWT.BORDER);
		text_3.setBounds(214, 158, 80, 25);

		final Label label_4 = new Label(shell, SWT.NONE);
		label_4.setBackground(SWTResourceManager.getColor(128, 255, 255));
		label_4.setBounds(53, 205, 127, 17);
		label_4.setText("��Ⱥ��-->������");

		text_4 = new Text(shell, SWT.BORDER);
		text_4.setBounds(214, 202, 80, 25);

		final Label label_5 = new Label(shell, SWT.NONE);
		label_5.setBackground(SWTResourceManager.getColor(128, 255, 255));
		label_5.setBounds(53, 245, 127, 17);
		label_5.setText("��Ⱥ��-->������");

		text_5 = new Text(shell, SWT.BORDER);
		text_5.setBounds(214, 242, 80, 25);

		final Label label_6 = new Label(shell, SWT.NONE);
		label_6.setBackground(SWTResourceManager.getColor(128, 255, 255));
		label_6.setBounds(53, 287, 127, 17);
		label_6.setText("�ȶ���-->�˷���");

		text_6 = new Text(shell, SWT.BORDER);
		text_6.setBounds(214, 284, 80, 25);

		final Label label_7 = new Label(shell, SWT.NONE);
		label_7.setBackground(SWTResourceManager.getColor(128, 255, 255));
		label_7.setBounds(314, 71, 127, 17);
		label_7.setText("�ȶ���-->������");

		text_7 = new Text(shell, SWT.BORDER);
		text_7.setBounds(475, 68, 80, 25);

		final Label label_8 = new Label(shell, SWT.NONE);
		label_8.setBackground(SWTResourceManager.getColor(128, 255, 255));
		label_8.setBounds(314, 112, 127, 17);
		label_8.setText("�ȶ���-->������");

		text_8 = new Text(shell, SWT.BORDER);
		text_8.setBounds(475, 109, 80, 25);

		final Label label_9 = new Label(shell, SWT.NONE);
		label_9.setBackground(SWTResourceManager.getColor(128, 255, 255));
		label_9.setBounds(314, 161, 127, 17);
		label_9.setText("�˷���-->�к���");

		text_9 = new Text(shell, SWT.BORDER);
		text_9.setBounds(475, 158, 80, 25);

		final Label label_10 = new Label(shell, SWT.NONE);
		label_10.setBackground(SWTResourceManager.getColor(128, 255, 255));
		label_10.setBounds(53, 334, 127, 17);
		label_10.setText("�ȶ���-->�к���");

		text_10 = new Text(shell, SWT.BORDER);
		text_10.setBounds(214, 331, 80, 25);

		final Label label_9_1 = new Label(shell, SWT.NONE);
		label_9_1.setBackground(SWTResourceManager.getColor(128, 255, 255));
		label_9_1.setBounds(314, 205, 127, 17);
		label_9_1.setText("�˷���-->������");

		text_11 = new Text(shell, SWT.BORDER);
		text_11.setBounds(475, 202, 80, 25);

		final Label label_9_2 = new Label(shell, SWT.NONE);
		label_9_2.setBackground(SWTResourceManager.getColor(128, 255, 255));
		label_9_2.setBounds(314, 245, 127, 17);
		label_9_2.setText("�˷���-->������");

		text_12 = new Text(shell, SWT.BORDER);
		text_12.setBounds(475, 242, 80, 25);

		final Label label_9_1_1 = new Label(shell, SWT.NONE);
		label_9_1_1.setBackground(SWTResourceManager.getColor(128, 255, 255));
		label_9_1_1.setBounds(314, 287, 127, 17);
		label_9_1_1.setText("�к���-->������");

		text_13 = new Text(shell, SWT.BORDER);
		text_13.setBounds(475, 284, 80, 25);

		final Label label_9_1_2 = new Label(shell, SWT.NONE);
		label_9_1_2.setBackground(SWTResourceManager.getColor(128, 255, 255));
		label_9_1_2.setBounds(314, 334, 127, 17);
		label_9_1_2.setText("�˷���-->������");

		text_14 = new Text(shell, SWT.BORDER);
		text_14.setBounds(475, 331, 80, 25);

		final Label label_9_1_3 = new Label(shell, SWT.NONE);
		label_9_1_3.setBackground(SWTResourceManager.getColor(128, 255, 255));
		label_9_1_3.setBounds(314, 378, 127, 17);
		label_9_1_3.setText("������-->������");

		text_15 = new Text(shell, SWT.BORDER);
		text_15.setBounds(475, 375, 80, 25);

		final Button okButton = new Button(shell, SWT.NONE);
		okButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(final SelectionEvent e) {
				String t1 = text.getText();
				String t2 = text_2.getText();
				String t3 = text_3.getText();
				String t4 = text_4.getText();
				String t5 = text_5.getText();
				String t6 = text_6.getText();
				String t7 = text_7.getText();
				String t8 = text_8.getText();
				String t9 = text_9.getText();
				String t10 = text_10.getText();
				String t11 = text_11.getText();
				String t12 = text_12.getText();
				String t13 = text_13.getText();
				String t14 = text_14.getText();
				String t15 = text_15.getText();
				if (t1!="" && t2!="" && t3!="" && t4!="" && t5!="" && t6!="" && t7!="" && t8!="" && t9!="" && t10!="" && t11!="" && t12!="" && t13!="" && t14!="" && t15!=""){
				double [][] array = {
						{0, Integer.parseInt(t1), Integer.parseInt(t2), Integer.parseInt(t3), Integer.parseInt(t4), Integer.parseInt(t5)},
						{0, 0, Integer.parseInt(t6), Integer.parseInt(t7), Integer.parseInt(t8), Integer.parseInt(t9)},
						{0, 0, 0, Integer.parseInt(t10), Integer.parseInt(t11), Integer.parseInt(t12)},
						{0, 0, 0, 0, Integer.parseInt(t13), Integer.parseInt(t14)},
						{0, 0, 0, 0, 0, Integer.parseInt(t15)},
						{0, 0, 0, 0, 0, 0}
				};
				double [][]p = new double[array.length][array.length];
			
				for (int i=0; i<array.length; i++)
				{
					for (int j=0; j<array.length; j++)
					{
						if (i==j)
						{
							p[i][j] = 1;  
						}
						else 
							if (i<j)
							{
								p[i][j] = array[i][j];
							}
							else
							{
								p[i][j] = 1.0 / array[j][i];
							}
						}
				}
						
				try
				{
					Matrix m = new Matrix(p);
					//System.out.println("The original matrix is: ");
					Class.forName("com.mysql.jdbc.Driver");
					Connection con;
					con = DriverManager.getConnection("jdbc:mysql://localhost/crimeminer","root","admin");
					Statement state = con.createStatement();
					Statement state1 = con.createStatement();
					state.execute("delete from matrix");
					state.close();
					
					for (int i=0; i<m.matrix.length; i++)
					{
						for (int j=0; j<m.matrix[i].length; j++)
						{
							//System.out.print(m.matrix[i][j]);
							//System.out.print('\t');
							String insert = "insert into matrix values(" + i + "," + j + "," + m.matrix[i][j] + ")";
							state1.executeUpdate(insert);
						}
						//System.out.println();
					}
					
					//System.out.println("The weight of Character matrix is: ");
										
					m.ComputeWeight();
					
					text_1.setText(String.valueOf(m.weight[0]));
					text_17.setText(String.valueOf(m.weight[1]));
					text_18.setText(String.valueOf(m.weight[2]));
					text_19.setText(String.valueOf(m.weight[3]));
					text_20.setText(String.valueOf(m.weight[4]));
					text_21.setText(String.valueOf(m.weight[5]));
					
					
				}
				catch(Exception e1)
				{
					e1.printStackTrace();
				}
				}
				else
				{
					Error err = new Error(shell);
					err.open();
					return;
				}
			}
		});
		okButton.setText("ȷ��");
		okButton.setBounds(195, 530, 54, 27);

		final Button cancelButton = new Button(shell, SWT.NONE);
		cancelButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(final SelectionEvent e) {
				shell.close();
			}
		});
		cancelButton.setText("�˳�");
		cancelButton.setBounds(365, 530, 54, 27);

		final Label label_11 = new Label(shell, SWT.NONE);
		label_11.setBackground(SWTResourceManager.getColor(128, 255, 255));
		label_11.setText("��������Ȩ��");
		label_11.setBounds(10, 418, 85, 17);

		final Label label_12 = new Label(shell, SWT.NONE);
		label_12.setBackground(SWTResourceManager.getColor(128, 255, 255));
		label_12.setText("��Ⱥ��");
		label_12.setBounds(28, 452, 54, 17);

		text_1 = new Text(shell, SWT.BORDER);
		text_1.setBounds(10, 488, 80, 25);

		final Label label_12_1 = new Label(shell, SWT.NONE);
		label_12_1.setBackground(SWTResourceManager.getColor(128, 255, 255));
		label_12_1.setBounds(111, 452, 54, 17);
		label_12_1.setText("�ȶ���");

		text_17 = new Text(shell, SWT.BORDER);
		text_17.setBounds(100, 488, 80, 25);

		final Label label_12_2 = new Label(shell, SWT.NONE);
		label_12_2.setBackground(SWTResourceManager.getColor(128, 255, 255));
		label_12_2.setBounds(213, 450, 54, 17);
		label_12_2.setText("�˷���");

		text_18 = new Text(shell, SWT.BORDER);
		text_18.setBounds(195, 486, 80, 25);

		final Label label_12_3 = new Label(shell, SWT.NONE);
		label_12_3.setBackground(SWTResourceManager.getColor(128, 255, 255));
		label_12_3.setBounds(310, 450, 54, 17);
		label_12_3.setText("�к���");

		text_19 = new Text(shell, SWT.BORDER);
		text_19.setBounds(295, 486, 80, 25);

		final Label label_12_4 = new Label(shell, SWT.NONE);
		label_12_4.setBackground(SWTResourceManager.getColor(128, 255, 255));
		label_12_4.setBounds(398, 450, 54, 17);
		label_12_4.setText("������");

		text_20 = new Text(shell, SWT.BORDER);
		text_20.setBounds(390, 486, 80, 25);

		final Label label_12_5 = new Label(shell, SWT.NONE);
		label_12_5.setBackground(SWTResourceManager.getColor(128, 255, 255));
		label_12_5.setBounds(508, 450, 54, 17);
		label_12_5.setText("������");

		text_21 = new Text(shell, SWT.BORDER);
		text_21.setBounds(490, 486, 80, 25);

		final Label label_13 = new Label(shell, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_13.setBackground(SWTResourceManager.getColor(128, 255, 255));
		label_13.setBounds(10, 400, 545, 17);
		//
	}

}
