package crimeminer.qiao.Matrix;


public class Matrix {
	double [][] matrix;
	double [] weight;
	
	public Matrix(double mtx[][])
	{
		matrix = new double[mtx.length][mtx.length];
		for (int i=0; i<mtx.length; i++)
		{
			for (int j=0; j<mtx[i].length; j++)
			{
				matrix[i][j] = mtx[i][j];
			}
		}
		weight = new double[mtx.length];
	}
	
	public double [] ComputeWeight()
	{
		double wSum = 0;
		double []sum = new double[matrix.length];
		double []weightSum = new double[matrix.length];
		double []weightAvg = new double[matrix.length];
		double [][]p = new double[matrix.length][matrix.length];
		// double []weight = new double[matrix.length];
		for (int j=0; j<matrix.length; j++)
		{
			for (int i=0; i<matrix.length; i++)
			{
				sum[j] += matrix[i][j]; 
				
			}
			for (int i=0; i<matrix.length; i++)
			{
				p[i][j] = matrix[i][j] / sum[j]; 
			}

		}
		
		for (int i = 0; i<matrix.length; i++)
		{
			for (int j=0; j<matrix.length; j++)
			{
				weightSum[i] += p[i][j];
			}
			wSum += weightSum[i];
		}
		
		for (int k = 0; k<matrix.length; k++)
		{
			weightAvg[k] = weightSum[k] / wSum;
			weight[k] = weightAvg[k];
			System.out.print(weight[k]);
			System.out.print('\t');
			
		}
		System.out.println();
	
		return weight;
	}
	
	
}
