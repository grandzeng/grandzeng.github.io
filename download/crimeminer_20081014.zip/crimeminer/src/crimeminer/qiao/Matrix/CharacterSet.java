package crimeminer.qiao.Matrix;

import java.awt.Event;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Random;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ControlAdapter;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Scale;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class CharacterSet extends Dialog {

	private Text text_9;
	private Text text_7;
	private Text text_1;
	private Text text_6;
	private Text text_5;
	private Text text_4;
	private Text text_3;
	private Text text_2;
	private Text text;
	protected Object result;

	protected Shell shell;
	int sent;
	int receive;
	double dep;

	/**
	 * Create the dialog
	 * @param parent
	 * @param style
	 */
	public CharacterSet(Shell parent, int style) {
		super(parent, style);
	}

	/**
	 * Create the dialog
	 * @param parent
	 */
	public CharacterSet(Shell parent) {
		this(parent, SWT.NONE);
	}

	/**
	 * Open the dialog
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		return result;
	}

	/**
	 * Create contents of the dialog
	 */
	protected void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL);
		shell.setSize(500, 546);
		shell.setText("Email simulation");
		
		final Label label = new Label(shell, SWT.NONE);
		label.setText("��Ⱥ��");
		label.setBounds(34, 28, 57, 17);

		text = new Text(shell, SWT.BORDER);
		text.setBounds(362, 25, 80, 25);

		final Scale scale = new Scale(shell, SWT.NONE);
		
		scale.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(final SelectionEvent e) {
				final double value = scale.getSelection()/100.0;
				text.setText(String.valueOf(value));
			}
		});
		scale.setBounds(130, 10, 210, 48);
		scale.setMinimum(0);
		scale.setMaximum(100);
		scale.setPageIncrement(10);

		final Label label_1 = new Label(shell, SWT.NONE);
		label_1.setBounds(34, 81, 57, 17);
		label_1.setText("�ȶ���");
		
		final Scale scale_1 = new Scale(shell, SWT.NONE);
		
		scale_1.setBounds(127, 63, 210, 48);

		text_2 = new Text(shell, SWT.BORDER);
		text_2.setBounds(362, 78, 80, 25);
		
		scale_1.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(final SelectionEvent e) {
				final double value_1 = scale_1.getSelection()/100.0;
				text_2.setText(String.valueOf(value_1));
			}
		});

		final Label label_2 = new Label(shell, SWT.NONE);
		label_2.setBounds(34, 131, 57, 17);
		label_2.setText("�˷���");

		final Scale scale_2 = new Scale(shell, SWT.NONE);
		
		scale_2.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(final SelectionEvent e) {
				
				final double value_2 = scale_2.getSelection()/100.0;
				text_3.setText(String.valueOf(value_2));
			}
		});
		scale_2.setBounds(127, 113, 210, 48);

		text_3 = new Text(shell, SWT.BORDER);
		text_3.setBounds(362, 128, 80, 25);

		final Label label_3 = new Label(shell, SWT.NONE);
		label_3.setBounds(34, 174, 57, 17);
		label_3.setText("�к���");

		final Scale scale_3 = new Scale(shell, SWT.NONE);
		
		scale_3.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(final SelectionEvent e) {
				final double value_3 = scale_3.getSelection()/100.0;
				text_4.setText(String.valueOf(value_3));
			}
		});
		scale_3.setBounds(127, 156, 210, 48);

		text_4 = new Text(shell, SWT.BORDER);
		text_4.setBounds(362, 171, 80, 25);

		final Label label_4 = new Label(shell, SWT.NONE);
		label_4.setBounds(34, 224, 57, 17);
		label_4.setText("������");

		final Scale scale_4 = new Scale(shell, SWT.NONE);
		
		scale_4.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(final SelectionEvent e) {
				final double value_4 = scale_4.getSelection()/100.0;
				text_5.setText(String.valueOf(value_4));
			}
		});
		scale_4.setBounds(127, 206, 210, 48);

		text_5 = new Text(shell, SWT.BORDER);
		text_5.setBounds(362, 221, 80, 25);

		final Label label_5 = new Label(shell, SWT.NONE);
		label_5.setBounds(34, 274, 57, 17);
		label_5.setText("������");

		final Scale scale_5 = new Scale(shell, SWT.NONE);
		
		scale_5.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(final SelectionEvent e) {
				final double value_5 = scale_5.getSelection()/100.0;
				text_6.setText(String.valueOf(value_5));
			}
		});
		scale_5.setBounds(127, 256, 210, 48);

		text_6 = new Text(shell, SWT.BORDER);
		text_6.setBounds(362, 271, 80, 25);
		
		final Button button = new Button(shell, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(final SelectionEvent e) {
				try{
					double[][] p = new double[6][6];
					Class.forName("com.mysql.jdbc.Driver");
					Connection con;
					con = DriverManager.getConnection("jdbc:mysql://localhost/crimeminer","root","admin");
					Statement state = con.createStatement();
					
					String query = "select * from matrix";
					ResultSet result = state.executeQuery(query);
					while (result.next())
					{
						int i = result.getInt(1);
						int j = result.getInt(2);
						p[i][j] = result.getDouble(3);
					}
					
					for (int i=0; i<6; i++)
					{
							for (int j=0; j<6; j++)
							{
								System.out.print(p[i][j]);
								System.out.print('\t');
							}
							System.out.println();
					}
					
					
					Matrix m = new Matrix(p);
					m.ComputeWeight();
					double value = Double.parseDouble(text.getText());
					double value1 = Double.parseDouble(text_2.getText());
					double value2 = Double.parseDouble(text_3.getText());
					double value3 = Double.parseDouble(text_4.getText());
					double value4 = Double.parseDouble(text_5.getText());
					double value5 = Double.parseDouble(text_6.getText());
					System.out.println(value + " " + value1 + " " + value2 + " " + value3 + " " + value4 + " " + value5);
					System.out.println(m.weight[0] + " " + m.weight[1] + " " + m.weight[2] + " " + m.weight[3] + " " + m.weight[4] + " " + m.weight[5]);
					double cValue = value*m.weight[0]+value1*m.weight[1]+value2*m.weight[2]+
					value3*m.weight[3]+value4*m.weight[4]+value5*m.weight[5];
					System.out.println(cValue);
					dep = cValue;
					double miu = 7 - cValue*6;
					double sigma = 1.5 - cValue * 2; 
					/*Random r = new Random();
					r.nextGaussian();*/
					double f = 0.7;
					double avg = miu - Math.sqrt(-2*sigma*sigma*Math.log(f*sigma*Math.sqrt(2*Math.PI)));
					System.out.println(avg);
					int day = Integer.parseInt(text_1.getText());
					double sNo = day / avg;
					int s = (int) sNo;
					sent = s;
					System.out.println(sent);
					text_7.setText(String.valueOf(s));
					state.close();
					con.close();
				}
				catch(Exception ex){
				}
				//double sigma = 1.5 - cValue * 2;	
			}
		});
		
		button.setText("�����ʼ�ģ��");
		button.setBounds(110, 387, 103, 27);

		final Button button_1 = new Button(shell, SWT.NONE);
		button_1.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(final SelectionEvent e) {
				int m = 4;
				double tuner = 0;
				if (sent < m)
				{
					tuner = (dep-0.5)/0.5 * ((4-sent)/3);
				}
				else
				{
					tuner = (0.5-dep)/0.5 * ((sent-4)/3);
				}
				receive = (int)(sent+tuner);
				text_9.setText(String.valueOf(receive));		
			}
		});
		button_1.setBounds(381, 387, 103, 27);
		button_1.setText("�����ʼ�ģ��");

		final Label label_6 = new Label(shell, SWT.NONE);
		label_6.setText("ģ������");
		label_6.setBounds(148, 340, 65, 17);

		text_1 = new Text(shell, SWT.BORDER);
		text_1.setBounds(265, 337, 80, 25);

		text_7 = new Text(shell, SWT.BORDER);
		text_7.setBounds(110, 445, 103, 25);

		final Label label_7 = new Label(shell, SWT.NONE);
		label_7.setText("�����ʼ�����");
		label_7.setBounds(10, 448, 94, 17);

		final Label label_7_1 = new Label(shell, SWT.NONE);
		label_7_1.setBounds(281, 445, 94, 17);
		label_7_1.setText("�����ʼ�����");

		text_9 = new Text(shell, SWT.BORDER);
		text_9.setBounds(381, 442, 103, 25);
		//
	}

}
