DROP TABLE IF EXISTS matrix;
CREATE TABLE matrix(
cfrom int,
cto int,
relation DOUBLE
);
