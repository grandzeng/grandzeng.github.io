package crimeminer.qiao.Client;

import java.awt.BorderLayout;

import javax.swing.JPanel;

import crimeminer.mining.Operator;
import crimeminer.mining.trajectory.predictor.ui.PutmodePanel;
import crimeminer.ui.component.Walker;

public class MailAnalyzer extends Operator
{
	/*
	private JPanel mainPanel;
	
	public MailAnalyzer()
	{
		mainPanel=new JPanel();
		mainPanel.setLayout(new BorderLayout());
	}
	*/
	public void run()
	{
		try {
			Client window = new Client();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
		//mainPanel.add(analyzer, BorderLayout.CENTER);
		Walker walker = globalManager.getWalker();
		walker.removeAll();
		//walker.addTab("Mail Analyzer", mainPanel);
	}
}
