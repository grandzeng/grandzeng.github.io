DROP TABLE IF EXISTS relation;
CREATE TABLE relation(
eFrom int,
eTo int,
weight int
);
