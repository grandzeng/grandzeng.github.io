package crimeminer.qiao.Client;

public class ShortestPath {
	int[][] matrix;

	public ShortestPath(int[][] path)
	{
		matrix = new int[path.length][path.length];
		for (int i=0; i<path.length; i++)
		{
			for (int j=0; j<path.length; j++)
			{
				matrix[i][j] = path[i][j];
			}
		}
	}
	public void ComputePath(int x)
	{
		int w=0;
		int vexn=0;

		vexn = matrix.length;
		int m[][]=new int[vexn][vexn];
		for (int i=0; i<vexn ; i++)
		{
			for (int j=0;j<vexn;j++)
			{
				m[i][j]=3266;	
			}
		}
		
		for (int i=0; i<vexn ; i++)
		{
			for (int j=0;j<vexn;j++)
			{
				if (matrix[i][j]!=0)
				{
					m[i][j]=matrix[i][j];
				}
			}
		}
		
		int dist[]=new int[vexn]; //record the shortest distance
		int path[]=new int[vexn]; //recode the previous node
		int v0;
		int ss[]=new int[vexn];
		int u,vnum,wm;
				
		for(int cc=0;cc<vexn;cc++)
		{
			path[cc]=0;
			dist[cc]=0;
			ss[cc]=0;
		}
		v0=x;
		u=0;
		vnum=0;
		wm=0;
		for (w=0;w<vexn;w++)
		{
			dist[w]=m[v0][w]; //record the distanct from v0
			if (m[v0][w] < 3266) 
				path[w]=v0; //find current nodes from the initial node
		}
	
		ss[v0]=1;
		vnum=1;
		while(vnum<vexn)
		{
			wm=3266;
			u=v0;
			//System.out.print(u+"<-");
			for(w=0;w<vexn;w++)
			{
				if (ss[w]==0 && dist[w]<wm)
				{
					u=w;
					wm=dist[w]; //�Ҵӳ�ʼ�������̵ľ���

				}
			}
			//System.out.print(u+"<-");
			
			ss[u]=1; //����̾���ı�־λ��Ϊ1
			vnum++; //vnum��ʾ�ҵ������·������
			
			for(w=0;w<vexn;w++)
			{
				if (ss[w]==0 && dist[u]+m[u][w]<dist[w])
				{
					dist[w]=dist[u]+m[u][w];
					path[w]=u;
					//System.out.print(u+"<-"+" the total distance is: "+dist[w]);
					//System.out.println();
				}
				/*else if (ss[w]!=1)
				{
					System.out.append(w+"<-");
				}*/
			}
		}
		for (int i=1; i<dist.length; i++)
		{
			System.out.println("the shortest path from " + x + " to " + i + " is: " + dist[i]);
			                                                                            
		}
	}
}

