package crimeminer.qiao.Client;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.swing.JButton;

import javax.swing.JDialog;
import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Path extends JDialog {

	/**
	 * Launch the application
	 * @param args
	 */
		public void run() {
				try {
					Path dialog = new Path();
					dialog.addWindowListener(new WindowAdapter() {
						public void windowClosing(WindowEvent e) {
							return;
						}
					});
					dialog.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

	/**
	 * Create the dialog
	 */
	public Path() {
		super();
		setTitle("���·��");
		setBounds(100, 100, 537, 375);

		final JButton button = new JButton();
		button.addMouseListener(new MouseAdapter() {
			public void mouseClicked(final MouseEvent arg0) {
				removeNotify();
				
			}
		});
		button.setText("�˳�");
		getContentPane().add(button, BorderLayout.SOUTH);

		final JEditorPane editorPane = new JEditorPane();
		getContentPane().add(editorPane, BorderLayout.CENTER);
		try{
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(".\\path.txt")));
			String temp = in.readLine();
			String str = new String();
			while(temp != null)
			{
				str += temp;
				str += "\n";
				temp = in.readLine();
				
			}
			editorPane.setText(str);
			in.close();
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
		//
	}

}
