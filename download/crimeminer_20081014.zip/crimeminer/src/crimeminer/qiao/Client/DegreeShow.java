package crimeminer.qiao.Client;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import org.eclipse.jface.text.TextViewer;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;

public class DegreeShow extends Dialog {

	private Table table;
	private Text text;
	protected Object result;

	protected Shell shell;

	/**
	 * Create the dialog
	 * @param parent
	 * @param style
	 */
	public DegreeShow(Shell parent, int style) {
		super(parent, style);
	}

	/**
	 * Create the dialog
	 * @param parent
	 */
	public DegreeShow(Shell parent) {
		this(parent, SWT.NONE);
	}

	/**
	 * Open the dialog
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		return result;
	}

	/**
	 * Create contents of the dialog
	 */
	protected void createContents() {
		try
		{
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL);
		shell.setSize(489, 365);
		shell.setText("����������");
		
		table = new Table(shell, SWT.BORDER);
		table.setLinesVisible(true);
		table.setHeaderVisible(true);
		table.setBounds(23, 23, 438, 229);

		
		final Label label = new Label(shell, SWT.NONE);
		label.setText("���ĳ�Ա");
		label.setBounds(59, 276, 66, 17);
		
		final TableColumn newColumnTableColumn = new TableColumn(table, SWT.CENTER);
		newColumnTableColumn.setWidth(157);
		newColumnTableColumn.setText("Member");
		newColumnTableColumn.setResizable(true);
		//table.getColumn(0).pack();

		final TableColumn newColumnTableColumn_1 = new TableColumn(table, SWT.CENTER);
		newColumnTableColumn_1.setWidth(92);
		newColumnTableColumn_1.setText("Degree");
		newColumnTableColumn_1.setResizable(true);
		//table.getColumn(1).pack();

		final TableColumn newColumnTableColumn_2 = new TableColumn(table, SWT.CENTER);
		newColumnTableColumn_2.setWidth(87);
		newColumnTableColumn_2.setText("Betweeness");
		newColumnTableColumn_2.setResizable(true);
		//table.getColumn(2).pack();

		final TableColumn newColumnTableColumn_3 = new TableColumn(table, SWT.CENTER);
		newColumnTableColumn_3.setWidth(100);
		newColumnTableColumn_3.setText("Closeness");
		newColumnTableColumn_3.setResizable(true);
		//table.getColumn(3).pack();
		
		
			//Class.forName("com.mysql.jdbc.Driver");
			Connection con;
			con = DriverManager.getConnection("jdbc:mysql://localhost/crimeminer","root","admin");
			Statement state = con.createStatement();
			Statement state1 = con.createStatement();
			
			int node[] = new int[20];
			int degree[] = new int[20];
			int betweeness[] = new int[20];
			int closeness[] = new int[20];
			int score[] = new int[20];
			String email[] = new String[20];
			int i = 0;
			int max = 0;
			int core = 0;
			
			String query = "select * from degree";
			ResultSet rsQuery = state.executeQuery(query);
			
			//String query1 = "select * from client";
			//ResultSet rsQuery2 = state1.executeQuery(query1);
			int k=0;
				
			while(rsQuery.next())
			{
				node[i] = rsQuery.getInt(1);
				degree[i] = rsQuery.getInt(2);
				betweeness[i] = rsQuery.getInt(3);
				closeness[i] = rsQuery.getInt(4);
				TableItem newItemTableItem = new TableItem(table, SWT.BORDER);

				String query1 = "select * from client";
				ResultSet rsQuery2 = state1.executeQuery(query1);
				while((rsQuery2.next()))
				{
					if (node[i]==0)
					{
						email[i] = rsQuery2.getString(2);
						newItemTableItem.setText(0, email[i]);
						break;
					}
					else
					{
						node[i]--;
					}
				}
				rsQuery2.close();
				//newItemTableItem.setText(0, String.valueOf(node[i]));
				newItemTableItem.setText(1, String.valueOf(degree[i]));
				newItemTableItem.setText(2, String.valueOf(betweeness[i]));
				newItemTableItem.setText(3, String.valueOf(closeness[i]));
				
				System.out.println(node[i] + "  " + degree[i] + "  " + betweeness[i] + "  " + closeness[i]);
				i++;
			}
				
				
			
			rsQuery.close();
	
			con.close();
			for (int j=0; j<i; j++)
			{
				closeness[j]=3266*i-closeness[j];
				score[j]=degree[j]+betweeness[j]+closeness[j]/3266;
				if (score[j]>max)
				{
					max=score[j];
					core=j;
				}
			}
		text = new Text(shell, SWT.BORDER);
		text.setBounds(195, 273, 267, 25);
		text.setText(email[core]);


		}
		catch (Exception error)
		{
			error.printStackTrace();
		}





		//
	}

}
