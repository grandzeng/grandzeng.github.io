package crimeminer.qiao.Client;

//import PwdError;

import java.awt.Frame;
import java.awt.Graphics;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.lang.*;

import javax.swing.JPanel;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.omg.CORBA.portable.InputStream;


import crimeminer.qiao.Matrix.*;
import crimeminer.qiao.com.swtdesigner.SWTResourceManager;


public class Client
{

	private Text text_1;
	private Combo combo_2;
	private Combo combo_1;
	private Combo combo;
	private Text text;
	private Table table;
	protected Shell shell;

	/**
	 * Launch the application
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			Client window = new Client();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window
	 */
	public void open() {
		final Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
	}

	/**
	 * Create contents of the window
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setBackground(Display.getCurrent().getSystemColor(SWT.COLOR_WHITE));
		shell.setSize(632, 587);
		shell.setText("�ʼ�����ϵͳ");

		final Label label = new Label(shell, SWT.NONE);
		label.setBackground(Display.getCurrent().getSystemColor(SWT.COLOR_WHITE));
		label.setForeground(SWTResourceManager.getColor(0, 0, 255));
		label.setFont(SWTResourceManager.getFont("������", 12, SWT.NONE));
		label.setText("����SNA�ķ����ʼ�����ϵͳ");
		label.setBounds(167, 27, 359, 27);

		table = new Table(shell, SWT.BORDER);
		table.setLinesVisible(true);
		table.setHeaderVisible(true);
		table.setBounds(50, 75, 194, 202);

		final TableColumn newColumnTableColumn = new TableColumn(table, SWT.NONE);
		newColumnTableColumn.setWidth(100);
		newColumnTableColumn.setText("�û��ʼ���ַ");

		final TableColumn newColumnTableColumn_1 = new TableColumn(table, SWT.NONE);
		newColumnTableColumn_1.setWidth(100);
		newColumnTableColumn_1.setText("��Ϊģʽ");

		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con;
			con = DriverManager.getConnection("jdbc:mysql://localhost/crimeminer","root","admin");
			Statement state = con.createStatement();
			
			//show the cliend data in table
			String emailShow = null;
			int modeShow = 0;
			String query = "select * from client";
			ResultSet rsQuery = state.executeQuery(query);
			
			if(!rsQuery.next())
			{
				System.out.println("there is no record");
				return;
			}
			else 
			{
				do
				{
					emailShow = rsQuery.getString(2);
					modeShow = rsQuery.getInt(3);
					TableItem newItemTableItem = new TableItem(table, SWT.BORDER);
					newItemTableItem.setText(0, emailShow);
					newItemTableItem.setText(1, String.valueOf(modeShow));
					
				}
				while(rsQuery.next());
				rsQuery.close();
			}
			con.close();
		}
		catch (Exception error)
		{
			error.printStackTrace();
		}

		final Label label_1 = new Label(shell, SWT.NONE);
		label_1.setBackground(Display.getCurrent().getSystemColor(SWT.COLOR_WHITE));
		label_1.setText("�ʼ���ַ");
		label_1.setBounds(289, 75, 56, 17);

		text = new Text(shell, SWT.BORDER);
		text.setBounds(281, 98, 169, 25);

		final Label label_2 = new Label(shell, SWT.NONE);
		label_2.setBackground(Display.getCurrent().getSystemColor(SWT.COLOR_WHITE));
		label_2.setText("��Ϊģʽ");
		label_2.setBounds(289, 153, 56, 17);

		combo = new Combo(shell, SWT.NONE);
		combo.add("ģʽ1", 0);
		combo.add("ģʽ2", 1);
		combo.add("ģʽ3", 2);
		combo.add("ģʽ4", 3);
		combo.add("ģʽ5", 4);
		combo.add("ģʽ6", 5);
		combo.add("ģʽ7", 6);
		combo.add("ģʽ8", 7);
		combo.add("ģʽ9", 8);
		combo.add("ģʽ10", 9);
		combo.add("ģʽ11", 10);
		combo.add("ģʽ12", 11);
		combo.add("ģʽ13", 12);
		combo.add("ģʽ14", 13);
		combo.add("ģʽ15", 14);
		combo.add("ģʽ16", 15);
		combo.add("ģʽ17", 16);
		combo.add("ģʽ18", 17);
		combo.add("ģʽ19", 18);
		combo.select(0);
		combo.setBounds(281, 186, 169, 25);

		final Button button = new Button(shell, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(final SelectionEvent e) {
				try
				{
					Connection con;
					con = DriverManager.getConnection("jdbc:mysql://localhost/crimeminer","root","admin");
					Statement state = con.createStatement();
					String email = text.getText();
					int mode = combo.getSelectionIndex();
					if (text.getText()!="" && mode!=-1) 
					{
					String addClient = "insert into client values(" + "LAST_INSERT_ID()" 
					+ "," + "'" + email + "'" + "," + mode + ")";
						
					state.executeUpdate(addClient);
						
					TableItem newItemTableItem = new TableItem(table, SWT.BORDER);

					newItemTableItem.setText(0, email);
					newItemTableItem.setText(1, String.valueOf(mode));
					state.close();
					con.close();
					
					text.setText("");
					combo.select(0);
					return;
					}
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}			
			}
		});
		button.setText("�����û�");
		button.setBounds(278, 242, 67, 27);

		final Button button_1 = new Button(shell, SWT.NONE);
		button_1.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(final SelectionEvent e) {
				try
				{
					Connection con;
					con = DriverManager.getConnection("jdbc:mysql://localhost/crimeminer","root","admin");
					Statement state = con.createStatement();
					Statement state1 = con.createStatement();
					
					TableItem[] newItem = table.getSelection();
					for (int i=0; i<newItem.length; i++)
					{
						String delString = "delete from client where email = " + "'" 
						+ newItem[i].getText() + "'";
						state.execute(delString);
						//table.clear(table.getSelectionIndex());
					}
					//table.clearAll();
					table.removeAll();
					
					//show the cliend data in table
					String emailShow = null;
					int modeShow = 0;
					String query = "select * from client";
					ResultSet rsQuery = state1.executeQuery(query);
					
					if(!rsQuery.next())
					{
						System.out.println("there is no record");
						return;
					}
					else 
					{
						do
						{
							emailShow = rsQuery.getString(2);
							modeShow = rsQuery.getInt(3);
							TableItem newItemTableItem = new TableItem(table, SWT.BORDER);
							newItemTableItem.setText(0, emailShow);
							newItemTableItem.setText(1, String.valueOf(modeShow));
							
						}
						while(rsQuery.next());
						rsQuery.close();
					}
					con.close();
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}
				try
				{
					Connection con;
					con = DriverManager.getConnection("jdbc:mysql://localhost/crimeminer","root","admin");
					Statement state = con.createStatement();
							
					//show the cliend data in table
					String emailShow = null;
					String query = "select * from client";
					ResultSet rsQuery = state.executeQuery(query);
					
					if(!rsQuery.next())
					{
						System.out.println("there is no record");
						return;
					}
					else 
					{
					do
					{
						int index = 0;
						emailShow = rsQuery.getString(2);
						combo_1.add(emailShow, index);
						index++;
						//lable[index] = emailShow;
					}
					while(rsQuery.next());
					rsQuery.close();
					}
					con.close();
				}
				catch (Exception error)
				{
					error.printStackTrace();
				}				
			}
		});
		button_1.setBounds(412, 242, 67, 27);
		button_1.setText("ɾ���û�");

		final CLabel label_3 = new CLabel(shell, SWT.NONE);
		label_3.setBackground(Display.getCurrent().getSystemColor(SWT.COLOR_WHITE));
		label_3.setText("���������");
		label_3.setBounds(50, 320, 90, 23);

		combo_1 = new Combo(shell, SWT.NONE);
		/*combo_1.addMouseListener(new MouseAdapter() {
			public void mouseDown(final MouseEvent e) {
				try
				{
					combo_1.removeAll();
					Connection con;
					con = DriverManager.getConnection("jdbc:mysql://localhost/crimeminer","root","admin");
					Statement state = con.createStatement();
							
					//show the cliend data in table
					String emailShow = null;
					String query = "select * from client";
					ResultSet rsQuery = state.executeQuery(query);
					
					if(!rsQuery.next())
					{
						System.out.println("there is no record");
						return;
					}
					else 
					{
					do
					{
						int index = 0;
						emailShow = rsQuery.getString(2);
						combo_1.add(emailShow, index);
						//combo_2.add(emailShow, index);
						index++;
						//lable[index] = emailShow;
					}
					while(rsQuery.next());
					rsQuery.close();
					}
					con.close();
				}
				catch (Exception error)
				{
					error.printStackTrace();
				}	
			}
		});*/
		
		try
		{
			Connection con;
			con = DriverManager.getConnection("jdbc:mysql://localhost/crimeminer","root","admin");
			Statement state = con.createStatement();
					
			//show the cliend data in table
			String emailShow = null;
			String query = "select * from client";
			ResultSet rsQuery = state.executeQuery(query);
			
			if(!rsQuery.next())
			{
				System.out.println("there is no record");
				return;
			}
			else 
			{
			do
			{
				//int index = 0;
				emailShow = rsQuery.getString(2);
				combo_1.add(emailShow);
				//index++;
				//lable[index] = emailShow;
			}
			while(rsQuery.next());
			rsQuery.close();
			}
			con.close();
		}
		catch (Exception error)
		{
			error.printStackTrace();
		}				
		combo_1.setBounds(50, 349, 157, 25);
		
		final String lable[] = new String[combo_1.getItemCount()];
		for (int i=0; i<lable.length; i++)
		{
			lable[i] = combo_1.getItem(i).toString();
			//System.out.println(lable[i]);
		}

		final Button button_2 = new Button(shell, SWT.NONE);
		button_2.setText("��������ϵ");
		button_2.setBounds(96, 418, 99, 27);

		final int[][] neighMatrix = new int[combo_1.getItemCount()][combo_1.getItemCount()];
		
		
		final Button button_3 = new Button(shell, SWT.NONE);
		button_3.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(final SelectionEvent e) {
				//when there is an edge between nodes, set the element to 1
				int x = combo_1.getSelectionIndex();
				int y = combo_2.getSelectionIndex();
				String weight = text_1.getText();
			if (weight!="" && x!=y)
			{
				try
				{
					Connection con;
					con = DriverManager.getConnection("jdbc:mysql://localhost/crimeminer","root","admin");
					Statement state = con.createStatement();
					Statement state1 = con.createStatement();
					Statement state2 = con.createStatement();
					
					String query = "select * from relation";
					ResultSet rsQuery = state1.executeQuery(query);

					while(rsQuery.next())
					{
							int eFrom = rsQuery.getInt(1);
							int eTo = rsQuery.getInt(2);
							neighMatrix[x][y] = Integer.parseInt(weight);
							
							//if ((eFrom==x && eTo==y)||(eTo==x && eFrom==y))
							if (eFrom==x && eTo==y)
							{
								String delete = "delete from relation where eFrom = " + eFrom + " and eTo = " + eTo;
								state2.execute(delete);
							}
					}
					String insert = "insert into relation values(" + x + "," + y + "," + neighMatrix[x][y] + ")";
					state.executeUpdate(insert);
					
					rsQuery.close();
					state.close();
					state2.close();
					con.close();
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}
			}
		}
	});
		
		button_3.setText("Ӧ������ϵ");
		button_3.setBounds(247, 418, 99, 27);

		final Label label_4 = new Label(shell, SWT.NONE);
		label_4.setBackground(Display.getCurrent().getSystemColor(SWT.COLOR_WHITE));
		label_4.setText("�����Ľ��");
		label_4.setBounds(236, 326, 109, 17);

		combo_2 = new Combo(shell, SWT.NONE);
		/*combo_2.addMouseListener(new MouseAdapter() {
			public void mouseDown(final MouseEvent e) {
				try
				{
					combo_2.removeAll();
					Connection con;
					con = DriverManager.getConnection("jdbc:mysql://localhost/crimeminer","root","admin");
					Statement state = con.createStatement();
							
					//show the cliend data in table
					String emailShow = null;
					String query = "select * from client";
					ResultSet rsQuery = state.executeQuery(query);
					
					if(!rsQuery.next())
					{
						System.out.println("there is no record");
						return;
					}
					else 
					{
					do
					{
						int index = 0;
						emailShow = rsQuery.getString(2);
						//combo_1.add(emailShow, index);
						combo_2.add(emailShow, index);
						index++;
						//lable[index] = emailShow;
					}
					while(rsQuery.next());
					rsQuery.close();
					}
					con.close();
				}
				catch (Exception error)
				{
					error.printStackTrace();
				}	
			}
		});*/
		try
		{
			Connection con;
			con = DriverManager.getConnection("jdbc:mysql://localhost/crimeminer","root","admin");
			Statement state = con.createStatement();
					
			//show the cliend data in table
			String emailShow = null;
			String query = "select * from client";
			ResultSet rsQuery = state.executeQuery(query);
					
			if(!rsQuery.next())
			{
				System.out.println("there is no record");
				return;
			}
			else 
			{
			do
			{
				//int index = 0;
				emailShow = rsQuery.getString(2);
				combo_2.add(emailShow);
				//index++;
			}
			while(rsQuery.next());
			rsQuery.close();
			}
			con.close();
		}
		catch (Exception error)
		{
			error.printStackTrace();
		}			
		combo_2.setBounds(228, 349, 144, 25);

		final Button button_4 = new Button(shell, SWT.NONE);
		button_4.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(final SelectionEvent e) {
			int[][] matrix = new int[neighMatrix.length][neighMatrix.length];
			try
			{
				Class.forName("com.mysql.jdbc.Driver");
				Connection con;
				con = DriverManager.getConnection("jdbc:mysql://localhost/crimeminer","root","admin");
				Statement state = con.createStatement();
				
				//show the cliend data in table
				int eFrom=0, eTo=0, weight=0;
				
				String query = "select * from relation";
				ResultSet rsQuery = state.executeQuery(query);
				
				if(!rsQuery.next())
				{
					System.out.println("there is no record");
					return;
				}
				else 
				{
					do
					{
						eFrom = rsQuery.getInt(1);
						eTo = rsQuery.getInt(2);
						for (int i=0; i<neighMatrix.length; i++)
						{
							for (int j=0; j<neighMatrix.length; j++)
							{
								if (i==eFrom && j==eTo)
								{
									matrix[i][j] = rsQuery.getInt(3);
								}
							}
						}
						
					}
					while(rsQuery.next());
					rsQuery.close();
				}
				con.close();
			}
			catch (Exception error)
			{
				error.printStackTrace();
			}
			
			SNAShow graph = new SNAShow(matrix, lable);
			graph.setVisible(true);
			graph.toFront();
			}
		});
		
		button_4.setText("����������֯ͼ");
		button_4.setBounds(22, 470, 187, 27);

		final CLabel label_6 = new CLabel(shell, SWT.NONE);
		label_6.setBackground(Display.getCurrent().getSystemColor(SWT.COLOR_WHITE));
		label_6.setText("��Ϊģʽ����");
		label_6.setBounds(460, 65, 114, 23);

		final Button button_5 = new Button(shell, SWT.NONE);
		button_5.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(final SelectionEvent e) {
				CharacterSet s = new CharacterSet(shell, 1);
				s.open();
				
			}
		});
		button_5.setText("�༭��Ϊģʽ����");
		button_5.setBounds(460, 148, 136, 27);

		final Button button_6 = new Button(shell, SWT.NONE);

		button_6.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(final SelectionEvent e) {
				try 
				{
					//String path = ".\\tq\\tq.jar";
//					String path="src/crimeminer/qiao/tq/tq.jar";
					String path="tq/tq.jar";
					//Process ts = Runtime.getRuntime().exec("cmd /c start java -Dsun.java2d.noddraw=true -jar \"" + path + "\"" + " -d0");
					Process ts = Runtime.getRuntime().exec("cmd /c start " + path + "\"");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				//String path = "c:\\test.xls";
				//Process ts = Runtime.getRuntime().exec("cmd   /c   start   excel     \""   +   path   +   "\""); 
				}
		});
		button_6.setText("�շ��ʼ�ʱ�����");
		button_6.setBounds(455, 470, 144, 27);

		final Label label_5 = new Label(shell, SWT.NONE);
		label_5.setBackground(Display.getCurrent().getSystemColor(SWT.COLOR_WHITE));
		label_5.setText("ͨ�Ŵ���");
		label_5.setBounds(103, 390, 67, 17);

		text_1 = new Text(shell, SWT.BORDER);
		text_1.setBounds(176, 387, 80, 25);

		final Button button_4_1 = new Button(shell, SWT.NONE);
		button_4_1.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(final SelectionEvent e) {
				DegreeShow core = new DegreeShow(shell, 1);
				core.open();
			}
		});
		button_4_1.setBounds(228, 470, 187, 27);
		button_4_1.setText("���Һ��Ľ��");

		final Button button_7 = new Button(shell, SWT.NONE);
		button_7.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(final SelectionEvent e) {
				SetValue window = new SetValue();
				window.open();
			}
		});
		button_7.setText("��������Ȩ�ؼ���");
		button_7.setBounds(460, 95, 140, 27);
		//
	}
	
}
