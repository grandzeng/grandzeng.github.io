DROP TABLE IF EXISTS degree;
CREATE TABLE degree(
node int,
degree int,
betweeness int,
closeness int
);
