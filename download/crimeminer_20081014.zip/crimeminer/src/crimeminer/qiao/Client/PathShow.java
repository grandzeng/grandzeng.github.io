package crimeminer.qiao.Client;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class PathShow extends Dialog {

	private Text text;
	protected Object result;

	protected Shell shell;

	/**
	 * Create the dialog
	 * @param parent
	 * @param style
	 */
	public PathShow(Shell parent, int style) {
		super(parent, style);
	}

	/**
	 * Create the dialog
	 * @param parent
	 */
	public PathShow(Shell parent) {
		this(parent, SWT.NONE);
	}

	/**
	 * Open the dialog
	 * @return the result
	 */
	public static void main(String args[])
	{
		Shell shell = new Shell();
		PathShow s = new PathShow(shell, 1);
		s.open();
	}
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
			
		}
		return result;
	}

	/**
	 * Create contents of the dialog
	 */
	protected void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL);
		shell.setSize(500, 403);
		shell.setText("SWT Dialog");

		text = new Text(shell, SWT.BORDER);
		try{
		BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(".\\path.txt")));
		String temp = in.readLine();
		String str = new String();
		while(temp != null)
		{
			str +=temp;
			temp = in.readLine();
		}
		text.setText(str);
		in.close();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		text.setBounds(45, 32, 406, 276);

		final Label label = new Label(shell, SWT.NONE);
		label.setText("���·�����");
		label.setBounds(45, 9, 131, 17);

		final Button button = new Button(shell, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(final SelectionEvent e) {
				shell.close();
				//return;
			}
		});
		button.setText("�˳�");
		button.setBounds(220, 328, 54, 27);
		//
	}

}
