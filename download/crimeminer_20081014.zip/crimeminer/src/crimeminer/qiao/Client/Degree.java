package crimeminer.qiao.Client;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Date;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.TableItem;

public class Degree {
	
	int[][] matrix;
	
	public Degree(int[][] mtr)
	{
		matrix = new int[mtr.length][mtr.length];
		for (int i=0; i<mtr.length; i++)
		{
			for (int j=0; j<mtr.length; j++)
			{
				matrix[i][j] = mtr[i][j];
			}
		}
	}
	
	public void ComputeDegree() 
	{
		int k=0;
		int w=0;
		int vexn=matrix.length;

		
		int m[][]=new int[vexn][vexn];
		for (int i=0; i<vexn ; i++)
		{
			for (int j=0;j<vexn;j++)
			{
				if (matrix[i][j]!=0)
				{
					m[i][j]=matrix[i][j];
				}
				else
				{
				m[i][j]=3266;
				}
			}
		}
		
		Date date = new Date();
		long time1=date.getTime();
		System.out.print("time1: ");
		System.out.println(time1);

		int degree[]=new int[vexn];
		for(int ii=0;ii<vexn;ii++)
		{
			for(int jj=0;jj<vexn;jj++)
			{
				if (m[ii][jj]<3266)
					degree[ii]+=1;
			}
		}
		
		int dist[]=new int[vexn];
		int path[]=new int[vexn];
		int v0;
		int ss[]=new int[vexn];
		int u,vnum,wm;
		int closness[]=new int[vexn];
	
		int geocide[]=new int[vexn];
		int genum=0;
		
		try
		{
		PrintWriter out=new PrintWriter(new OutputStreamWriter(new FileOutputStream(".\\path.txt")));
		for(int x=0;x<vexn;x++)
		{
			for(int cc=0;cc<vexn;cc++)
			{
				path[cc]=0;
				dist[cc]=0;
				ss[cc]=0;
			}
			v0=x;
			u=0;
			vnum=0;
			wm=0;
			for (w=0;w<vexn;w++)
			{
				dist[w]=m[v0][w];
				if ((m[v0][w]<3266) ) 
				{
					path[w]=v0;
				}
			}
			for(w=0;w<vexn;w++)
			{
				ss[w]=0;
			}
			
			ss[v0]=1;
			vnum=1;
			while(vnum<vexn)
			{
				wm=3266;
				u=v0;
				for(w=0;w<vexn;w++)
				{
					if (ss[w]==0 && dist[w]<wm)
					{
						u=w;
						wm=dist[w];
					}
				}
				ss[u]=1;
				vnum++;
				
				for(w=0;w<vexn;w++)
				{
					if (ss[w]==0 && dist[u]+m[u][w]<dist[w])
					{
						dist[w]=dist[u]+m[u][w];
						path[w]=u;
					}
				}
			}
			
				
			out.print("From node "+x+"\'s shorest path:  ");
				
			for (int i=0; i<vexn; i++)
			{
				
				if(dist[i]==3266)
				{
					System.out.print(0);
					System.out.print('\t');
					out.print(0);
					out.print("  ");
				}
				else
				{
				System.out.print(dist[i]);
				System.out.print('\t');
				out.print(dist[i]);
				out.print("  ");
				}
			}
			System.out.println();
			out.println();
			
			int a=0;
			int firstnode=0;
		                 
			for(int i=0;i<vexn;i++)
			{
				a=0;
				if (ss[i]==1)
				{
					k=i;
					while(k!=v0)
					{
						a+=1;
						if (a==1) 
						{
							firstnode=k;
						}
						genum=k;
						if (v0<firstnode &&a>1)
						{
							geocide[genum]+=1;
						}
						k=path[k];//���ζ���ǰ��ڵ��1����Ϊ������ǰ��ڵ㵽��һ���ڵ㹹��һ�����·��
					}
				}
				closness[v0]+=dist[i]; //closeness equals the sum of shortest paths
			}
		}
		out.flush();
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
		
		int max=0;
		int leader=0;
		int score[]=new int[vexn];
		
		try {	
			Class.forName("com.mysql.jdbc.Driver");
			Connection con;
			con = DriverManager.getConnection("jdbc:mysql://localhost/crimeminer","root","admin");
			Statement state = con.createStatement();
		
			String delete = "delete from degree";
			state.execute(delete);
			
			state.close();
			con.close();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		for(int xx=0;xx<vexn;xx++)
		{
			
			System.out.print("node "+xx);
			System.out.print("\t betweenness:"+geocide[xx]);
			System.out.print("\t degree:"+degree[xx]);
			System.out.print("\t closeness:"+closness[xx]);
			System.out.println();
			int nodeId = xx;
			int nodeDegree = degree[xx];
			int nodeBetweeness = geocide[xx];
			int nodeCloseness = closness[xx];
			
			//insert the degrees into a table
			try {	
				Class.forName("com.mysql.jdbc.Driver");
				Connection con;
				con = DriverManager.getConnection("jdbc:mysql://localhost/crimeminer","root","admin");
				Statement state = con.createStatement();
				String addNode = "insert into degree values(" + nodeId 
				+ "," + nodeDegree + "," + nodeBetweeness + "," + nodeCloseness + ")";
				state.executeUpdate(addNode);
					
				state.close();
				con.close();
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
			
			closness[xx]=3266*vexn-closness[xx];
			score[xx]=geocide[xx]+degree[xx]+closness[xx]/3266;
			if (geocide[xx]+closness[xx]/3266+degree[xx]>max)
			{
				max=geocide[xx]+closness[xx]/3266+degree[xx];
				leader=xx;
			}

		}
		
		System.out.println("the leader is node :"+leader);
		Date date1 = new Date();
		long time2=date1.getTime();
		System.out.print("time2: ");
		System.out.println(time2);
		
		long time=time1-time2;
		System.out.print("the time span is: ");
		System.out.println(time);

	}
}
