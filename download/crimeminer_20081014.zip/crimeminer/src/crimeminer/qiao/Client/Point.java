package crimeminer.qiao.Client;

public class Point {
	double x;
	double y;
	int id;
	String label;
	public Point(double x1, double y1, String label1)
	{
		//id = id1;
		x = x1;
		y = y1;
		label = label1;
	}
	public void print()
	{
		System.out.println(label);
	}

}
