package crimeminer.qiao.Client;

//import java.awt.EventQueue;
import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Label;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import java.awt.Frame;
import java.io.FileNotFoundException;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import crimeminer.qiao.com.swtdesigner.SWTResourceManager;

public class SNAShow extends JFrame{
	
	public int[][] matrix;
	public String[] email;
	protected Shell shell;

	public SNAShow(int[][] neighbor, String[] lable) {
		super();
		shell = new Shell();
		matrix = new int[neighbor.length][neighbor.length];
		email = new String[neighbor.length];
		for (int i=0; i<matrix.length; i++)
		{
			for (int j=0; j<matrix.length; j++)
			
			{
				matrix[i][j]=neighbor[i][j];
				System.out.print(matrix[i][j]);
				System.out.print('\t');
			}
			System.out.println();
			email[i] = lable[i];
		}
		
		setBounds(100, 100, 611, 586);
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		final JButton button = new JButton();
		button.addMouseListener(new MouseAdapter() {
			public void mouseClicked(final MouseEvent arg0) {
				/*ShortestPath spath = new ShortestPath(matrix);
				int start = 0;
				spath.ComputePath(start);*/
				Degree test = new Degree(matrix);
				test.ComputeDegree();
				try{
				Path p = new Path();
				p.run();
				setVisible(false);
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
		});
		button.setText("�������·��");
		getContentPane().add(button, BorderLayout.SOUTH);
		//
	}
	
	public void paint (Graphics g) 
	{
		super.paint(g);
		Insets insets = getInsets();
		
		int x = 100, y = 100;
		g.drawOval(x,y,400,400);
		
		int pointNo = matrix.length;
		Point[] p = new Point[matrix.length];
		int radius = 10;
	
		for(int i=0; i<pointNo; i++)
		{ 
			int a = x+200+(int)(200*Math.cos(2*Math.PI/pointNo*i))-radius;
			int b = y+200+(int)(200*Math.sin(2*Math.PI/pointNo*i))-radius;
			p[i] = new Point(a,b, email[i]);
			//p[i].print();
			g.drawOval(a,b,2*radius,2*radius);
			g.drawString(email[i], a-60, b);
						
		}
		for (int i=0; i<pointNo; i++)
		{
			for (int j=0; j<pointNo; j++)
			{
				if (matrix[i][j]!=0)
				{
					g.drawLine((int)p[i].x+radius, (int)p[i].y+radius, (int)p[j].x+radius, (int)p[j].y+radius);
					g.drawString(String.valueOf(matrix[i][j]), ((int)p[i].x+radius+(int)p[j].x+radius)/2, ((int)p[i].y+radius+(int)p[j].y+radius)/2);
				}
			}
		}
	}
	public void print()
	{
		for (int i=0; i<matrix.length; i++)
		{
			for (int j=0; j<matrix.length; j++)
			
			{
				System.out.print(matrix[i][j]);
				System.out.print('\t');
			}
			System.out.println();
		}
	}
	
	public void repaint(Graphics g)
	{
		paint(g);
	}
	
	public void update (Graphics g)
	{
		paint(g);
	}

}
