package crimeminer.ui.component.explorer;

import crimeminer.mining.*;
import crimeminer.ui.*;
import crimeminer.ui.component.CMMenuBar;
import crimeminer.ui.component.CMToolBar;

import javax.swing.ImageIcon;
import javax.swing.JTree;
import javax.swing.tree.*;
import java.awt.event.*;
import java.net.MalformedURLException;

public class CMTree extends JTree {

	public CMTree(CMNode root) {
		super();
		putClientProperty("JTree.lineStyle", "Angled");
		DefaultTreeModel model = new DefaultTreeModel(root);
		setModel(model);
		DefaultTreeCellRenderer dtcr = (DefaultTreeCellRenderer)getCellRenderer();
		ImageIcon leaf = new ImageIcon("image/leaf.gif");
		ImageIcon open = new ImageIcon("image/open.gif");
		ImageIcon close = new ImageIcon("image/close.gif");
		dtcr.setLeafIcon(leaf);
		dtcr.setOpenIcon(open);
		dtcr.setClosedIcon(close);
		this.addMouseListener(new MouseOnTree());
	}

	class MouseOnTree extends MouseAdapter {
		public void mouseClicked(MouseEvent evt) {
			if (evt.getClickCount() == 2) {
				TreePath path = CMTree.this.getPathForLocation(evt.getX(), evt
						.getY());
				if (path != null) {
					CMNode node = (CMNode) path.getLastPathComponent();
					if (node.isLeaf()) {
						Handler handler = node.getHandler();
						try {
							String className = handler.getClassName();
							String jarName = handler.getJarName();
							if(className.trim().equals("null"))
								return;
							Class c = CrimeMiner.m_globalManager.getCache()
									.getClass(className,jarName);
							Operator op =(Operator)c.newInstance();
							op.run();
							CMMenuBar bar=CrimeMiner.m_globalManager.getMenuBar();
							bar.addDynamicMenu(handler.getMenu());
							CMToolBar tbar = CrimeMiner.m_globalManager.getToolBar();
							tbar.setDynamicBar(handler.getToolbar());
						} catch (ClassNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (InstantiationException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IllegalAccessException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (MalformedURLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}
		}
	}
}
