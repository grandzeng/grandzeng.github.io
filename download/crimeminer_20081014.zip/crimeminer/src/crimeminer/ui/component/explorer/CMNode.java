package crimeminer.ui.component.explorer;

import javax.swing.tree.DefaultMutableTreeNode;
import crimeminer.mining.*;
public class CMNode extends DefaultMutableTreeNode {

	private static final long serialVersionUID = -8539336677018391322L;
	
	private String m_name;
	
	private boolean m_isLeaf;
	
	private Handler m_handler;
	
	public CMNode(){
	
	}
		
	public CMNode(String name, boolean leaf){
		m_name = name;
		m_isLeaf = leaf;
	}
	
	public CMNode(String name){
		m_name =name;
		m_isLeaf = false;
	}
	
	public String getName(){
		return m_name;
	}
	
	
	public void setName(String name){
		m_name = name;
	}
	
	public Handler getHandler(){
		return m_handler;
	}
	
	public void setHandler(Handler h){
		m_handler =h;
	}
		
	public boolean isLeaf(){
		return m_isLeaf;
	}
	
	public boolean getAllowsChildren(){
		return m_isLeaf;
	}
	
	public String toString(){
		return m_name;
	}
	
}
