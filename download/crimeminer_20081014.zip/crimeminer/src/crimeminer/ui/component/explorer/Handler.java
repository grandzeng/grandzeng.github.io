/**
 * 
 */
package crimeminer.ui.component.explorer;

import crimeminer.core.*;
import crimeminer.ui.component.menu.*;
import crimeminer.ui.component.toolbar.*;
import crimeminer.ui.component.*;

/**
 * @author grand
 * 
 */
public class Handler {

	private String name;

	private String className;
	
	private String jarName;
	
	private CMMenu menu;

	private CMToolBar toolbar;

	public Handler() {
	}

	public Handler(String name,String className,String jar,CMMenu menu,CMToolBar toolbar){
		this.name=name;
		this.menu = menu;
		this.className = className;
		this.jarName = jar;
		this.toolbar = toolbar;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		name = name;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public void setJarName(String jar){
		jarName = jar;
	}
	
	public String getJarName(){
		return jarName;
	}
	
	public CMMenu getMenu() {
		return menu;
	}

	public void setMenu(CMMenu m) {
		menu = m;
	}

	public CMToolBar getToolbar() {
		return toolbar;
	}

	public void setToolbar(CMToolBar toolbar) {
		this.toolbar = toolbar;
	}
	
	
}
