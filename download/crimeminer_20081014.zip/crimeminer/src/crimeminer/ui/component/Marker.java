package crimeminer.ui.component;

import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;

import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JPanel;

public class Marker extends JTabbedPane {

	private static final long serialVersionUID = 8788099639409986858L;

	private JTextArea area = new JTextArea();

	public Marker() {
		JScrollPane pane = new JScrollPane(area);
		addTab("Marker", pane);
		area.setEditable(false);
	}

	public void log(String mes) {
		StringBuffer sb = new StringBuffer();
		sb.append(header() + mes + "\n");
		area.append(sb.toString());
		area.setCaretPosition(area.getText().length());
		
	}

	public String header() {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
		Date date = new Date();
		String time = format.format(date);
		return "[" + time + "]::>";
	}
}
