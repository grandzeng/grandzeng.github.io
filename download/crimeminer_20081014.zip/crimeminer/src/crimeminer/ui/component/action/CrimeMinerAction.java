package crimeminer.ui.component.action;

import java.awt.event.ActionEvent;
import java.net.MalformedURLException;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;

import crimeminer.mining.Operator;
import crimeminer.ui.CrimeMiner;

public class CrimeMinerAction extends AbstractAction {

	private String class_name;
	private String jar_name;
	
	public CrimeMinerAction(String name, String iconName, char mnemonic,
			String shortdes, String longdes, String className,String jar) {
		putValue(NAME, name);
		if (!iconName.equals("null")) {
			ImageIcon icon = new ImageIcon(iconName);
			putValue(SMALL_ICON, icon);
		}
		putValue(MNEMONIC_KEY, new Integer(mnemonic));
		putValue(SHORT_DESCRIPTION, shortdes);
		putValue(LONG_DESCRIPTION, longdes);
		class_name = className;
		jar_name = jar;
	}

	public CrimeMinerAction(String name, String iconName, String className,String jar) {
		putValue(NAME, name);
		putValue(SHORT_DESCRIPTION, name);
		if (!iconName.equals("null")) {
			ImageIcon icon = new ImageIcon(iconName);
			putValue(SMALL_ICON, icon);
		}
		class_name =className;
		jar_name = jar;
	}
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (class_name == null ||class_name.trim().equals("null"))
			return;
		Class c;
		try {
			c = CrimeMiner.m_globalManager.getCache().getClass(class_name,jar_name);
			Operator op = (Operator) c.newInstance();
			op.run();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (InstantiationException ec) {
			// TODO Auto-generated catch block
			ec.printStackTrace();
		} catch (IllegalAccessException et) {
			// TODO Auto-generated catch block
			et.printStackTrace();
		} catch (MalformedURLException em) {
			// TODO Auto-generated catch block
			em.printStackTrace();
		}
	}

}
