package crimeminer.ui.component;

import javax.swing.JMenuBar;
import javax.swing.*;
import java.util.*;
import crimeminer.ui.component.menu.*;

public class CMMenuBar extends JMenuBar {

	private static final long serialVersionUID = -4196645041678964655L;

	private ArrayList<CMMenu> m_DynamicMenuList = new ArrayList<CMMenu>();

	private JMenu actionMenu = new JMenu("Action");

	public void addDynamicMenu(CMMenu c) {
		m_DynamicMenuList.clear();
		if (c != null)
			m_DynamicMenuList.add(c);

		updateDynamicMenu();
	}

	public void resetDynamicMenu() {
		m_DynamicMenuList.clear();
		updateDynamicMenu();
	}

	public void updateDynamicMenu() {
		this.remove(actionMenu);
		if (m_DynamicMenuList.isEmpty()) {
			actionMenu.removeAll();
			this.remove(actionMenu);
		} else {

			actionMenu.removeAll();
			for (int i = 0; i < m_DynamicMenuList.size(); i++) {
				actionMenu.add(m_DynamicMenuList.get(i));
			}
			this.add(actionMenu);
		}

		this.updateUI();
	}

	public CMMenu getDynamicMenu(int index) {
		return m_DynamicMenuList.get(index);
	}

	// public JMenu programMenu=new JMenu("Program");

	// public JMenuItem exitMenuItem=new JMenuItem("Exit");

	public CMMenuBar() {
		// programMenu.add(exitMenuItem);
		// programMenu.setMnemonic('P');
		// exitMenuItem.setMnemonic('E');
		// add(programMenu);
		// this.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
	}
}
