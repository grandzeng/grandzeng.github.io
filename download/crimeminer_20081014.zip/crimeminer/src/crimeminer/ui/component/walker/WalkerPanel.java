package crimeminer.ui.component.walker;

import javax.swing.JPanel;


/**
 * This class will be completed later
 * */
public class WalkerPanel extends JPanel {
	
	private String title = "";
	
	public WalkerPanel(){
		
	}
	
	public String getTitle(){
		return title;
	}
	
	public void setTitle(){}
	
}
