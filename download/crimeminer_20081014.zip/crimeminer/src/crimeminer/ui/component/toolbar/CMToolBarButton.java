package crimeminer.ui.component.toolbar;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;

import javax.swing.JButton;

import crimeminer.mining.Operator;
import crimeminer.ui.CrimeMiner;
import crimeminer.ui.component.action.CrimeMinerAction;

public class CMToolBarButton extends JButton {

	private static final long serialVersionUID = -4577291707587143477L;
	
	private String m_className;
	
	private String m_jarName;
	
	private String m_IconName;
	
	public CMToolBarButton(CrimeMinerAction action){
		super(action);
	}
	
	public CMToolBarButton(){
		this.addActionListener(new ButtonAction());
	}
	
	public CMToolBarButton(String name){
		super(name);
		this.addActionListener(new ButtonAction());
	}
	
	public CMToolBarButton(String name, String className){
		super(name);
		m_className = className;
		m_jarName = null;
		this.addActionListener(new ButtonAction());
	}
	
	public CMToolBarButton(String name,String className,String jar,String icon){
		super(name);
		m_className =className;
		m_jarName = jar;
		m_IconName = icon;
		this.addActionListener(new ButtonAction());
	}
	
	public void setClassName(String className){
		m_className = className;
	}
	
	public String getClassName(){
		return m_className;
	}
	
	public String getIconName(){
		return m_IconName;
	}
	
	public void setJarName(String jar){
		m_jarName = jar;
	}
	
	public String getJarName(){
		return m_jarName;
	}
	
	public void setIconName(String icon){
		m_IconName = icon;
	}
	
	class ButtonAction implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			String className = getClassName();
			if(className.trim().equals("null"))
				return;
			Class c;
			try {
				c = CrimeMiner.m_globalManager.getCache()
						.getClass(className,m_jarName);
				Operator op =(Operator)c.newInstance();
				op.run();
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (InstantiationException ec) {
				// TODO Auto-generated catch block
				ec.printStackTrace();
			} catch (IllegalAccessException et) {
				// TODO Auto-generated catch block
				et.printStackTrace();
			} catch (MalformedURLException em) {
				// TODO Auto-generated catch block
				em.printStackTrace();
			}
			
		}
		
	}
	
}
