package crimeminer.ui.component;

import javax.swing.JTabbedPane;
import javax.swing.JPanel;
import java.awt.*;
import javax.swing.JTree;
import javax.swing.JScrollPane;
import crimeminer.ui.component.explorer.*;
import javax.swing.tree.*;
import javax.swing.event.*;
public class Explorer extends JTabbedPane {

	private static final long serialVersionUID = -4245015223864928147L;

//	private JPanel panel = new JPanel();
	
//	private JTree tree = new JTree();
	public Explorer(CMTree tree) {
//		String values[]={"association","classification","cluster","SNA"};
//		JTree tree = new JTree(values);
		tree.setRootVisible(true);
		JScrollPane pane =new JScrollPane(tree);
		
		pane.setBackground(Color.WHITE);
//		pane.setLayout(new BorderLayout());
		this.addTab("Explorer", pane);
		
	
	}
	public Explorer() {
		/*
		String values[]={"association","classification","cluster","SNA","USER"};
		JTree tree = new JTree(values);
		tree.setRootVisible(true);
		//
		DefaultMutableTreeNode top = new DefaultMutableTreeNode(getString("TreeDemo.music")); 
        DefaultMutableTreeNode catagory = null ; 
		*/
		DefaultMutableTreeNode top = new DefaultMutableTreeNode("CrimerMiner"); 
		DefaultMutableTreeNode association = new DefaultMutableTreeNode("association");
		DefaultMutableTreeNode classification = new DefaultMutableTreeNode("classification");
		DefaultMutableTreeNode cluster = new DefaultMutableTreeNode("cluster");
		DefaultMutableTreeNode SNA = new DefaultMutableTreeNode("SNA");
		DefaultMutableTreeNode user = new DefaultMutableTreeNode("User");
		DefaultMutableTreeNode addUser = new DefaultMutableTreeNode("addUser");
		DefaultMutableTreeNode exit = new DefaultMutableTreeNode("exit");
		
		user.add(addUser);
		top.add(association);
		top.add(classification);
		top.add(cluster);
		top.add(SNA);
		top.add(user);
		top.add(exit);
		
		//
		final JTree tree = new JTree(top);
		tree.addTreeSelectionListener(
			new TreeSelectionListener(){
				public void valueChanged(TreeSelectionEvent evnet){
					DefaultMutableTreeNode node = (DefaultMutableTreeNode)tree.getLastSelectedPathComponent();
				if(node == null)
					return ;
				Object nodeInfo = node.getUserObject();
				String nodeName = (String)nodeInfo;
				if(nodeName.equalsIgnoreCase("user")){
					System.out.println("user manager");
				}
				//System.out.println(str);
				}
			});
		//
		JScrollPane pane =new JScrollPane(tree);
		pane.setBackground(Color.WHITE);
      //pane.setLayout(new BorderLayout());
		this.addTab("Explorer", pane);
	}
}
