package crimeminer.ui.component;

import javax.swing.*;
import crimeminer.ui.component.toolbar.*;
import java.util.*;
import crimeminer.ui.component.action.*;

public class CMToolBar extends JToolBar {

	private static final long serialVersionUID = 1240257383047348042L;

	private CMToolBar m_DynamicBar = null;

	// private JButton OpenButton=new JButton("Open");

	// private JButton SaveButton = new JButton("Save");

	// private JButton ExitButton = new JButton("Exit");

	public CMToolBar() {
		// add(OpenButton);
		// add(SaveButton);
		// add(ExitButton);
		// this.setBorder(new EtchedBorder());
		// CrimeMinerAction action = new CrimeMinerAction("help",
		// "image/logo.gif",'H',"short","long", "crimeminer.mining.zeng.Help");
		// this.add(action);
	}

	public void setDynamicBar(CMToolBar bar) {
		if (m_DynamicBar != null)
			this.remove(m_DynamicBar);
		m_DynamicBar = bar;
		if (m_DynamicBar == null)
			return;
		else {
			this.add(m_DynamicBar);
			this.updateUI();
		}
	}

	public void resetDynamicBar() {
		this.remove(m_DynamicBar);
		m_DynamicBar = null;
		this.updateUI();
	}
}
