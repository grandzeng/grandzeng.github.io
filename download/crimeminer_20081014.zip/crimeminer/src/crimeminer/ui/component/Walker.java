package crimeminer.ui.component;

import javax.print.DocFlavor.URL;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTabbedPane;
import java.awt.*;
import javax.swing.JPanel;

public class Walker extends JTabbedPane {

	private static final long serialVersionUID = 1869465159180488578L;

	private JPanel panel = new JPanel();

	public Walker() {
		panel.setBackground(Color.WHITE);
		java.net.URL imageURL = this.getClass().getResource("image/bg.jpg");

		ImageIcon icon = new ImageIcon(imageURL);
		JLabel label = new JLabel(icon) {
			protected void paintComponent(Graphics g) {
				super.paintComponent(g);
				g.drawImage(((ImageIcon) getIcon()).getImage(), 0, 0,
						getWidth(), getHeight(), null);
			}
		};

		panel.setLayout(new BorderLayout());
		panel.add(label, BorderLayout.CENTER);
		this.addTab("Walker", panel);
	}
}
