package crimeminer.ui.component.menu;

import javax.swing.ImageIcon;
import javax.swing.JMenuItem;

import crimeminer.mining.Operator;
import crimeminer.ui.CrimeMiner;
import crimeminer.ui.component.action.CrimeMinerAction;

import java.awt.event.*;
import java.net.MalformedURLException;

public class CMMenuItem extends JMenuItem {

	private static final long serialVersionUID = -7803779453232459074L;

	private String m_className;
	
	private String m_jarName;
	
	private String m_IconName;

	public CMMenuItem() {
		this.addActionListener(new MenuItemAction());
	}
	
	public CMMenuItem(CrimeMinerAction action){
		super(action);
	}
	
	public CMMenuItem(String name) {
		super(name);
		m_className = null;
		m_jarName = null;
		this.addActionListener(new MenuItemAction());
	}

	public CMMenuItem(String name, String className) {
		super(name);
		m_className = className;
		m_jarName = null;
		this.addActionListener(new MenuItemAction());
	}

	public CMMenuItem(String name, String className, String jar,String Icon) {
		super(name);
		m_className = className;
		m_jarName = jar;
		m_IconName = Icon;
		if (!m_IconName.equals("null")) {
			ImageIcon icon = new ImageIcon(m_IconName);
			this.setIcon(icon);
		}
		this.addActionListener(new MenuItemAction());
	}

	public String getClassName() {
		return m_className;
	}

	public void setClassName(String className) {
		m_className = className;
	}

	public void setJarName(String jar){
		m_jarName = jar;
	}
	
	public String getJarName (){
		return m_jarName;
	}
	
	public String getIconName() {
		return m_IconName;
	}

	public void setIconName(String icon) {
		m_IconName = icon;
	}

	class MenuItemAction implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			String className = getClassName();
			if (className.trim().equals("null"))
				return;
			Class c;
			try {
				c = CrimeMiner.m_globalManager.getCache().getClass(className,m_jarName);
				Operator op = (Operator) c.newInstance();
				op.run();
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (InstantiationException ec) {
				// TODO Auto-generated catch block
				ec.printStackTrace();
			} catch (IllegalAccessException et) {
				// TODO Auto-generated catch block
				et.printStackTrace();
			} catch (MalformedURLException em) {
				// TODO Auto-generated catch block
				em.printStackTrace();
			}

		}

	}
}
