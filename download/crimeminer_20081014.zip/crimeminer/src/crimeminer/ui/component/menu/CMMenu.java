package crimeminer.ui.component.menu;

import javax.swing.JMenu;
import java.util.*;


public class CMMenu extends JMenu {

	private static final long serialVersionUID = -2088794008134967199L;

	private ArrayList<CMMenuItem> m_ItemList = new ArrayList<CMMenuItem>();
	
	
	private String m_iconName;
	
	public CMMenu(){}
	
	public CMMenu(String name){
		super(name);
	}


	public String getIconName() {
		return m_iconName;
	}

	public void setM_iconName(String iconName) {
		m_iconName = iconName;
	
	}
	
}
