package crimeminer.ui.parser;

import org.jdom.*;
import org.jdom.input.*;
import org.jdom.output.*;
import java.io.*;

import crimeminer.ui.component.*;
import crimeminer.ui.component.menu.*;
import crimeminer.ui.component.toolbar.*;
import crimeminer.ui.component.explorer.*;
import crimeminer.ui.component.walker.*;
import java.util.*;
import crimeminer.ui.component.action.*;
import crimeminer.ui.exception.*;

public class UIParser {

	private String m_UIFileName = "crimeminer.xml";

	private Document m_Doc = null;

	public UIParser() throws JDOMException, IOException {
		initDoc();
	}

	public void setUIFileName(String fileName) {
		m_UIFileName = fileName;
	}

	public String getUIFileName() {
		return m_UIFileName;
	}

	public Document getDoc() {
		return m_Doc;
	}

	public void initDoc() throws JDOMException, IOException {
		File ui = new File(m_UIFileName);
		SAXBuilder builder = new SAXBuilder();
		m_Doc = builder.build(ui);

	}

	public String getExtensionLibrary() throws UIParserInitException,
			UIParserException {
		if (m_Doc == null)
			throw new UIParserInitException();
		Element extension = m_Doc.getRootElement()
				.getChild("extension-library");
		if (extension == null)
			throw new UIParserException(
					"there should be a extension-library element in file:"
							+ m_UIFileName);
		String dir = extension.getText().trim();
		return dir;
	}

	public ArrayList<CMMenu> getAllMenus() throws UIParserInitException,
			UIParserException {
		if (m_Doc == null)
			throw new UIParserInitException();

		ArrayList<CMMenu> menuList = new ArrayList<CMMenu>();

		Element mainMenu = m_Doc.getRootElement().getChild("mainMenu");
		List childern = mainMenu.getChildren();
		Iterator iter = childern.iterator();
		while (iter.hasNext()) {
			Element ele = (Element) iter.next();
			CMMenu menu = constructMenu(ele);

			if (menu != null)
				menuList.add(menu);
		}

		return menuList;
	}

	private CMMenu constructMenu(Element menu) throws UIParserException {

		String name = menu.getName();
		if (!name.equals("menu"))
			throw new UIParserException("This is not a menu, it is called: "
					+ name);
		String text = menu.getAttributeValue("name");
		CMMenu cmmenu = new CMMenu(text);

		List childern = menu.getChildren();

		Iterator iter = childern.iterator();
		while (iter.hasNext()) {
			Element ele = (Element) iter.next();
			if (ele.getName().equals("menuItem")) {
				String itemText = ele.getAttributeValue("name");
				String jarName = ele.getAttributeValue("jar");
				String className = ele.getAttributeValue("class");
				String icon = ele.getAttributeValue("icon");
				CrimeMinerAction action = new CrimeMinerAction(itemText, icon,
						className,jarName);
//				 CMMenuItem menuItem = new CMMenuItem(itemText,
//				 className,jarName,icon);
				CMMenuItem menuItem = new CMMenuItem(action);
				cmmenu.add(menuItem);
			} else {
				CMMenu sonMenu = constructMenu(ele);
				if (sonMenu != null)
					cmmenu.add(sonMenu);
			}
		}
		return cmmenu;
	}

	public ArrayList<CMToolBarButton> getAllToolBarButton()
			throws UIParserInitException, UIParserException {
		if (m_Doc == null)
			throw new UIParserInitException();
		Element toolbar = m_Doc.getRootElement().getChild("mainToolbar");
		ArrayList<CMToolBarButton> toolBarButtonList;
		if (toolbar == null)
			return new ArrayList<CMToolBarButton>();
		toolBarButtonList = constructButtonList(toolbar);
		return toolBarButtonList;
	}

	public ArrayList<CrimeMinerAction> getAllToolBarAction()
			throws UIParserInitException, UIParserException {
		if (m_Doc == null)
			throw new UIParserInitException();
		Element toolbar = m_Doc.getRootElement().getChild("mainToolbar");
		ArrayList<CrimeMinerAction> toolBarActionList;
		if (toolbar == null)
			return new ArrayList<CrimeMinerAction>();
		toolBarActionList = constructActionList(toolbar);
		return toolBarActionList;
	}

	private ArrayList<CrimeMinerAction> constructActionList(Element toolbar)
			throws UIParserException {
		String Name = toolbar.getName();
		if (!Name.equals("mainToolbar"))
			throw new UIParserException("This is not a toolbar, it is called: "
					+ Name);
		ArrayList<CrimeMinerAction> toolBarActionList = new ArrayList<CrimeMinerAction>();
		List children = toolbar.getChildren();
		Iterator iter = children.iterator();
		while (iter.hasNext()) {
			Element ele = (Element) iter.next();
			String name = ele.getName();
			if (!name.equals("button"))
				throw new UIParserException(
						"This is not a button, but it is called: " + name);

			String text = ele.getAttributeValue("name");
			String className = ele.getAttributeValue("class");
			String jarName = ele.getAttributeValue("jar");
			String icon = ele.getAttributeValue("icon");
			CrimeMinerAction action = new CrimeMinerAction(text, icon,
					className,jarName);
			toolBarActionList.add(action);

		}
		return toolBarActionList;

	}

	private ArrayList<CMToolBarButton> constructButtonList(Element toolbar)
			throws UIParserException {
		String Name = toolbar.getName();
		if (!Name.equals("mainToolbar"))
			throw new UIParserException("This is not a toolbar, it is called: "
					+ Name);
		ArrayList<CMToolBarButton> toolBarButtonList = new ArrayList<CMToolBarButton>();
		List children = toolbar.getChildren();
		Iterator iter = children.iterator();
		while (iter.hasNext()) {
			Element ele = (Element) iter.next();
			String name = ele.getName();
			if (!name.equals("button"))
				throw new UIParserException(
						"This is not a button, but it is called: " + name);

			String text = ele.getAttributeValue("name");
			String className = ele.getAttributeValue("class");
			String jarName = ele.getAttributeValue("jar");
			String icon = ele.getAttributeValue("icon");
			CrimeMinerAction action = new CrimeMinerAction(text, icon,
					className,jarName);
//			 CMToolBarButton button = new CMToolBarButton(text,
//			 className,jarName,icon);
			CMToolBarButton button = new CMToolBarButton(action);

			toolBarButtonList.add(button);

		}
		return toolBarButtonList;

	}

	public CMNode getExplorerRoot() throws UIParserInitException,
			UIParserException {
		if (m_Doc == null)
			throw new UIParserInitException();

		Element explorer = m_Doc.getRootElement().getChild("explorer");
		CMNode root = new CMNode(explorer.getAttributeValue("name"), false);

		List children = explorer.getChildren();
		Iterator iter = children.iterator();
		while (iter.hasNext()) {
			Element ele = (Element) iter.next();
			CMNode handler = constructHandler(ele);
			if (handler != null)
				root.add(handler);
		}
		return root;
	}

	private CMNode constructHandler(Element handler) throws UIParserException {
		String name = handler.getName();
		if (!name.equals("handler"))
			throw new UIParserException(
					"This is not a handler,but it is called " + name);

		String text = handler.getAttributeValue("name");
		CMNode node = new CMNode(text, false);
		List children = handler.getChildren();
		Iterator iter = children.iterator();
		while (iter.hasNext()) {
			Element ele = (Element) iter.next();
			if (ele.getName().equals("handlerItem")) {
				String itemText = ele.getAttributeValue("name");
				String classname = ele.getAttributeValue("class");
				String jarName = ele.getAttributeValue("jar");
				CMNode h = new CMNode(itemText, true);
				Element m = ele.getChild("menu");
				Element t = ele.getChild("mainToolbar");
				CMMenu menu = null;
				CMToolBar toolbar = null;
				if (m != null)
					menu = constructMenu(m);
				if (t != null) {
					ArrayList<CrimeMinerAction> bList = constructActionList(t);
					Iterator<CrimeMinerAction> buttonIter = bList.iterator();
					toolbar = new CMToolBar();
					while (buttonIter.hasNext()) {
						toolbar.add(buttonIter.next());
					}
				}
				Handler handle = new Handler(itemText, classname,jarName, menu, toolbar);
				h.setHandler(handle);
				node.add(h);
			} else {
				CMNode n = constructHandler(ele);
				if (n != null)
					node.add(n);
			}
		}
		return node;

	}

}
