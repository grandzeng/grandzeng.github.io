package crimeminer.ui;

import javax.swing.*;
import crimeminer.ui.component.*;
import java.awt.*;
import crimeminer.global.*;


public class CrimeMiner extends JFrame {

	private static final long serialVersionUID = 1792150077958270748L;

	private static final String title = "crime miner";

	private CMMenuBar crimeMinerMenuBar = null;//new CMMenuBar();

	private CMToolBar crimeMinerToolBar = null;//new CMToolBar();

	private Explorer explorer = null;//new Explorer();

	private Marker marker = null;//new Marker();

	private Walker walker = null;//new Walker();
	
	public static GlobalManager m_globalManager = null;
	
	public void fillContent() {

		JPanel backPanel = new JPanel();
		backPanel.setLayout(new BorderLayout());
		backPanel.setBorder(BorderFactory.createEtchedBorder());
		crimeMinerToolBar = m_globalManager.getToolBar();
		backPanel.add(crimeMinerToolBar, BorderLayout.NORTH);

		JSplitPane parent = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, true);
		JSplitPane son = new JSplitPane(JSplitPane.VERTICAL_SPLIT, true);
		
		walker = m_globalManager.getWalker();
		marker =  m_globalManager.getMarker();

		son.setTopComponent(walker);
		son.setBottomComponent(marker);
//		son.setDividerLocation(350);
		son.setDividerLocation(0.3);
		son.setOneTouchExpandable(true);
		son.setResizeWeight(1.0);
		
				
		explorer = new Explorer(m_globalManager.getTree());
		parent.setLeftComponent(explorer);
		parent.setRightComponent(son);
		parent.setOneTouchExpandable(true);
		parent.setDividerLocation(200);
		parent.setResizeWeight(0);

		backPanel.add(parent, BorderLayout.CENTER);
		getContentPane().add(backPanel);

	}

	public CrimeMiner() {
		m_globalManager = new GlobalManager();
		
		addCrimeMinerMenuBar();
		configureLayout();
		fillContent();
		setTitle(title);
//		setSize(800, 600);
		configureLocation();
		setVisible(true);
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
	}

	private void configureLayout() {
		getContentPane().setLayout(new BorderLayout());
	}

	private void addCrimeMinerMenuBar() {
		crimeMinerMenuBar = m_globalManager.getMenuBar();
		setJMenuBar(crimeMinerMenuBar);
	}

	private void configureLocation() {
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		setSize(d);
		this.toFront();
//		setAlwaysOnTop(true);
		Dimension c = getSize();
		
		int x = (d.width - c.width) / 2;
		int y = (d.height - c.height) / 2;
		setLocation(x, y);
	}

}
