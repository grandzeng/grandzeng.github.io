package crimeminer.ui.exception;

public class UIParserInitException extends Exception {
	
	private static final long serialVersionUID = 326053030192440113L;
		
	public UIParserInitException(){
		super("The UIParser has not been initialized");
	}
}
