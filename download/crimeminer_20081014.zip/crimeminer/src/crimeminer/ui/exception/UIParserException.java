package crimeminer.ui.exception;

public class UIParserException extends Exception {

	private static final long serialVersionUID = 3308261717289982152L;
	
	public UIParserException(){
		super("UI parser exception");
	}
	
	public UIParserException(String message){
		super("UI pareser exception:" + message);
	}
}
