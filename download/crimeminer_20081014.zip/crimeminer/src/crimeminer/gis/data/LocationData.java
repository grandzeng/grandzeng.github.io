package crimeminer.gis.data;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;

import org.geotools.feature.Feature;
import org.geotools.feature.FeatureCollection;
import org.geotools.feature.FeatureIterator;
import org.geotools.gui.swing.JMapPane;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.Geometry;


import spatialindex.rtree.RTree;
import spatialindex.spatialindex.ISpatialIndex;
import spatialindex.spatialindex.Point;
import spatialindex.storagemanager.DiskStorageManager;
import spatialindex.storagemanager.IBuffer;
import spatialindex.storagemanager.IStorageManager;
import spatialindex.storagemanager.PropertySet;
import spatialindex.storagemanager.RandomEvictionsBuffer;


public class LocationData {

	private final String fileName = "locationdata.txt";
	
	private static String treeFile = "e:\\tree1"; 
		
	private static int treeId;
	
	private static HashMap<String,Point> resultSet = new HashMap<String,Point>();
	
	public void getAllData() 
	throws FileNotFoundException{
//		resultSet = new HashMap<String,Point>();
		String shpPath = getClass().getResource(fileName).toString();
		File file = new File(shpPath);
		Scanner scanner = new Scanner(file);
		while (scanner.hasNext()) {
			String place = scanner.next();
			int x = scanner.nextInt();
			int y = scanner.nextInt();
			resultSet.put(place, new Point(new double[]{x,y}));
		}
	}
	
	public void getAllData(JMapPane pane) 
	throws FileNotFoundException,IOException{
		
		treeId = buildRTree(pane);
	}
	
	public int getTreeId() {
		return treeId;
	}
	public void getData() {
		// TODO Auto-generated method stub
		
	}

	public void setData() {
		// TODO Auto-generated method stub
		
	}

	public HashMap<String,Point> returnData() {
		return resultSet; 
	}
	
	public String returnTreeFile() {
		return treeFile;
	}
	
	private int buildRTree(JMapPane pane) 
	throws FileNotFoundException,IOException{
		
		// Create a disk based storage manager.
		PropertySet ps = new PropertySet();

		Boolean b = new Boolean(true);
		ps.setProperty("Overwrite", b);
			//overwrite the file if it exists.

		ps.setProperty("FileName", treeFile);
			// .idx and .dat extensions will be added.

		Integer i = new Integer(4096);
		ps.setProperty("PageSize", i);
			// specify the page size. Since the index may also contain user defined data
			// there is no way to know how big a single node may become. The storage manager
			// will use multiple pages per node if needed. Off course this will slow down performance.

		IStorageManager diskfile = new DiskStorageManager(ps);

		IBuffer file = new RandomEvictionsBuffer(diskfile,20, false);
			// applies a main memory random buffer on top of the persistent storage manager
			// (LRU buffer, etc can be created the same way).
		
		/*
		 *
		 */
		
		// Create a new, empty, RTree with dimensionality 2, minimum load 70%, using "file" as
		// the StorageManager and the RSTAR splitting policy.
		PropertySet ps2 = new PropertySet();

		Double f = new Double(0.7);
		ps2.setProperty("FillFactor", f);

		i = new Integer(100);
		ps2.setProperty("IndexCapacity", i);
		ps2.setProperty("LeafCapacity", i);
			// Index capacity and leaf capacity may be different.

		i = new Integer(2);
		ps2.setProperty("Dimension", i);

		ISpatialIndex tree = new RTree(ps2, file);

		insertTree(tree,pane);
		
		return ((Integer)ps2.getProperty("IndexIdentifier")).intValue();
	}
	
	private void insertTree(ISpatialIndex tree,JMapPane pane) 
	throws IOException	{
		
		FeatureCollection fc = pane.getSelectionLayer().getFeatureSource().getFeatures();
		
		FeatureIterator iterator = fc.features();
		
		int nodeId = 0;
		
		while (iterator.hasNext()) {
			Feature feature = iterator.next();
			
			String country = (String)feature.getAttribute(1);
			
			Geometry g = feature.getDefaultGeometry();
			Coordinate[] points =  g.getCoordinates();
			
			double totalX = 0;
			double totalY = 0;
			for (Coordinate point : points) {
				totalX += point.x;
				totalY += point.y;
			}
			
			double avgX = totalX / points.length;
			double avgY = totalY / points.length;
			
			
			Point newPoint = new Point(new double[]{avgX,avgY});
			
			resultSet.put(country, newPoint);
			
			tree.insertData(country.getBytes(), newPoint, ++nodeId);
			
			if (!tree.isIndexValid())
				throw new IOException("Failed: Construction of RTree");
			
			tree.flush();
		}
	}
}
