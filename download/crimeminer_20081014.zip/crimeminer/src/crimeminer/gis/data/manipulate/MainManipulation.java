package crimeminer.gis.data.manipulate;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.*;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileFilter;

import org.geotools.catalog.GeoResource;
import org.geotools.catalog.Service;
import org.geotools.catalog.defaults.DefaultServiceFinder;
import org.geotools.data.FeatureSource;
import org.geotools.data.shapefile.ShapefileDataStoreFactory;
//import org.geotools.demo.introduction.DemoData;
//import org.geotools.demo.introduction.DemoGUI;
//import org.geotools.demo.mappane.MapViewer;
import org.geotools.feature.Feature;
import org.geotools.feature.FeatureCollection;
import org.geotools.geometry.jts.ReferencedEnvelope;
import org.geotools.gui.swing.JMapPane;
import org.geotools.gui.swing.SelectionManager;
import org.geotools.map.DefaultMapLayer;
import org.geotools.map.MapContext;
import org.geotools.map.MapLayer;
import org.geotools.referencing.crs.DefaultGeographicCRS;
import org.geotools.styling.SLDParser;
import org.geotools.styling.Style;
import org.geotools.styling.StyleFactory;
import org.geotools.styling.StyleFactoryFinder;
import org.opengis.referencing.crs.CoordinateReferenceSystem;

import com.vividsolutions.jts.geom.Envelope;

import crimeminer.gis.data.MapData;
import crimeminer.gis.ui.MainFrame;

public class MainManipulation {
	    
	    /* The name of the test shapefile. */
	  	String SHAPEFILENAME;
	    /* The name of the test sld for the test shapefile. */
//	    String SHAPEFILESLDNAME;
	    
	    /* The filename for the output image */
//	    final String imageFileEnd = "image.png";
	    
	    /* Cartographic variables */
	    public final static Envelope envlp_NoEdges = new Envelope(-179.0,179.0,-80.0,80.0);
	    public final static ReferencedEnvelope envlp_NoEdges2 = 
	                             new ReferencedEnvelope(-179.0,179.0,-80.0,80.0, 
	                                                    DefaultGeographicCRS.WGS84);
	    // TODO: move to GUI
	    CoordinateReferenceSystem projCRS = null;

	    /* The URI of the test shapefile. */
	    URI SHAPEFILEURI;

	    /* GUI class */
	    MainFrame ui;
	    
	    /* map data class */
	    MapData mapData;
	    
	    /* widgets */
	    MapContext context;
	    
	    JMapPane jmp;
	    
	    JTextArea textArea;
	    
	    JPanel frame;
	    
	    /* The constructor */
	    public MainManipulation(){
	        
	        mapData = new MapData();
//	        try {
//	            //path to our shapefile 
//	            String shpPath = getClass().getResource(SHAPEFILENAME).toString();
//	            //convert spaces to %20 
//	            shpPath = shpPath.replaceAll(" ", "%20");
//	            SHAPEFILEURI =  new URI(shpPath);
//	        } catch (URISyntaxException uriex) {
//	            System.err.println("Unable to create shapefile uri: "+ uriex.getMessage());
//	        }
	    }
	    
	    /* set the current Frame */
	    public void setMainFrame(MainFrame mFrame) {
	    	ui = mFrame;
	    }

	    /* These callback methods are called by MainFrame when the respective buttons 
	     * are pressed. Each one calls other methods below. */ 
	    
	    public void buttonCreateFeatures()
	    throws URISyntaxException , MalformedURLException{

	    	/* Load a shapefile with the given name into the List of DataStores.*/
	        /* NB: then close it so we can load it into the catalog instead. */
	        
	        /* Load a shapefile with the given name into the local catalog. */
	    	
	    	textArea = ui.returnJTextArea();
	    	loadShapefileIntoCatalog();
	    	textArea.append(" Done: Loaded the Shapefile into the catalog.\n");
	    }
	    
	    public void buttonCreateStyles()
	    throws IOException{
	    	
	    	File sldFile = toSLDFile(SHAPEFILENAME);	
	    	Style shpstyl = createShapefileStyleFromSLDFile(sldFile);
	    	mapData.setStyleMap("shpstyl",shpstyl);
	    	textArea.append(" Done: Created and loaded the Shape Style.\n");
	    	
	    }
	    
	    
	    
	    public void buttonCreateMap()
	    throws IOException{
	        ui.initialize_JMapPane();
	        textArea.append(" Done: Initialized the MapPane.\n");
	        
	        /* Add the Shapefile FeatureSource below the first layer. */
	        FeatureSource shpFS = getAShapefileFeatureSourceFromCatalog();
	        Style shpsty = (Style) mapData.getStyleMap().get("shpstyl");
	        MapLayer m1 = new DefaultMapLayer(shpFS,shpsty);
	        context = ui.returnMapContext();
	        context.addLayer(0,m1);
       
	        jmp = ui.returnJMapPane();
	        /* Configure JMapPane */
	        jmp.setHighlightLayer(context.getLayer(0));
	        jmp.setSelectionManager(new SelectionManager(context.getLayer(0)));
	        jmp.setSelectionLayer(context.getLayer(0));
	        
//	        jmp.setSize(200,600);

//	        jmp.setMapArea(context.getLayerBounds());
	        jmp.setMapArea(envlp_NoEdges);

	        /* Paint */
	        frame = ui.returnJFrame();
	        frame.repaint();
	        frame.doLayout();

	        textArea.append(" Done: Loaded the map.\n");
	    }
	    
	    
	    /**
	     * Loads a shapefile service into the catalog.
	     * 
	     * @throws IOException Any I/O errors loading into the catalog.
	     */
	    public void loadShapefileIntoCatalog()
	    throws URISyntaxException , MalformedURLException{
	        
	        //create shapefile datastore parameters
//	        URL shapefileURL = getClass().getResource( shpname );
	    	File shapeFile = getShapeFile();
	    	if (shapeFile == null) return;
	    	
	    	SHAPEFILENAME = shapeFile.getPath();
	    	textArea.append(" Done: Open file " + SHAPEFILENAME + "\n");
	    	     	
	    	URL shapefileURL = shapeFile.toURL();
	    	//path to our shapefile 
	    	String shpPath = shapefileURL.toString();
	    	//convert spaces to %20 
	    	shpPath = shpPath.replaceAll(" ", "%20");
	    	SHAPEFILEURI =  new URI(shpPath);
	      
	        Map params = new HashMap();
	        params.put( ShapefileDataStoreFactory.URLP.key, shapefileURL );
	        //load the services, there should be only one service
	        DefaultServiceFinder finder = new DefaultServiceFinder(mapData.getLocalCatalog());
	        List services = finder.aquire(SHAPEFILEURI, params);
	        
	        //add the service to the catalog
	        mapData.getLocalCatalog().add( (Service) services.get( 0 ) );
	    }
	    
	    // TODO: This should be done through the catalog *not* directly from the file.
	    public Style createShapefileStyleFromSLDFile(File sldFile)
	    throws IOException{
	    
	        // Make the sldURL from the sldName 
	    	URL sldURL = sldFile.toURL();
	        
	        // Create the shapefile Style, uses StyleFactory and an SLD URL
	        StyleFactory sf = StyleFactoryFinder.createStyleFactory();
	        SLDParser stylereader = null;
	     
	        stylereader = new SLDParser(sf,sldURL);
	     
	        Style[] shpStylArr = stylereader.readXML();
	        Style shpStyle = shpStylArr[0];
	        
	        return shpStyle;
	        
	    }
	    
	    /**
	     * Gets a FeatureCollection with the shapefile from the catalog.
	     * <p>
	     * This method <b>must</b> be called after {@link #loadShapefileIntoCatalog(String)}.
	     * </p>
	     * @return The shapefile feature source.
	     * 
	     * @throws IOException Any I/O errors that occur accessing the shapefile resource.
	     */
	    public FeatureSource getAShapefileFeatureSourceFromCatalog()
	    throws IOException{
//	    public FeatureCollection getFeatureCollectionForShapefile() throws IOException {
	        
	        //lookup service, should be only one
	        List serviceList = mapData.getLocalCatalog().find( SHAPEFILEURI, null );
	        Service service = (Service) serviceList.get( 0 );
	        
	        //shapefiles only contain a single resource
	        List resourceList = null;
            
	        resourceList = service.members( null );

            GeoResource resource = (GeoResource) resourceList.get( 0 );
	        
	        FeatureSource shpFS = null;
	        
	        shpFS = (FeatureSource) resource.resolve( FeatureSource.class, null );
	
	        return shpFS;
	    }
	    
	    
		private File getShapeFile() {
			File file;
			JFileChooser chooser = new JFileChooser();
			chooser.setDialogTitle("Open Shapefile");
			chooser.setFileFilter(new FileFilter() {
				public boolean accept(File f) {
					return f.isDirectory() || f.getPath().endsWith("shp")
					|| f.getPath().endsWith("SHP");
				}

				public String getDescription() {
					return "Shapefiles";
				}
			});
			int returnVal = chooser.showOpenDialog(null);

			if (returnVal != JFileChooser.APPROVE_OPTION) {
				file = null;
			}
			else {
				file = chooser.getSelectedFile();
			}
			
//			System.out.println("You chose to open this file: " + file.getName());
			return file;
		}

	    /** Figure out the URL for the "sld" file */
	    public static File toSLDFile(String filename)  {
	        if (filename.endsWith(".shp") || filename.endsWith(".dbf")
	                || filename.endsWith(".shx")) {
	            filename = filename.substring(0, filename.length() - 4);
	            filename += ".sld";
	        } else if (filename.endsWith(".SLD") || filename.endsWith(".SLD")
	                || filename.endsWith(".SLD")) {
	            filename = filename.substring(0, filename.length() - 4);
	            filename += ".SLD";
	        }
	        return new File(filename);
	    }
	    
	    public MapContext returnMapContext() {
	    	return context;
	    }
	    
	    public JMapPane returnMapPane() {
	    	return jmp;
	    }
}
