package crimeminer.gis.data;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.geotools.catalog.Catalog;
import org.geotools.catalog.defaults.DefaultCatalog;
import org.geotools.styling.Style;

public class MapData {
	
    /**
     * The List of Features used to store data outside the localCatalog.
     */
    List theFeatureList;
//    List <Feature> theFeatureList;
    
    /**
     * The List of FeatureCollections used to store data outside the localCatalog.
     */
    List  theFeatureCollectionList;
//    List <FeatureCollection> theFeatureCollectionList;
    
	/**
	 * The List of DataStores used to store data outside the localCatalog.
	 */
	List theDataStoreList;
//    List <DataStore> theDataStoreList;
	
    /**
     * The local Catalog used to store the services pointing to data in data stores.
     */
    Catalog localCatalog;
    
    /**
     * A Network Catalog used to store the services pointing to data on the network.
     */
    Catalog aNetworkCatalog;
    
    /**
     * The Map of Styles used to render the different layers stored as:
     *   String name, Style s.
     */
    Map theStyleMap;
    
	/**
	 * Creates the demo class and an underlying catalog for storing data.
	 */
	public MapData() {
        theFeatureList = new LinkedList();
        theFeatureCollectionList = new LinkedList();
        theDataStoreList = new LinkedList();
		localCatalog = new DefaultCatalog();
        aNetworkCatalog = new DefaultCatalog();//TODO: How is this done?
        theStyleMap = new HashMap();
	}
	
	/**
	 * @return The List used to store data as Features.
	 */
	public List getFeaturenList() {
		return theFeatureList;
	}
	
    /**
     * @return The List used to store data in FeatureCollections.
     */
    public List getFeatureCollectionList() {
        return theFeatureCollectionList;
    }
    
    /**
     * @return The List used to store data in DataStores.
     */
    public List getDataStoreList() {
        return theDataStoreList;
    }
    
    /**
     * @return The catalog used to store data.
     */
    public Catalog getLocalCatalog() {
        return localCatalog;
    }
    
    public void setStyleMap(String string,Style style) {
    	theStyleMap.put(string, style);
    }
    
    public Map getStyleMap() {
    	return theStyleMap;
    }

    
}
