package crimeminer.gis.data;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.util.ArrayList;

import crimeminer.gis.query.hotspot.CrimeTime;

public class CrimeData {

	private static ResultSet resultSet = null;

	final String url = "jdbc:mysql://localhost/crimeminer";

	final String user = "root";

	final String pwd = "admin";

	final String driver = "com.mysql.jdbc.Driver";
	
	public void getAllData() 
	throws ClassNotFoundException , SQLException{
		Class.forName(driver);
		Connection con = DriverManager.getConnection(url, user, pwd);
		Statement s = con.createStatement();
		resultSet = s.executeQuery("select * from crimedata");
	}

	public  ArrayList<CrimeTime> getData(String crimePlace,String crimeType) {
		// TODO Auto-generated method stub
		ArrayList<CrimeTime> array = new ArrayList<CrimeTime>();
	
		try {
			while (resultSet.next()) {
				Date startDate = resultSet.getDate("starttime");

				Date endDate = resultSet.getDate("endtime");
				
				Time startTime = resultSet.getTime("starttime");
				
				Time endTime = resultSet.getTime("endtime");

				array.add(new CrimeTime(startDate, endDate,startTime,endTime));

			}
			resultSet.beforeFirst();
		} catch (SQLException se) {
			// TODO: handle exception
			System.out.println(se.getMessage());
		}		
		
		return array;
	}

	public void setData() {
		// TODO Auto-generated method stub

	}

	public ResultSet returnResult() {
		return resultSet;
	}
}
