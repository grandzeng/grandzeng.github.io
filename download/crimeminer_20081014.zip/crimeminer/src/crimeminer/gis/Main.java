package crimeminer.gis;


import crimeminer.gis.data.manipulate.MainManipulation;
import crimeminer.gis.ui.MainFrame;
import crimeminer.mining.Operator;
import crimeminer.mining.classifier.ID3;
import crimeminer.ui.component.Walker;

public class Main extends Operator{

	MainFrame mFrame;
	@Override
	public void run() {
		// TODO Auto-generated method stub
		MainManipulation mm = new MainManipulation();
		
		mFrame = new MainFrame(mm);
		mm.setMainFrame(mFrame);
		Walker walker = globalManager.getWalker();
		walker.removeAll();
		walker.addTab("hotspot", mFrame.returnJFrame());
	}
	
}
