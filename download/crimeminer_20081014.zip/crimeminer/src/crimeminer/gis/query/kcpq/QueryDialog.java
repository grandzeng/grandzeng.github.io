package crimeminer.gis.query.kcpq;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import spatialindex.spatialindex.Point;

import crimeminer.gis.data.LocationData;

public class QueryDialog extends JDialog{
	
	private final String[] treeVariants = {"Linear","Quadratic","Rstar"};
	
	private JTextField fK;
	
	private JComboBox bTreeType;
	
	private int treeId;
	
	private Point sPoint;
	
	private String country;
	
	public QueryDialog(Point point,String selectedCountry,int id) {
		
		super();
		this.country = selectedCountry;
		this.sPoint = point;
		this.treeId = id;
		
		setSize(new Dimension(300,300));
		setResizable(false);
		Dimension sSize = Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((int)sSize.getWidth() / 2,(int)sSize.getHeight() / 2);
		
		
		JPanel inputPanel = new JPanel();
		BoxLayout layout = new BoxLayout(inputPanel,BoxLayout.Y_AXIS);		
		inputPanel.setLayout(layout);
		
		JLabel label = new JLabel(selectedCountry);
		label.setSize(150, 50);
		label.setAlignmentX(JLabel.CENTER_ALIGNMENT);
		label.setFont(new Font(Font.SERIF,Font.BOLD,20));
		
		JPanel subPanel1 = new JPanel();
		subPanel1.setLayout(new BoxLayout(subPanel1,BoxLayout.X_AXIS));
		JLabel label1 = new JLabel("The closest point number:");
		label1.setMaximumSize(label1.getPreferredSize());
		fK = new JTextField(new Integer(5).toString(),10);
		fK.setMaximumSize(fK.getPreferredSize());
		subPanel1.add(label1);
		subPanel1.add(Box.createHorizontalStrut(6));
		subPanel1.add(fK);
		subPanel1.setVisible(true);
		
		JPanel subPanel2 = new JPanel();
		subPanel2.setLayout(new BoxLayout(subPanel2,BoxLayout.X_AXIS));
		JLabel label2 = new JLabel("Please select the tree variant:   ");
		label2.setMaximumSize(label2.getPreferredSize());
		bTreeType = new JComboBox(treeVariants);
		bTreeType.setMaximumSize(bTreeType.getPreferredSize());
		subPanel2.add(label2);
		subPanel2.add(Box.createHorizontalStrut(6));
		subPanel2.add(bTreeType);
		subPanel2.setVisible(true);
		
		inputPanel.add(label);
		inputPanel.add(Box.createVerticalStrut(30));
		inputPanel.add(subPanel1);
		inputPanel.add(Box.createVerticalStrut(30));
		inputPanel.add(subPanel2);
		inputPanel.add(Box.createVerticalStrut(30));
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new FlowLayout());
		JButton ok = new JButton("OK");
		ok.setMinimumSize(new Dimension(100,30));
		JButton cancel = new JButton("cancel");
		cancel.setMinimumSize(new Dimension(100,30));
		buttonPanel.add(ok);
		buttonPanel.add(cancel);

		ok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				int k = new Integer(fK.getText().trim()).intValue();
				k++;
				String variant = (String)bTreeType.getSelectedItem();
				
				QueryProcess qp = new QueryProcess(k,sPoint,treeId);
				
				try {
					qp.openRTree(variant);
					ArrayList<String> res = qp.doKClosestPairQuery();
					ResultOutput output = new ResultOutput(res);
					output.showResult(k, country);
				} catch (FileNotFoundException error) {
					// TODO: handle exception
					JOptionPane.showMessageDialog(null, error.getMessage());
				} catch (IOException error) {
					JOptionPane.showMessageDialog(null, error.getMessage());
				}
				dispose();
			}
		});	
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
			}		
		});
		
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		panel.add(inputPanel,BorderLayout.CENTER);
		panel.add(buttonPanel,BorderLayout.SOUTH);
		panel.setVisible(true);
		
		add(panel);
	}
}
