package crimeminer.gis.query.kcpq;

import java.awt.Cursor;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;

import org.geotools.gui.swing.JMapPane;
import org.geotools.gui.swing.Messages;
import org.geotools.gui.swing.SelectionManager;

import crimeminer.gis.query.hotspot.HotspotQuery;
import crimeminer.gis.query.hotspot.HotspotQueryAction;

public class KClosestPairQueryAction extends AbstractAction{

	private ImageIcon icon;
	
    JMapPane map;
    
    private static KClosestPairQuery kcpq = null;


    public KClosestPairQueryAction() {
    	
    }
    public KClosestPairQueryAction(JMapPane map) {
//        URL url = this.getClass().getResource("resources/Add16.gif"); //$NON-NLS-1$
//
//        icon = new ImageIcon(url);
//        this.putValue(Action.SMALL_ICON, icon);
        this.putValue(Action.NAME, Messages.getString("kcpq")); //$NON-NLS-1$
        this.setEnabled(false);
        this.map = map;
    }

    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
        SelectionManager sm = map.getSelectionManager();
        if (kcpq == null)
        	kcpq = new KClosestPairQuery();
        HotspotQuery hq = new HotspotQueryAction().getHotspotQueryObject();
        if (hq != null)
        	sm.removeSelectionChangeListener(hq);
        sm.addSelectionChangeListener(kcpq);
  
        map.setState(JMapPane.Select);
        map.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    public ImageIcon getIcon() {
        return icon;
    }

    public void setIcon(ImageIcon icon) {
        this.icon = icon;
    }
    
    public KClosestPairQuery getKClosestPairQueryObject() {
    	return kcpq;
    }
}
