package crimeminer.gis.query.kcpq;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import crimeminer.gis.data.LocationData;
import spatialindex.rtree.RTree;
import spatialindex.spatialindex.ISpatialIndex;
import spatialindex.spatialindex.Point;
import spatialindex.spatialindex.SpatialIndex;
import spatialindex.storagemanager.DiskStorageManager;
import spatialindex.storagemanager.IBuffer;
import spatialindex.storagemanager.IStorageManager;
import spatialindex.storagemanager.PropertySet;
import spatialindex.storagemanager.RandomEvictionsBuffer;

public class QueryProcess {

	private Point sPoint;
	
	private int treeId;
	
	private int numK;
	
	private RTree tree;
	
	public QueryProcess(int k,Point point,int id) {
		numK = k;
		
		sPoint = point;
		
		treeId = id;
	}

	public void openRTree(String var) throws FileNotFoundException, IOException {
		
		int type = SpatialIndex.RtreeVariantRstar;
		
		if (var.equalsIgnoreCase("Linear"))
			type = SpatialIndex.RtreeVariantLinear;
		else if (var.equalsIgnoreCase("Quadratic"))
			type = SpatialIndex.RtreeVariantQuadratic;
			
		// Create a disk based storage manager.
		PropertySet ps = new PropertySet();

		ps.setProperty("FileName",new LocationData().returnTreeFile());
			// .idx and .dat extensions will be added.

		IStorageManager diskfile = new DiskStorageManager(ps);

		IBuffer file = new RandomEvictionsBuffer(diskfile, 20, false);
			// applies a main memory random buffer on top of the persistent storage manager
			// (LRU buffer, etc can be created the same way).

		PropertySet ps2 = new PropertySet();

		// If we need to open an existing tree stored in the storage manager, we only
		// have to specify the index identifier as follows
		Integer i = new Integer(treeId); // INDEX_IDENTIFIER_GOES_HERE (suppose I know that in this case it is equal to 1);
		ps2.setProperty("IndexIdentifier", i);
			// this will try to locate and open an already existing r-tree index from file manager file.
		ps2.setProperty("TreeVariant",type);
		tree = new RTree(ps2, file);

		if (!tree.isIndexValid())
			throw new IOException("Failed open tree file: " + 
					new LocationData().returnTreeFile());
	}
	
	public ArrayList<String> doKClosestPairQuery() {
		if (tree == null)
			return null;
		
		MyVisitor myVisitor = new MyVisitor();
		tree.nearestNeighborQuery(numK, sPoint, myVisitor);
		ArrayList<String> res = myVisitor.getResult();
		return res;
	}
}
