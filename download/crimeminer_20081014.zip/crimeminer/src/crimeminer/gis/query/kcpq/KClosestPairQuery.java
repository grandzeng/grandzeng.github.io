package crimeminer.gis.query.kcpq;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

import org.geotools.feature.Feature;
import org.geotools.feature.FeatureCollection;
import org.geotools.gui.swing.JMapPane;
import org.geotools.gui.swing.event.SelectionChangeListener;
import org.geotools.gui.swing.event.SelectionChangedEvent;

import crimeminer.gis.data.LocationData;

import spatialindex.spatialindex.Point;


public class KClosestPairQuery implements SelectionChangeListener{

	public void selectionChanged(SelectionChangedEvent e) {
		// TODO Auto-generated method stub
		try {
			JMapPane pane = (JMapPane)e.getSource();
			FeatureCollection fCollection = pane.getSelectionLayer().getFeatureSource()
							.getFeatures(e.getFilter());
			if (fCollection.getNumberOfAttributes() == 0) {
				JOptionPane.showMessageDialog(pane,"Warning: Please select a country");
			}
			else {
				Feature feature = fCollection.features().next();
				String country = (String)feature.getAttribute(1);
				LocationData temp = new LocationData();
				Point sPoint = temp.returnData().get(country);
				QueryDialog qDialog = new QueryDialog(sPoint,country,temp.getTreeId());
				qDialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
				qDialog.setVisible(true);
			}		
		} catch (Exception er) {
			// TODO: handle exception
			System.out.println(er.getMessage());
		}	
	}
}
