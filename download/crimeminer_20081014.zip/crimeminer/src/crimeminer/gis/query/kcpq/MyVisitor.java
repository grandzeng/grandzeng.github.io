package crimeminer.gis.query.kcpq;

import java.util.ArrayList;

import spatialindex.spatialindex.IData;
import spatialindex.spatialindex.INode;
import spatialindex.spatialindex.IVisitor;

public class MyVisitor implements IVisitor{

	private ArrayList<String> result;
	
	public MyVisitor() {
		result = new ArrayList<String>();
	}
	
	public void visitData(IData d) {
		// TODO Auto-generated method stub
		byte[] arr = d.getData();
		String country = "";
		for (byte i : arr)
			country += (char)i;
		result.add(country);
	}

	public void visitNode(INode n) {
		// TODO Auto-generated method stub
	}

	public ArrayList<String> getResult() {
		return result;
	}
}
