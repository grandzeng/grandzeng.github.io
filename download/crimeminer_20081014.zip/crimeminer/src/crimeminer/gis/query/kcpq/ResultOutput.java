package crimeminer.gis.query.kcpq;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import org.geotools.data.FeatureSource;
import org.geotools.feature.Feature;
import org.geotools.feature.FeatureCollection;
import org.geotools.feature.FeatureIterator;
import org.geotools.feature.FeatureType;
import org.geotools.gui.swing.JMapPane;
import org.geotools.map.MapContext;
import org.geotools.map.MapLayer;
import org.opengis.filter.FilterFactory2;

import crimeminer.gis.data.MapData;
import crimeminer.gis.data.manipulate.MainManipulation;
import crimeminer.gis.ui.MainFrame;


public class ResultOutput {
	
	private ArrayList<String> result;
	
	private JButton highLight;
	
	private JList list;
	
	public ResultOutput(ArrayList<String> res) {
		result = res;
	}

	public void showResult(int k, String country) {
		
		ResultDialog dialog = new ResultDialog(k,country);
		dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		dialog.setVisible(true);
	}

	class ResultDialog extends JDialog {
		
		public ResultDialog(int k,String country) {

			Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
			setLocation((int)d.getWidth() / 2,(int)d.getHeight() / 2);
			setSize(300,300);

			JLabel lInfo = new JLabel("The " + (k - 1) + " closest points of " + country + ":");

			int size = result.size();
			String[] answers = new String[size - 1];
			for (int i = 1; i < size; i++)
				answers[i - 1] = result.get(i);
			list = new JList(answers);
			list.setVisibleRowCount(5);
			list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			list.addListSelectionListener(new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent e) {
					JList list = (JList)e.getSource();
					if (list.getSelectedIndex() == -1)
						highLight.setEnabled(false);
					else
						highLight.setEnabled(true);
				}
			});
			JScrollPane sPane = new JScrollPane(list);
			sPane.setVisible(true);

			highLight = new JButton("HighLight");
			highLight.setEnabled(false);
			highLight.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
			
					try {
									
						MainManipulation mm = MainFrame.returnMM();

						MapContext context = mm.returnMapContext();

						MapLayer layer = context.getLayer(0);

						FeatureSource fs = layer.getFeatureSource();

						FilterFactory2 ff = (FilterFactory2) org.geotools.factory.CommonFactoryFinder
						.getFilterFactory(null);

						org.opengis.filter.spatial.BinarySpatialOperator f 
						= ff.equal(ff.property("NAME"),ff.literal(list.getSelectedValue()));

						FeatureCollection fc = fs.getFeatures(f);

						JMapPane jmp = mm.returnMapPane();

						jmp.setSelection(fc);

					} catch (IOException error) {
						// TODO: handle exception
						System.out.println(error.getMessage());
					}
				}
			});
			
			JButton ok = new JButton("Quit");
			JPanel buttonPanel = new JPanel();
			
			ok.addActionListener(new ActionListener() {

				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					dispose();
				}
				
			});
			buttonPanel.add(highLight);
			buttonPanel.add(ok);
			
			JPanel panel = new JPanel();
			panel.setLayout(new BorderLayout(0,20));
			panel.add(lInfo,BorderLayout.NORTH);
			panel.add(sPane,BorderLayout.CENTER);
			panel.add(buttonPanel,BorderLayout.SOUTH);
			panel.setVisible(true);
			
			add(panel);
		}
	}
}