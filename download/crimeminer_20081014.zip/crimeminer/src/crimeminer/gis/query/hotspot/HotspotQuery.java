package crimeminer.gis.query.hotspot;

import java.awt.Dimension;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

import org.geotools.feature.Feature;
import org.geotools.feature.FeatureCollection;
import org.geotools.feature.FeatureIterator;
import org.geotools.gui.swing.JMapPane;
import org.geotools.gui.swing.event.SelectionChangeListener;
import org.geotools.gui.swing.event.SelectionChangedEvent;

public class HotspotQuery implements SelectionChangeListener{

	public void selectionChanged(SelectionChangedEvent e) {
		// TODO Auto-generated method stub
		try {
			
			JMapPane pane = (JMapPane)e.getSource();
			FeatureCollection fCollection = pane.getSelectionLayer().getFeatureSource()
							.getFeatures(e.getFilter());
			if (fCollection.getNumberOfAttributes() == 0) {
				JOptionPane.showMessageDialog(pane,"Warning: Please select a country");
			}
			else {
				Feature feature = fCollection.features().next();
				String country = (String)feature.getAttribute(1);
				QueryDialog qDialog = new QueryDialog(country);
				qDialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
				qDialog.setVisible(true);
			}		
		} catch (Exception er) {
			// TODO: handle exception
			System.out.println(er.getMessage());
		}		
	}	
	
}
