package crimeminer.gis.query.hotspot;

import java.sql.Date;
import java.sql.Time;


public class CrimeTime {
	private Date startDate;
	
	private Date endDate;
	
	private Time startTime;
	
	private Time endTime;
	
	public CrimeTime(){
		
	}
	public CrimeTime(Date sd,Date ed,Time st,Time et) {
		startDate = sd;
		
		endDate = ed;
		
		startTime = st;
		
		endTime = et;
	}
	
	public void setTime(Date sd,Date ed,Time st,Time et) {
		startDate = sd;
		
		endDate = ed;
		
		startTime = st;
		
		endTime = et;
	}
	
	
	public Date getStartDate() {
		return startDate;
	}
	
	public Date getEndDate() {
		return endDate;
	}
	
	public Time getStartTime() {
		return startTime;
	}
	
	public Time getEndTime() {
		return endTime;
	}
}
