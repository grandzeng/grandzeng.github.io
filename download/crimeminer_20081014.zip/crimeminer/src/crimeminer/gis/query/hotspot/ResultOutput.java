package crimeminer.gis.query.hotspot;

import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;


public class ResultOutput {
	
	private double[] result = null;
	
	public ResultOutput(double[] res) {
		result = res;
	}
	
	public void showResult(String crimePlace,String crimeType,String dimension) {
		JFreeChart chart = createJFreeChart(crimePlace,crimeType,dimension);
		
		ChartFrame frame = new ChartFrame("result",chart);
		frame.setSize(new Dimension(500,270));
		
		Dimension sSize = Toolkit.getDefaultToolkit().getScreenSize();
		frame.setLocation((int)sSize.getWidth() / 2, (int)sSize.getHeight() / 2);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setVisible(true);
	}
	
	private JFreeChart createJFreeChart(String cp,String ct,String d) {
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();
			
		int start , end;
		if (d.equalsIgnoreCase("hour")) { 
			start = 0;
			end = 23;
		}
		else {
			start = 1;
			end = d.equalsIgnoreCase("month") ? 12 : 31;
		}
		
		for (int i = start;i <= end; i++) {
			String value = new Integer(i).toString();
			dataset.addValue(result[i],"crime",value);
		}
		
		String category = d;
	
		JFreeChart chart = ChartFactory.createBarChart(
				ct + " at " + cp + " in every " + d,
				category,
				"value",
				dataset,
				PlotOrientation.VERTICAL,
				true,
				true,
				false);
		
		return chart;
	}
}
