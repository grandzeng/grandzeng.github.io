package crimeminer.gis.query.hotspot;

import java.awt.Cursor;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;

import org.geotools.gui.swing.JMapPane;
import org.geotools.gui.swing.Messages;
import org.geotools.gui.swing.SelectionManager;

import crimeminer.gis.query.kcpq.KClosestPairQuery;
import crimeminer.gis.query.kcpq.KClosestPairQueryAction;

public class HotspotQueryAction extends AbstractAction{
	
	private ImageIcon icon;
	
    JMapPane map;
    
    private static HotspotQuery hq = null;


    public HotspotQueryAction() {
    }
    
    public HotspotQueryAction(JMapPane map) {
//        URL url = this.getClass().getResource("resources/Add16.gif"); //$NON-NLS-1$
//
//        icon = new ImageIcon(url);
//        this.putValue(Action.SMALL_ICON, icon);
        this.putValue(Action.NAME, Messages.getString("Hotspot")); //$NON-NLS-1$
        this.setEnabled(false);
        this.map = map;
    }

    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
        SelectionManager sm = map.getSelectionManager();
        if (hq == null)
        	hq = new HotspotQuery();
        KClosestPairQuery kcpq = new KClosestPairQueryAction().getKClosestPairQueryObject();
        if (kcpq != null)
        	sm.removeSelectionChangeListener(kcpq);
        sm.addSelectionChangeListener(hq);
 
        map.setState(JMapPane.Select);
        map.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    public ImageIcon getIcon() {
        return icon;
    }
    

    public void setIcon(ImageIcon icon) {
        this.icon = icon;
    }
    
    public HotspotQuery getHotspotQueryObject() {
    	return hq;
    }
}