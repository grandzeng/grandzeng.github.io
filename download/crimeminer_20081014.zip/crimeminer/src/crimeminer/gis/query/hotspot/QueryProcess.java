package crimeminer.gis.query.hotspot;

import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;

import crimeminer.gis.data.CrimeData;

public class QueryProcess {
	
	private final int MONTH = 12;
	
	private final int DAY = 31;
	
	private final int HOUR = 24;
	
	private final int[] MONTHAT={0,31,28,31,30,31,30,31,31,30,31,30,31};
	
	private String crimePlace;
	
	private String crimeType;
	
	private String dimension;
	
	private ArrayList<CrimeTime> timeArray;
	
	private int dayCnt[];
	
	private int hourCnt[];
	
	private int start_year;
	
	private int start_month;
	
	private int end_year;
	
	private int end_month;
	
	private int start_day;
	
	private int end_day;
	
	private Date start_date;
	
	private Date end_date;
	
	
	public QueryProcess(String cp,String ct,String d) {
		crimePlace = cp;
		
		crimeType = ct;
		
		dimension = d;
	}
	
	public void getFitData() {
		
		timeArray = new CrimeData().getData(crimePlace, crimeType);
		
	}
	
	public double[] doStatistic() {
		
		int precision = dimension.equalsIgnoreCase("month") ? MONTH : 
						dimension.equalsIgnoreCase("day") ? DAY : HOUR;
		
		double[] result = new double[precision + 1];
		
		if (!dimension.equalsIgnoreCase("month"))
			dayCnt= new int[32];
		if (dimension.equalsIgnoreCase("hour"))
			hourCnt = new int[24];
		
		for (CrimeTime item : timeArray)
 		{
			start_date = item.getStartDate();
			end_date = item.getEndDate();
			start_year = start_date.getYear()+1900;
			end_year = end_date.getYear()+1900;
			start_month=start_date.getMonth()+1;
			end_month=end_date.getMonth()+1;
			start_day=start_date.getDate();
			end_day = end_date.getDate();
			
			int i;
			int total_day = 0;
			switch (precision)
			{
			case MONTH:
				
				int total_month = 0;
				
				if (start_year == end_year)
					total_month = end_month - start_month + 1;
				else
					total_month = MONTH - start_month + 1
					+end_month+(end_year-start_year-1)
					*MONTH;
				
				double t = (double)1/total_month;
				
				if (start_year == end_year)
					for (i = start_month;i <= end_month; i++)
						result[i] += t;
				else
				{
					for (i = start_month;i <= MONTH; i++)
						result[i] += t;
					for (i = 1;i <= end_month; i++)
						result[i] += t;
					for (i = 1;i <= MONTH; i++)
						result[i] += t * (end_year - start_year - 1);
				}
				break;
				
			case DAY:
				getDays();
				
				for (i = 1;i <= DAY; i++)
					total_day += dayCnt[i];
				for (i = 1;i <= DAY; i++)
					result[i] += (double)dayCnt[i] / total_day;
				break;
				
			case HOUR:
				Time start_time = item.getStartTime();
				Time end_time = item.getEndTime();
				int start_hour = start_time.getHours();
				int end_hour = end_time.getHours();
				int total_hour=0;
				
				if (start_date.equals(end_date))
				{
					for (i = start_hour;i <= end_hour + 1; i++)
					{
						total_hour++;
						hourCnt[i]++;
					}
				}
				else
				{
					getDays();
					
					dayCnt[start_date.getDate()]--;
					dayCnt[end_date.getDate()]--;
					
					for (i = 1;i <= DAY;i++)
						total_day += dayCnt[i];
					
					for (i = 0;i < HOUR; i++)
						hourCnt[i] = total_day;
					
					total_hour = 24 * total_day;
					
					for (i = start_hour;i < HOUR;i++)
					{
						total_hour++;
						hourCnt[i]++;
					}
					for (i = 0;i <= end_hour + 1;i++)
					{
						total_hour++;
						hourCnt[i]++;
					}
				}
				for (i = 0;i < HOUR;i++)
					result[i] += (double)hourCnt[i] / total_hour;
				break;
			}
		}
		return result;
	}
	
	private boolean isBigMonth(int m)
	{
		return m==1||m==3||m==5||m==7||m==8||m==10||m==12;
	}
	private boolean isLeapYear(int year)
	{
		return year%4==0&&year%100!=0||year%400==0;
	}
	
	private void getDays()
	{		
		int i;
		for (i = 1;i <= DAY; i++)
			dayCnt[i]=0;
		
		if (start_year == end_year)
			if (start_month == end_month)
			{
				for (i = start_day;i <= end_day;i++) 
					dayCnt[i]++;
			}
			else
			{
				
				for (i = 1;i < DAY;i++)
				{
					dayCnt[i] += end_month - start_month - 1;
					dayCnt[i] += ( i >= start_day && i <= MONTHAT[start_month] ? 1 : 0);
					dayCnt[i] += (i <= end_day ? 1 : 0);
				}
				
				for (i = start_month + 1;i <= end_month - 1; i++)
					if (isBigMonth(i))
						dayCnt[31]++;
				
				if (start_month < 2 && end_month > 2)
				{
					dayCnt[30]--;
					if (!isLeapYear(start_year))
						dayCnt[29]--;
				}
			}
		else
		{
			for (i = 1;i <= 30; i++)
			{
				dayCnt[i] += MONTH * (end_year - start_year - 1);
				dayCnt[i] += MONTH - start_month;
				dayCnt[i] += end_month - 1;
				dayCnt[i] += (i >= start_day && i <= MONTHAT[start_month] ? 1 : 0);
				dayCnt[i] += (i <= end_day ? 1 : 0);
			}
			
			dayCnt[31] += 7 * (end_year - start_year - 1);
			dayCnt[30] -= (end_year - start_year - 1);
			
			for (i = start_year + 1;i <= end_year - 1; i++)
				if (!isLeapYear(i))
					dayCnt[29]--;
			
			for (i = start_month + 1;i <= MONTH; i++)
				if (isBigMonth(i))
					dayCnt[31]++;
			
			if (start_month < 2)
			{
				dayCnt[30]--;
				if (!isLeapYear(start_year))
					dayCnt[29]--;
			}
			
			if (end_month > 2)
			{
				dayCnt[30]--;
				if (!isLeapYear(end_year))
					dayCnt[29]--;
			}		
		}
	}
}
