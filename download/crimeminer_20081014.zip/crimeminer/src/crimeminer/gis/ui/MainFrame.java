package crimeminer.gis.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Panel;
import java.awt.ScrollPane;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;

import javax.swing.Action;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JToolBar;

import org.geotools.gui.swing.JMapPane;
import org.geotools.gui.swing.PanAction;
import org.geotools.gui.swing.ResetAction;
import org.geotools.gui.swing.SelectAction;
import org.geotools.gui.swing.ZoomInAction;
import org.geotools.gui.swing.ZoomOutAction;
import org.geotools.map.DefaultMapContext;
import org.geotools.map.MapContext;
import org.geotools.referencing.CRS;
import org.geotools.referencing.crs.DefaultGeographicCRS;
import org.geotools.renderer.GTRenderer;
import org.geotools.renderer.lite.StreamingRenderer;
import org.opengis.referencing.FactoryException;
import org.opengis.referencing.crs.CoordinateReferenceSystem;

import crimeminer.gis.data.CrimeData;
import crimeminer.gis.data.LocationData;
import crimeminer.gis.data.manipulate.MainManipulation;
import crimeminer.gis.query.hotspot.HotspotQueryAction;
import crimeminer.gis.query.kcpq.KClosestPairQueryAction;


public class MainFrame extends JPanel {
    /* A link to the MainManipulation instance, to pass control back to the 'button*'
     * methods in that instance. */
    private static MainManipulation mainMan ;
    
    /* GUI frame, pane and extras */
//    final JFrame frame;//updated by grand
    final JPanel frame;//updated by zengchunqiu
    JPanel visPanel;
    ScrollPane infoSP;
    JToolBar jtb;
    JLabel text;
    JButton quitButton;
    JButton loadMapButton;
    JButton loadCrimeButton;
    JButton loadLocationButton;
    Action hotspotQuery;
    Action kClosestPairQuery;
    
    JTextArea textArea;
    
    /* Display elements */
    JMapPane jmp;
    MapContext context;
    GTRenderer renderer;
    
    com.vividsolutions.jts.geom.Envelope worldbounds;
     
    /*
     * Create the GUI.
     */
    public MainFrame(MainManipulation mm) {

        mainMan = mm; 
        
 
//        frame=new JFrame();
        frame = this;
        //frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//        frame.setBounds(20,20,800,500);
        this.setBounds(20,20,800,500);
//        frame.setBackground(Color.cyan);
        
        Container contentPane = this;//frame.getContentPane();
        BoxLayout layout = new BoxLayout(contentPane, BoxLayout.X_AXIS);
//        frame.setLayout(layout);
        this.setLayout(layout);
//        contentPane.setBackground(Color.red);
        
        JPanel buttonPanel = new JPanel();
//        buttonPanel.setBackground(Color.blue);
        buttonPanel.setVisible(true);
        visPanel = new JPanel();
//        visPanel.setBackground(Color.gray);
        visPanel.setVisible(true);
        
        frame.add(Box.createRigidArea(new Dimension(10, 0)));
        frame.add(buttonPanel);
        frame.add(Box.createRigidArea(new Dimension(10, 0)));
        frame.add(visPanel);
        frame.add(Box.createRigidArea(new Dimension(10, 0)));
        
        /* The action button Panel */
        JPanel actionButtonPanel = new JPanel();
//        actionButtonPanel.setBackground(Color.green);
        actionButtonPanel.setVisible(true);
        
        BoxLayout aBPlayout = new BoxLayout(actionButtonPanel, BoxLayout.Y_AXIS);
        actionButtonPanel.setLayout(aBPlayout);
        
        int BUTTON_WIDTH = 100;
        loadMapButton = new JButton("Load map data");
        loadMapButton.setMinimumSize(new Dimension(BUTTON_WIDTH,1));
        actionButtonPanel.add(loadMapButton);
        actionButtonPanel.add(Box.createRigidArea(new Dimension(0, 6)));
        loadCrimeButton = new JButton("Load crime data");
        loadCrimeButton.setEnabled(false);
        loadCrimeButton.setMinimumSize(new Dimension(BUTTON_WIDTH,1));
        actionButtonPanel.add(loadCrimeButton);
        actionButtonPanel.add(Box.createRigidArea(new Dimension(0, 6)));
        loadLocationButton = new JButton("Load location data");
        loadLocationButton.setEnabled(false);
        loadLocationButton.setMinimumSize(new Dimension(BUTTON_WIDTH,1));
        actionButtonPanel.add(loadLocationButton);
        actionButtonPanel.add(Box.createRigidArea(new Dimension(0, 6)));

        /* The button Panel */
        BoxLayout buttonPanelBoxLayout = new BoxLayout(buttonPanel,BoxLayout.Y_AXIS);
        buttonPanel.setLayout(buttonPanelBoxLayout);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        //TODO: verify the file can be found
        java.net.URL imgURL = 
            MainFrame.class.getResource("earth.png");
//        System.out.println(imgURL);
        ImageIcon icon = new ImageIcon(imgURL,"The crime Logo");
        JLabel iconLabel = new JLabel(icon);
        buttonPanel.add(iconLabel);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        buttonPanel.add(actionButtonPanel);
        buttonPanel.add(Box.createVerticalGlue());
        JButton quitButton = new JButton("QUIT");
//        buttonPanel.add(quitButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        
        quitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
//            	frame.dispose();
              }
          });
        
        loadMapButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                
                loadMapButton.setEnabled(false);
                
                try {
                	mainMan.buttonCreateFeatures();
                	mainMan.buttonCreateStyles();
                	mainMan.buttonCreateMap();
                	//styleButton.setEnabled(true);

                	loadCrimeButton.setEnabled(true);
                	loadLocationButton.setEnabled(true);
                	
                    frame.setSize(Toolkit.getDefaultToolkit().getScreenSize());
                    frame.setLocation(0,0);
  
                }
                catch (URISyntaxException error) {
                	textArea.append("Unable to construct shapefile URI: " + error.getMessage());
                }
                catch (MalformedURLException error) {
                	textArea.append("Incorrect shapefile URL: " + error.getMessage());
                }
                catch (IOException error){
    	            textArea.append("An IOException occured: " + error.getMessage());
    	        }
            }
          });
        
        loadCrimeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                
            	CrimeData cData = new CrimeData();
            	try {
            		cData.getAllData();
                    loadCrimeButton.setEnabled(false);            
                    hotspotQuery.setEnabled(true);
                    textArea.append("Done: Load the crime data");
            	}
            	catch (Exception error) {
            		textArea.append("Load crime data failed: " + error.getMessage());
            	}
             }
          });
        
        loadLocationButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	
                LocationData lData = new LocationData();
                try {
                	lData.getAllData(jmp);              	
                    loadLocationButton.setEnabled(false);
                    kClosestPairQuery.setEnabled(true);
                    textArea.append("Done: Load the loaction data");
                }
                catch (FileNotFoundException error) {
                	textArea.append("File not found: " + error.getMessage());
                }
                catch (IOException error) {
                	textArea.append("Failed: " + error.getMessage());
                }
              }
          });
        
        /* The info Text Area */
        textArea = new JTextArea();
        textArea.append("Welcome to the Geotools Demo.\n\n");
        textArea.append("Click on the \"Create\" button to start.\n\n");
        infoSP = new ScrollPane();
        infoSP.add(textArea);
        
        
        /* The visuals Panel */
        BoxLayout visPanelBoxLayout = new BoxLayout(visPanel,BoxLayout.Y_AXIS);
        visPanel.setLayout(visPanelBoxLayout);
        visPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        visPanel.add(infoSP);
        visPanel.add(Box.createRigidArea(new Dimension(0, 10)));
                
        contentPane.setVisible(true);
        contentPane.doLayout();
        frame.doLayout();
        frame.setVisible(true);
        frame.repaint();
        
    }
    
    
    
    
    
    /*
     * Create a GUI map displayer.
     * 
     * This is all Swing stuff for the JMapPane.
     * 
     */
    public void initialize_JMapPane(){
        textArea.append("Start: Initialize the GUI.\n");

        Panel mapGUI = new Panel();
        mapGUI.setLayout(new BorderLayout());
        jmp = new JMapPane();
        jmp.setBackground(Color.white);
        
        /* Renderer */
        renderer = new StreamingRenderer();
        
        /* Context */
        context = new DefaultMapContext(DefaultGeographicCRS.WGS84); 
        context.setAreaOfInterest(MainManipulation.envlp_NoEdges2);
 
        /* Add to JMapPane */
        jmp.setRenderer(renderer);
        jmp.setContext(context);
        
        
        /* The toolbar */
        jtb = new JToolBar();
        Action zoomIn = new ZoomInAction(jmp);
        Action zoomOut = new ZoomOutAction(jmp);
        Action pan = new PanAction(jmp);
        Action select = new SelectAction(jmp);
        Action reset = new ResetAction(jmp);
        jtb.add(zoomIn);
        jtb.add(zoomOut);
        jtb.add(pan);
        jtb.addSeparator();
        jtb.add(reset);
        jtb.addSeparator();
        jtb.add(select);
        final JButton button= new JButton();
        button.setText("CRS");
        button.setToolTipText("Change map prjection");
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
              
              String code = JOptionPane.showInputDialog( button, "Coordinate Reference System:", "EPSG:4326" ); 
              try{
                 CoordinateReferenceSystem crs = CRS.decode( code );
                 jmp.getContext().setAreaOfInterest(jmp.getContext().getAreaOfInterest(),crs);
                 jmp.setReset(true);
                 jmp.repaint();       
                   
                }
                catch(FactoryException fe){
                 JOptionPane.showMessageDialog( button, fe.getMessage(), fe.getClass().toString(), JOptionPane.ERROR_MESSAGE );
                 return;
                }
            }
        });
        jtb.add(button);
        jtb.addSeparator();
        
        //add Hotspot Query function
        hotspotQuery = new HotspotQueryAction(jmp);
        jtb.add(hotspotQuery);

        //add KCPQ function
        kClosestPairQuery = new KClosestPairQueryAction(jmp);
        jtb.add(kClosestPairQuery);
        
        mapGUI.add(jtb,BorderLayout.NORTH);
        mapGUI.add(jmp);
        
        infoSP.setSize(new Dimension(300,60));        
        BoxLayout visPanelBoxLayout = new BoxLayout(visPanel,BoxLayout.Y_AXIS);
        visPanel.setLayout(visPanelBoxLayout);
        visPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        visPanel.add(infoSP);
	    visPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        visPanel.add(mapGUI);
        visPanel.add(Box.createRigidArea(new Dimension(0, 10)));
//        frame.getContentPane().doLayout();
        doLayout();
        infoSP.setSize(new Dimension(3,3));
//        frame.getContentPane().doLayout();
        doLayout();
        frame.setVisible(true);

        textArea.append("  End: Initialized the GUI.\n");
        
    }
    
    public JTextArea returnJTextArea() {
    	return textArea;
    }
    
    public JPanel returnJFrame() {
    	return frame;
    }
    
    public JMapPane returnJMapPane() {
    	return jmp;
    }
    
    public MapContext returnMapContext() {
    	return context;
    }
    
    public static MainManipulation returnMM() {
    	return mainMan;
    }
}

