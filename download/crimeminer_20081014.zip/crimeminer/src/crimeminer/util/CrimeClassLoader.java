package crimeminer.util;

import java.util.logging.Logger;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.WritableByteChannel;

public class CrimeClassLoader extends ClassLoader {

	private String baseDir;
	private static final Logger log = Logger.getLogger(CrimeClassLoader.class
			.toString());

	public CrimeClassLoader(ClassLoader parent, String base) {
		super(parent);
		baseDir = base;
	}

	public String getBaseDir() {
		return baseDir;
	}

	protected Class findClass(String name) throws ClassNotFoundException {
		log.fine("findClass: " + name);
		byte[] bytes = loadClassBytes(name);
		Class theClass = defineClass(name, bytes, 0, bytes.length);
		if (theClass == null)
			throw new ClassFormatError();
		return theClass;
	}

	private byte[] loadClassBytes(String className)
			throws ClassNotFoundException {
		try {
			String classFile = getClassFile(className);
			FileInputStream fis = new FileInputStream(classFile);
			FileChannel fileC = fis.getChannel();
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			WritableByteChannel outC = Channels.newChannel(baos);
			ByteBuffer buffer = ByteBuffer.allocateDirect(1024);
			while (true) {
				int i = fileC.read(buffer);
				if (i == 0 || i == -1) {
					break;
				}
				buffer.flip();
				outC.write(buffer);
				buffer.clear();
			}
			fis.close();
			return baos.toByteArray();
		} catch (IOException fnfe) {
			throw new ClassNotFoundException(className);
		}
	}

	private String getClassFile(String name) {
		StringBuffer sb = new StringBuffer(baseDir);
		name = name.replace('.', File.separatorChar) + ".class";
		sb.append(File.separator + name);
		return sb.toString();
	}

	protected URL findResource(String name) {
		log.fine("findResource" + name);
		try {
			URL url = super.findResource(name);
			if (url != null)
				return url;
			url = new URL("file:///" + convertName(name));
			return url;
		} catch (MalformedURLException mue) {
			log.severe("findResouse error");
			return null;
		}
	}

	private String convertName(String name) {
		StringBuffer sb = new StringBuffer(baseDir);
		name = name.replace('.', File.separatorChar);
		sb.append(File.separator + name);
		return sb.toString();
	}

}
