package crimeminer.util.dbi;

import java.sql.*;
import java.util.ArrayList;
import java.util.Properties;

import javax.sql.*;

import crimeminer.core.Attribute;
import crimeminer.core.Instance;
import crimeminer.core.Instances;

import java.io.*;
/**
 * this class is used to build a tool library for access to the database.
 * all the data can be accessed by this class.
 * @author grandzeng
 * @version 1.0.0.0
 **/
public class DBI {
	/**
	 * this is used to stored the the configuration of the responding database.
	 * */
	private String db_properties;

	/**
	 * default constructor
	 * */
	public DBI() {
		db_properties = "db.properties";
	}

	public String getDb_properties() {
		return db_properties;
	}

	public void setDb_properties(String properties) {
		db_properties = properties;
	}

	public Connection getConnection() throws IOException,
			ClassNotFoundException, SQLException {
		String driver;
		String url;
		// String username;
		// String password;

		Properties prop = new Properties();

		FileInputStream in = new FileInputStream(db_properties);

		prop.load(in);

		in.close();

		driver = prop.getProperty("jdbc.driver");
		url = prop.getProperty("jdbc.url");
		// username = prop.getProperty("jdbc.username");
		// password = prop.getProperty("jdbc.password");

		Class.forName(driver);
		Connection connection = DriverManager.getConnection(url);

		return connection;
	}

	public ArrayList<String> listTables() throws IOException,
			ClassNotFoundException, SQLException {
		ArrayList<String> tables = new ArrayList<String>();

		Connection connection = getConnection();

		DatabaseMetaData metaData = connection.getMetaData();
		ResultSet resultSet = metaData.getTables(null, null, null,
				new String[] { "TABLE" });

		while (resultSet.next()) {
			tables.add(resultSet.getString(3));
		}

		connection.close();
		return tables;
	}

	public ArrayList<Attribute> readAttribute(ResultSet result_set)
			throws SQLException {
		ArrayList<Attribute> attributes = new ArrayList<Attribute>();
		ResultSetMetaData meta = result_set.getMetaData();

		for (int i = 1; i <= meta.getColumnCount(); i++) {
			String column_name = meta.getColumnLabel(i);
			int column_type = getAttributeType(meta.getColumnType(i));
			Attribute attribute = new Attribute(column_name, column_type);
			attribute.setIndex(i - 1);
			attributes.add(attribute);
		}

		return attributes;
	}

	/**
	 * @param type
	 *            is java.sql.Types
	 * @return The type of crimeminer.core.Attribute
	 */
	public int getAttributeType(int type) {
		// java.sql.Types ty;
		if ((java.sql.Types.BIT <= type && type <= java.sql.Types.BIGINT)
				|| (java.sql.Types.NUMERIC <= type && type <= java.sql.Types.DOUBLE))
			return Attribute.NUMERIC_TYPE;
		else if (type == java.sql.Types.CHAR
				|| type == java.sql.Types.LONGNVARCHAR
				|| type == java.sql.Types.VARCHAR
				|| type == java.sql.Types.BOOLEAN
				|| type == java.sql.Types.LONGVARCHAR
				|| type == java.sql.Types.NVARCHAR
				|| type == java.sql.Types.NCHAR)
			return Attribute.NOMINAL_TYPE;
		else if (type >= java.sql.Types.DATE
				&& type <= java.sql.Types.TIMESTAMP)
			return Attribute.DATE_TYPE;
		else
			return Attribute.NULL_TYPE;
	}

	@SuppressWarnings( { "deprecation", "deprecation" })
	public void attachData(ResultSet result, Instances dataset)
			throws SQLException {

		while (result.next()) {
			Instance instance = new Instance(dataset);
			int length = instance.getAttributeNum();
			for (int index = 0; index < length; index++) {
				Attribute attribute = dataset.getAttributeAt(index);
				if (attribute.isNominalType()) {
					String value = result.getString(index + 1);
					if (value == null)
						value = "";
					int val = attribute.addAttributeValue(value);
					instance.setValueAt(index, val);
				} else if (attribute.isNumericType()) {
					double val = result.getDouble(index + 1);
					instance.setValueAt(index, val);
				} else if (attribute.isDateType()) {
					int value;
					java.sql.Timestamp date = result.getTimestamp(index + 1);// getDate(index+1);
					if (date == null) {
						date = new java.sql.Timestamp(1970, 01, 01, 0, 0, 0, 0);
						value = attribute.addAttributeValue("");
					} else
						// long value = date.getTime();
						value = attribute.addAttributeValue(date);
					instance.setValueAt(index, value);
				}
				// //////add other type
				else {
					System.err.print("can not support this type");
				}
			}
			dataset.addInstance(instance);
		}
	}

	public Instances readInstances(String tableName) throws IOException,
			ClassNotFoundException, SQLException {
		String query = "select * from " + tableName;
		Connection connection = getConnection();
		Statement statement = connection.createStatement(
				ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
		ResultSet resultSet = statement.executeQuery(query);

		ArrayList<Attribute> attributes = readAttribute(resultSet);
		Instances instances = new Instances(tableName, attributes);
		attachData(resultSet, instances);

		connection.close();
		return instances;
	}

	// test
	public static void main(String args[]) {
		DBI dbi = new DBI();

		try {
			ArrayList<String> tables = dbi.listTables();
			for (int i = 0; i < tables.size(); i++) {
				System.out.println(tables.get(i));
			}
			dbi.readInstances("weather");

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
