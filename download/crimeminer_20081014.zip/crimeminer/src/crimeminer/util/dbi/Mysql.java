package crimeminer.util.dbi;

import java.sql.*;
import java.io.*;

public class Mysql {
	public static void main(String args[]) throws Exception {
		String url = "jdbc:mysql://localhost:3306/test";
		String user = "root";
		String pass = "admin";
		String driver = "com.mysql.jdbc.Driver";
		String query = "select * from Miss";

		Class.forName(driver);
		Connection connection = DriverManager.getConnection(url, user, pass);
		Statement statement = connection.createStatement();

		ResultSet result = statement.executeQuery(query);
		System.out.println("id\t\tsex\t\tage\t\t");
		while (result.next()) {
			StringBuffer buffer = new StringBuffer();
			int id = result.getInt("id");
			if (result.wasNull())
				buffer.append("Missing\t\t");
			else
				buffer.append(id + "\t\t");
			String sex = result.getString("sex");
			if (result.wasNull())
				buffer.append("Missing\t\t");
			else
				buffer.append(sex + "\t\t");
			int age = result.getInt("age");
			if (result.wasNull())
				buffer.append("Missing\t\t");
			else
				buffer.append(age + "\t\t");

			System.out.println(buffer.toString());
		}
	}
}
