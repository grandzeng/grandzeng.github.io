package crimeminer.global;

import java.io.IOException;
import java.util.*;

import org.jdom.JDOMException;

import crimeminer.core.*;
import crimeminer.ui.component.*;
import crimeminer.ui.parser.*;
import crimeminer.ui.component.menu.*;
import crimeminer.ui.component.toolbar.*;
import crimeminer.ui.exception.UIParserException;
import crimeminer.ui.exception.UIParserInitException;
import crimeminer.ui.component.action.CrimeMinerAction;
import crimeminer.ui.component.explorer.*;
import crimeminer.util.dbi.DBI;
/**
 * This class object should always be the only one active as a global object.
 * */
public class GlobalManager {
	
	//��ǰ�����ݼ�
	private Instances m_currentInstances;
	
	//��ǰ�Ĳ˵�
	private CMMenuBar m_currentMenuBar;
	
	//��ǰ�Ĺ�����
	private CMToolBar m_currentToolBar;
	
	//��ǰ�����н��
	private ResultData m_resultData;
	
	private Walker m_walker;
	
	private Marker m_marker;
	
	private CMTree m_tree;
	
	private ClassCache cache ;
	
	private DBI dbi;
	
	public GlobalManager(){
		
		try {
			UIParser parser = new UIParser();
			
			m_currentMenuBar = new CMMenuBar();
			ArrayList<CMMenu> menuList = parser.getAllMenus();
			Iterator<CMMenu> menuIter = menuList.iterator();
			while(menuIter.hasNext()){
				m_currentMenuBar.add(menuIter.next());
			}
			
			m_currentToolBar = new CMToolBar(); 
//			ArrayList<CMToolBarButton> buttonList = parser.getAllToolBarButton();
//			Iterator<CMToolBarButton> buttonIter = buttonList.iterator();
//			
			ArrayList<CrimeMinerAction> actionList = parser.getAllToolBarAction();
			Iterator<CrimeMinerAction> actionIter = actionList.iterator();
			
//			while(buttonIter.hasNext()){
//				m_currentToolBar.add(buttonIter.next());
//			}
			
			while(actionIter.hasNext()){
				m_currentToolBar.add(actionIter.next());
			}
			CMNode root = parser.getExplorerRoot();
			m_tree = new CMTree(root);
			
			cache = new ClassCache(parser.getExtensionLibrary());
			
			m_walker= new Walker();
			
			
			m_marker = new Marker();
			
			dbi = new DBI();
			
		} catch (JDOMException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UIParserInitException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UIParserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public synchronized CMMenuBar getMenuBar(){
		return  m_currentMenuBar;
	}
	
	public synchronized void setMenuBar(CMMenuBar menuBar){
		m_currentMenuBar = menuBar;
	}
	
	public synchronized Instances getInstances(){
		return m_currentInstances;
	}
	
	public synchronized void setInstances(Instances instances){
		m_currentInstances = instances;
	}
	
	public synchronized CMToolBar getToolBar(){
		return m_currentToolBar;
	}
	
	public synchronized void setToolBar(CMToolBar toolbar){
		m_currentToolBar = toolbar;
	}
	
	public synchronized ResultData getResultData(){
		return m_resultData;
	}
	
	public synchronized CMTree getTree(){
		return m_tree;
	}
	
	public synchronized void setTree(CMTree tree){
		m_tree = tree;
	}
	public synchronized void setCache(ClassCache c){
		cache =c;
	}
	public synchronized ClassCache getCache(){
		return cache;
	}
	
	public synchronized Walker getWalker(){
		return m_walker;
	}
	
	public synchronized void setWalker(Walker walker){
		m_walker=walker;
	}
	
	public synchronized void setMarker(Marker m){
		m_marker=m;
	}
	public synchronized Marker getMarker(){
		return m_marker;
	} 
}
