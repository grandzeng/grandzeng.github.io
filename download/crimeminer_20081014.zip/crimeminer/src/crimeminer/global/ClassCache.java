package crimeminer.global;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.*;
import crimeminer.util.*;

public class ClassCache {

	private HashMap<String, Class> map = null;

	// private CrimeClassLoader loader = null;

	private String classLibrary = ".";

	public ClassCache() {
		classLibrary = ".";
		// loader = new CrimeClassLoader(ClassLoader.getSystemClassLoader(),
		// classLibrary);
		map = new HashMap<String, Class>();
	}

	public ClassCache(String library) {
		classLibrary = library;
		// loader = new CrimeClassLoader(ClassLoader.getSystemClassLoader(),
		// classLibrary);
		map = new HashMap<String, Class>();
	}

	public Class getClass(String className, String jar)
			throws ClassNotFoundException, MalformedURLException {
		String key = jar + className;
		Class result = map.get(key);
		if (result == null) {
			// result = loader.loadClass(key);
			URL url = getJarURL(jar);
			URLClassLoader classLoader = new URLClassLoader(new URL[] { url },
					ClassLoader.getSystemClassLoader());
			result = classLoader.loadClass(className);
			System.out.println(key + " has been loaded successfully");
			map.put(key, result);
		} else
			System.out.println(key + " has been hitted in ClassCache");
		return result;
	}

	private URL getJarURL(String jar) throws MalformedURLException {
		StringBuffer path = new StringBuffer();
		path.append(classLibrary);
		path.append("/");
		path.append(jar);
		File file = new File(path.toString());
		return file.toURL();
	}

	public String getClassLibrary() {
		return classLibrary;
	}

	protected void setClassLibrary(String library) {
		classLibrary = library;
		// loader = new CrimeClassLoader(ClassLoader.getSystemClassLoader(),
		// classLibrary);
	}

	// public CrimeClassLoader getClassLoader() {
	// return loader;
	// }

	// protected void setClassLoader(CrimeClassLoader l) {
	// loader = l;
	// classLibrary = loader.getBaseDir();
	// }
}
