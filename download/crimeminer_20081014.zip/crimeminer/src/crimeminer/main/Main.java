package crimeminer.main;

import crimeminer.ui.*;

public class Main {

	public static void main(String[] args) {
		CrimeMiner crimeMiner=new CrimeMiner();
	}

}
