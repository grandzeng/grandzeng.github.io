package crimeminer.mining;
import crimeminer.core.*;
import crimeminer.global.GlobalManager;
import crimeminer.ui.*;
public abstract class Operator {
	
	protected GlobalManager globalManager;
	
	public Operator(){
		globalManager = CrimeMiner.m_globalManager;
	}
	
	public abstract void run();
	
	
}
