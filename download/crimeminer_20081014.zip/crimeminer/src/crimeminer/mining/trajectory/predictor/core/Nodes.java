package crimeminer.mining.trajectory.predictor.core;
import java.util.*;
import java.io.*;



public class Nodes implements Serializable
{
	private Hashtable<Node, Node> hashtable=null;
	private Node searchNode;
	
	public Nodes(File nodeFile)
	{
		searchNode=new Node(null,0,0,0);
		hashtable=new Hashtable<Node, Node>(10000);
		try
		{
			DataInput in=new DataInputStream(new FileInputStream(nodeFile));
			while( true )
			{
				Node tmp=this.read(in);
				if( tmp==null )
					break;
				this.addNode(tmp);
				//tmp.print();
			}
		}
		catch(Exception ex)
		{
			System.err.println(ex);
			System.exit(0);
		}
	}
	
	private void addNode(Node n)
	{
		hashtable.put(n, n);
	}
	
	private Node read (DataInput in) {
		try {
			byte len = in.readByte();
			if (len > 0) {
				byte[] data = new byte[len];
				in.readFully (data);
				long pID = in.readLong();
				int x = in.readInt();
				int y = in.readInt();
				return new Node(new String(data),pID,x,y);
			}	
			else {
				long pID = in.readLong();
				int x = in.readInt();
				int y = in.readInt();
				return new Node(null,pID,x,y);
			}
		}
		catch(EOFException ex)
		{
			return null;
		}
		catch(IOException ex) 
		{
			System.err.println(ex);
			System.exit(0);
			return null;
		}	
	}
	
	public Node getNode(long id)
	{
		searchNode.setId(id);
		return hashtable.get(searchNode);
	}
	
	public Node getNode(Node n)
	{
		return hashtable.get(n);
	}
	
	public Node getNode(long x, long y)
	{
		Enumeration<Node> e=hashtable.keys();
		if (e==null)
			return null;
		//int c=0;
		while( e.hasMoreElements() )
		{
			//c++;
			Node tmp=e.nextElement();
			//System.out.println(e.nextElement().getX()+","+e.nextElement().getY()+" c: "+c);
			if( tmp.getX()==x && tmp.getY()==y )
				return tmp;
		}
		//System.out.println(c);
		return null;
	}
	
	public Enumeration getAllNodes()
	{
		return hashtable.keys();
	}
	
	public void print()
	{
		Enumeration<Node> e=hashtable.keys();
		if (e==null) return;
		while( e.hasMoreElements() )
			e.nextElement().print();
	}
	
}
