package crimeminer.mining.trajectory.predictor.ui;

import javax.swing.*;
import javax.swing.border.TitledBorder;



import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class FileBrouser extends JPanel
{
	JTextField tf_fileDir;
	JButton b_chooseFile;
	File choosedFile;
	String title="Destination File";
	JFileChooser fc=new JFileChooser();
	String curDes="~";
		
	public FileBrouser(String currentDirectory)
	{
		curDes=currentDirectory;
		GridBagLayout gridBag=new GridBagLayout();
		setLayout(gridBag);
		GridBagConstraints cons=new GridBagConstraints();
		tf_fileDir=new JTextField();
		tf_fileDir.setEditable(false);
		cons.gridx=0;
		cons.gridy=0;
		cons.gridheight=1;
		//cons.gridwidth=1;
		cons.ipadx=0;
		cons.weightx=1;
		cons.anchor=GridBagConstraints.WEST;
		cons.fill=GridBagConstraints.HORIZONTAL;
		//cons.insets=new Insets(0,0,0,10);
		gridBag.setConstraints(tf_fileDir, cons);
		add(tf_fileDir);
		
		b_chooseFile=new JButton("Brouse");
		cons.gridx=1;
		cons.gridy=0;
		//cons.gridwidth=1;
		cons.weightx=0;
		cons.anchor=GridBagConstraints.EAST;
		cons.fill=GridBagConstraints.NONE;
		cons.insets=new Insets(0,10,0,0);
		gridBag.setConstraints(b_chooseFile, cons);
		add(b_chooseFile);

		setBorder(BorderFactory.createTitledBorder(title));
		
		
		
		
		b_chooseFile.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				fc=new JFileChooser(curDes);
				fc.setDialogTitle("Choose the file");
				int result=fc.showOpenDialog(FileBrouser.this);
				if( result==JFileChooser.APPROVE_OPTION )
				{
					choosedFile=fc.getSelectedFile();
					System.out.println("choosedFile: "+choosedFile);
					tf_fileDir.setText(choosedFile.getAbsolutePath());
					
					repaint();
				}
				
				
			}
		}
		);
		
	}
	
	public void setTitle(String s)
	{
		title=s;
		setBorder(new TitledBorder(title));
	}
	
	
	public void setEditable(boolean b)
	{
		tf_fileDir.setEditable(b);
	}
	
	public File getFile()
	{
		return choosedFile;
	}

	
	public static void main(String [] args)
	{
		JFrame frame=new JFrame("test");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		File file=null;
		FileBrouser f=new FileBrouser("data");
		System.out.println(file);
		f.setTitle("flew");
		frame.getContentPane().add(f);
		frame.setSize(400,80);
		frame.setVisible(true);
		//frame.pack();
	}
}
