package crimeminer.mining.trajectory.predictor.core;

import java.util.Scanner;

public class Controller 
{
	public static void pause()
	{
		System.out.print("press any key to continue...");
		Scanner scan=new Scanner(System.in);
		scan.nextLine();
	}
}
