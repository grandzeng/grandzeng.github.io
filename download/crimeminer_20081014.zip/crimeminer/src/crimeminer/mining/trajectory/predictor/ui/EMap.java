package crimeminer.mining.trajectory.predictor.ui;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;

import crimeminer.mining.trajectory.predictor.core.Edge;
import crimeminer.mining.trajectory.predictor.core.Edges;
import crimeminer.mining.trajectory.predictor.core.Node;
import crimeminer.mining.trajectory.predictor.core.Nodes;
import crimeminer.mining.trajectory.predictor.core.Path;
import crimeminer.mining.trajectory.predictor.core.Stamp;




public class EMap extends JPanel
{
	private Nodes nodes;
	private Edges edges;
	private int scale=600;//the user-set scale of the map;
	private int original_scale;
	private int x_min, x_max, y_min, y_max;//to determine the actual for vertex of the map
	private ArrayList<Path> paths=new ArrayList<Path>();
	private int wayOfshow=0;//
	private int time_index=0;
	private int offsetx=0, offsety=0;
	
	Graphics g;
	
	public EMap(Nodes nodes, Edges edges, int size)
	{
		this.nodes=nodes;
		this.edges=edges;
		scale=size;
		
		
		Enumeration e=nodes.getAllNodes();
		Node tmp=(Node)e.nextElement();
		x_min=x_max=tmp.getX();
		y_min=y_max=tmp.getY();
		while( e.hasMoreElements() )
		{
			tmp=(Node)e.nextElement();
			if( tmp.getX()>x_max )
				x_max=tmp.getX();
			else if( tmp.getX()<x_min )
				x_min=tmp.getX();
			
			if( tmp.getY()>y_max )
				y_max=tmp.getY();
			else if( tmp.getY()<y_min )
				y_min=tmp.getY();
		}
		original_scale=(x_max-x_min)>(y_max-y_min)? (x_max-x_min):(y_max-y_min);
		
		this.setBorder(new TitledBorder("map"));
		
	}
	
	
	public EMap(int size)
	{
		scale=size;
		
	}
	
	public EMap()
	{
		
	}
	
	/*
	public void setSize(int size)
	{
		scale=size;
		this.setBorder(new TitledBorder("map"));
		this.repaint();
	}
	*/
	
	public void setMap(Nodes nodes, Edges edges)
	{
		if( scale==-1 )
		{
			System.err.println("please use 'setSize()' first.");
			System.exit(0);
		}
		
		this.nodes=nodes;
		this.edges=edges;
		
		
		Enumeration e=nodes.getAllNodes();
		Node tmp=(Node)e.nextElement();
		x_min=x_max=tmp.getX();
		y_min=y_max=tmp.getY();
		while( e.hasMoreElements() )
		{
			tmp=(Node)e.nextElement();
			if( tmp.getX()>x_max )
				x_max=tmp.getX();
			else if( tmp.getX()<x_min )
				x_min=tmp.getX();
			
			if( tmp.getY()>y_max )
				y_max=tmp.getY();
			else if( tmp.getY()<y_min )
				y_min=tmp.getY();
		}
		original_scale=(x_max-x_min)>(y_max-y_min)? (x_max-x_min):(y_max-y_min);
		this.setBorder(new TitledBorder("map"));
		this.repaint();
	}
	
	public void setSize(int size)
	{
		scale=size;
		repaint();
	}
	
	public int getsize() {
		return scale;
	}
	
	public void setPaths(ArrayList<Path> result)
	{
		paths=result;
		repaint();
	}
	
	public void resetOffsets()
	{
		offsetx=0;
		offsety=0;
		repaint();
	}
	
	public ArrayList<Path> getPaths()
	{
		return paths;
	}
	
	protected void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		this.g=g;
		if( scale!=-1 && nodes!=null && edges!=null )
		{
			//this.paintAllNodes(g);
			this.paintEdges(g);
			this.paintPaths(g);
		}
	}
	
	private void paintEdges(Graphics g)
	{
		Enumeration e=edges.getAllEdges();
		while( e.hasMoreElements() )
		{
			Edge edge=(Edge)e.nextElement();
			Node n1=edge.getNode1();
			Node n2=edge.getNode2();
			g.setColor(Color.black);
			g.drawLine(this.coorConvX(n1.getX())+offsetx, this.coorConvY(n1.getY())+offsety, this.coorConvX(n2.getX())+offsetx, this.coorConvY(n2.getY())+offsety);		
			
			Stamp stamp1, stamp2;
			stamp1=new Stamp();
			stamp2=new Stamp();
			stamp1.setVal(n1.getX(), n1.getY(), 0);
			stamp2.setVal(n2.getX(), n2.getY(), 0);
			//paintDot(g, stamp1, Color.red);
			//paintDot(g, stamp2, Color.red);
			//g.setColor(Color.red);
			//g.fillOval(this.coorConvX(n1.getX())+offsetx, this.coorConvY(n1.getY())+offsety, 3, 3);
			//g.fillOval(this.coorConvX(n2.getX())+offsetx, this.coorConvY(n2.getY())+offsety, 3, 3);
			//g.setColor(Color.black);
		}
		
	}
	
	private void paintPaths(Graphics g)
	{
		if(paths==null || paths.size()==0 )
			return;
		
		Stamp initStamp=paths.get(0).getStamp(0);
		paintDot(g, paths.get(0).getStamp(0), Color.RED);
		
		for( int i=0; i<paths.size(); i++ )
		{
			for( int j=1; j<paths.get(i).getStampNum(); j++ )
			{
				if( j==time_index)
				{
					paintDot(g, paths.get(i).getStamp(j), Color.BLACK);
				}
			}
		}
		
	}
	
	
	private void paintDot(Graphics g, Stamp s, Color c)
	{
		/*
		g.setColor(c);
		g.fillOval(this.coorConvX((int)s.getX())+offsetx, this.coorConvY((int)s.getY())+offsety, 2, 2);
		g.setColor(Color.black);
		*/
		g.setColor(c);
		int x=this.coorConvX((int)s.getX());
		int y=this.coorConvY((int)s.getY());
		g.fillOval(x+offsetx, y+offsety, 6, 6);
		
	}
	
	public void setTimeIndex(int timeIndex)
	{
		time_index=timeIndex;
		repaint();
	}
	
	public int getTimeIndex()
	{
		return time_index;
	}
	
	public void addOffsetX(int x)
	{
		offsetx+=x;
	}
	
	public void addOffsetY(int y)
	{
		offsety+=y;
	}
	
	private int coorConvX(int coor)
	{
		coor-=x_min;
		double result=((double)coor/(double)original_scale+0.05)*(double)scale;
		//double result=((double)coor/(double)original_scale)*(double)scale;
		return (int)result+offsetx;
	}
	
	private int coorConvY(int coor)
	{
		coor-=y_min;
		double result=((double)coor/(double)original_scale+0.05)*(double)scale;
		//double result=((double)coor/(double)original_scale)*(double)scale;
		return (int)result+offsety;
	}
	
	public static void main(String [] args)
	{
		/*
		 * read map data
		 */
		//read the node info
		String mapName="oldenburgGen";
		File nodeFile=new File("D:\\workspace\\mapManager\\data\\"+mapName+".node");
		//File nodeFile=new File("/home/douglass/workspace/mapManager/data/"+mapName+".node");
		Nodes nodes=new Nodes(nodeFile);
		//read the edge info
		File edgeFile=new File("D:\\workspace\\mapManager\\data\\"+mapName+".edge");
		//File edgeFile=new File("/home/douglass/workspace/mapManager/data/"+mapName+".edge");
		Edges edges=new Edges(edgeFile, nodes);
		
		//EMap map=new EMap( nodes, edges, 500);
		EMap map=new EMap();
		map.setSize(900);
		map.setMap(nodes, edges);
		
		
		Stamp a=new Stamp();
		Stamp b=new Stamp();
		Stamp c=new Stamp();
		a.setVal(100, 100, 1);
		b.setVal(200, 200, 2);
		c.setVal(100, 300, 3);
		Path path=new Path();
		path.addStamp(a);
		path.addStamp(b);
		path.addStamp(c);
		ArrayList<Path> paths=new ArrayList<Path>();
		paths.add(path);
		map.setPaths(paths);
		
		JFrame frame=new JFrame("EMap");
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(1000, 1000);
		frame.getContentPane().add(map);
		
		
		Scanner scan=new Scanner(System.in);
		//map.setSize(500);
		String h=scan.nextLine();
		map.setMap(nodes, edges);
		
		//frame.pack();
		
	}
}
