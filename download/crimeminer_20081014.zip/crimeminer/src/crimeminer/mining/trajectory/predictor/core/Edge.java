package crimeminer.mining.trajectory.predictor.core;

import java.io.*;

public class Edge implements Serializable
{
	private Node node1;
	private Node node2;
	private String name;
	private long id;
	private int edgeClass;
	
	//the following attributes are used in the hotpred algorithm
	private int freq;//the frequence that this edge has been went through
	
	public Edge()
	{
		node1=null;
		node2=null;
		name=null;
		id=0;
		edgeClass=0;
		freq=0;
	}
	
	public Edge( Node node1, Node node2, String name, long id, int edgeClass)
	{
		this.node1=node1;
		this.node2=node2;
		this.name=name;
		this.id=id;
		this.edgeClass=edgeClass;
	}
	
	public Node getNode1()
	{
		return this.node1;
	}
	
	public Node getNode2()
	{
		return this.node2;
	}
	
	public void setName(String name)
	{
		this.name=name;
	}
	
	public String getName()
	{
		return this.name;
	}
	
	public void setId(long id)
	{
		this.id=id;
	}
	
	public long getId()
	{
		return this.id;
	}
	
	public void setEdgeClass(int edgeClass)
	{
		this.edgeClass=edgeClass;
	}
	
	public int getEdgeClass()
	{
		return edgeClass;
	}
	
	public double getLength()
	{
		return this.dist(node1.getX(), node1.getY(), node2.getX(), node2.getY());
	}
	
	/*
	public void freqAdd()
	{
		freq++;
	}
	
	public void setFreq(int i)
	{
		freq=i;
	}
	
	public int getFreq()
	{
		return freq;
	}
	
	public void addFreq()
	{
		freq++;
	}
	public void addFreq(int i)
	{
		freq=freq+i;
	}
	*/
	private double dist(double ax, double ay, double bx, double by)
	{
		return Math.sqrt(Math.pow(ax-bx, 2)+Math.pow(ay-by, 2));
	}
	
	public boolean equals(Object edge)
	{
		if( edge==null )
			return false;
		else
		{
			Node n1=((Edge)edge).getNode1();
			Node n2=((Edge)edge).getNode2();
			return ( (n1.getId()==this.node1.getId() && n2.getId()==this.node2.getId())
					||(n1.getId()==this.node2.getId() && n2.getId()==this.node1.getId()) );
		}
			//return ((Edge)edge).getId()==id;
	}
	
	public int hashCode()
	{
		return (int)node1.getId();
	}
	
	public void print()
	{
		System.out.println("edgeid: "+id+" Name: "+name+" nodeId1: "+this.node1.getId()+" nodeId2: "+this.node2.getId());
	}
}
