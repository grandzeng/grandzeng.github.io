/*
 * ��һ��״̬(�ߣ������ٶ�)ӳ���һ�����֣���������໥ת��
 */
package crimeminer.mining.trajectory.predictor.core;

import java.util.*;
import java.io.*;

public class StatusMapper implements Serializable
{
	private int edgeNum;
	private Hashtable<Long, Integer> h;
	private int count;
	
	public StatusMapper(Edges edges)
	{
		edgeNum=edges.getEdgeNum();
		h=new Hashtable<Long, Integer>();
		count=0;
	}
	
	public int toCode(Status s)
	{
		long code=24*s.getEdgeId()+6*s.getDirection()+1*(s.getSpeedLevel()-4);//�����ڱ߱�ţ������ٶȵȼ��仯��һ��code
		Long key=new Long(code);
		if( h.containsKey(key) )
		{
			return h.get(key).intValue();
		}
		else
		{
			h.put(key, count);
			count++;
			return count-1;
		}
		
	}
	
	public Status toStatus(int code)
	{
		Enumeration<Long> e=h.keys();
		long m=0;
		while( e.hasMoreElements() )
		{
			Long key=e.nextElement();
			int c=h.get(key).intValue();
			if( c==code )
			{
				m=key.longValue();
			}
		}
		long edgeId=m/24;
		int direction=(int)(m-edgeId*24)/6;
		int speedLevel=(int)(m-edgeId*24-direction*6); 
		return new Status(edgeId, direction, speedLevel+4);
		
	}
	

}
