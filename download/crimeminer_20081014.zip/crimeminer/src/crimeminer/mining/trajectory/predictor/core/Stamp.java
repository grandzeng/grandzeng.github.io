package crimeminer.mining.trajectory.predictor.core;

public class Stamp
{
	private double x;
	private double y;
	private int time;
	
	public Stamp()
	{
		x=y=0;
		time=0;
	}
	public Stamp(double x, double y, int time)
	{
		this.x=x;
		this.y=y;
		this.time=time;
	}
	
	public void setVal(double x, double y, int time)
	{
		this.x=x;
		this.y=y;
		this.time=time;
	}
	
	public double getX()
	{
		return x;
	}
	public double getY()
	{
		return y;
	}
	public int getTime()
	{
		return time;
	}
	public String toString()
	{
		String result=("<"+x+" ,"+y+" ,"+time+">");
		return result;
	}
	
	public boolean equals (Object stamp) {
		if (stamp == null)
			return false;
		Stamp tmp=(Stamp)stamp;
		return( tmp.getX()==this.x && tmp.getY()==this.y && tmp.getTime()==this.time  );
	}
	
	
	public static void main(String [] args)
	{
		Stamp a=new Stamp();
		Stamp b=new Stamp();
		Stamp c=new Stamp();
		a.setVal(1, 1, 1);
		b.setVal(2, 2, 2);
		c.setVal(1, 1, 1);
		
		System.out.println(a==b);
		System.out.println(a.equals(c));
		System.out.println(a==c);
	}
}
