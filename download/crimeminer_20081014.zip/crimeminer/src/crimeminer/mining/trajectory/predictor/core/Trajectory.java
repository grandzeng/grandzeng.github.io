package crimeminer.mining.trajectory.predictor.core;
import java.util.*;
import java.io.*;
public class Trajectory implements Serializable
{
	public static int UNCLUSTERED=-1;
	public static int NOISE=-2;
	private int clusterLabel;
	
	
	private int id=-1;//the id of the object
	ArrayList<Slot> slotSet=new ArrayList<Slot>();
	private boolean flag;//to indicate whether this trajectory contains the startpoint and the aim point
	
	public Trajectory(int iden)
	{
		clusterLabel=this.UNCLUSTERED;
		id=iden;
		flag=false;
	}
	
	public void addSlot(Slot s)
	{
		//if the Trajectory is empty, add the slot into it
		if ( slotSet.size()==0 )
			slotSet.add(s);
		//if the last slot of the trajectory has a sequence id smaller than the current one, add the current slot add the end  
		else if ( slotSet.get(slotSet.size()-1).getSequence()<s.getSequence())
			slotSet.add(s);
		else
		{
			System.out.println("Error heppened when adding slots into the trajectory!");
		}
	}
	
	//set the flag
	public void setFlag()
	{
		flag=true;
	}
	
	//get the flag
	public boolean getFlag()
	{
		return flag;
	}
	
	//return the id of the trajectory
	public int getId()
	{
		return id;
	}
	
	//print the info of this trajectory
	public void printTrajectory()
	{
		System.out.println("The Id of the Trajectory is: "+id);
		
		for( int i=0; i<slotSet.size(); i++ )
		{
			slotSet.get(i).printSlot();
		}
		System.out.println();
	}
	
	public void printTrajectory(int n)
	{
		System.out.println("The id of the Trajectory is: "+id);
		
		for( int i=0; i<(slotSet.size()<n? slotSet.size(): n); i++ )
		{
			slotSet.get(i).printSlot();
		}
		System.out.println();
	}
	
	//return the amount of all slots in it
	public int getSlotAmount()
	{
		return slotSet.size();
	}
	
	//return the slot at a certain place
	public Slot getSlot(int id)
	{
		if( id<0 || id >=slotSet.size() ) return null;
		return slotSet.get(id);
	}
	
	public void setClusterLabel(int l)
	{
		clusterLabel=l;
	}
	
	public int getClusterLabel()
	{
		return clusterLabel;
	}
}
