package crimeminer.mining.trajectory.predictor.core;
import java.io.*;

public class Slot implements Serializable 
{
	private int id;//the id of the object
	private int sequence;//the sequence of the slot in a trajectory
	private int class_id;//the id of the class in which the object is
	private int timeStamp;//the reporting time of the slot
	private double x_coor, y_coor;//the x and y coordinate of the object
	private double speed;//current speed of the object
	private double nod_x_coor, nod_y_coor;//the x and y coordinate of the next node that the object will pass by
	
	//add all info to the Slot when initializing it
	public Slot(int iden, int seq, int class_iden, int ts, double x, double y, double spd, double nod_x, double nod_y)
	{
		id=iden;
		sequence=seq;
		class_id=class_iden;
		timeStamp=ts;
		x_coor=x;
		y_coor=y;
		speed=spd;
		nod_x_coor=nod_x;
		nod_y_coor=nod_y;
	}
	
	public int getId()
	{
		return id;
	}
	
	public int getSequence()
	{
		return sequence;
	}
	
	public int getClassId()
	{
		return class_id;
	}
	
	public int getTimeStamp()
	{
		return timeStamp;
	}
	
	public double getXCoordinate()
	{
		return x_coor;
	}
	
	public double getYCoordinate()
	{
		return y_coor;
	}
	
	public double getSpeed()
	{
		return speed;
	}
	
	public double getNodeXCoordinate()
	{
		return nod_x_coor;
	}
	
	public double getNodeYCoordinate()
	{
		return nod_y_coor;
	}
	
	public void printSlot()
	{
		System.out.println("id: "+id+" seq: "+sequence+" class_id: "+class_id+" timeStamp: "+timeStamp+" position: ("
				+x_coor+","+y_coor+") speed: "+speed+" nodPos: ("+nod_x_coor+","+nod_y_coor+")");
	}
}
