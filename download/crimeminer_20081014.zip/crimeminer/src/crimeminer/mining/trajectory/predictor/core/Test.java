package crimeminer.mining.trajectory.predictor.core;

import java.io.*;
import java.util.*;

public class Test 
{

	public static void main(String [] args)
	{
		File file;
		Scanner scan=new Scanner(System.in);
		System.out.println("please input the name of the map file");
		String mapName=scan.nextLine();
		System.out.println("please input the name of the data file");
		String fileName=scan.nextLine();
		try
		{
			System.out.println("Program Started!");
			//��ȡ�ڵ��ļ�
			double t1=System.currentTimeMillis();
			file=new File("data/putmode/map/"+mapName+".node");
			Nodes nodes=new Nodes(file);
			//nodes.print();
			file.exists();		
			double t2=System.currentTimeMillis();
			System.out.println("get nodes time: "+(t2-t1));
			
			
			//��ȡ���ļ�
			file=new File("data/putmode/map/"+mapName+".edge");
			Edges edges=new Edges(file, nodes);			
			file.exists();
			//edges.print()
			double t3=System.currentTimeMillis();
			System.out.println("get edges time: "+(t3-t2));
			
			
			//����ctbn
			Ctbn ctbn=new Ctbn(edges, nodes);
			double t4=System.currentTimeMillis();
			System.out.println("create ctbn time: "+(t4-t3));
			
			TrajectorySet ts=new TrajectorySet();
			file=new File("data/putmode/data/"+fileName+".dat");
			ts.buildSet(file);
			
			double t5=System.currentTimeMillis();
			System.out.println("build trajectorySet time: "+(t5-t4));
			int total=ts.getTrajectoryAmount();
			int mount=0;//ѡ����������ctbn�����Ĺ켣����
			System.out.println("�����ݼ��У������켣����Ϊ��	"+total);
			
			
			//ѡ����Ҫ���еĲ���������ctbn��������ctbn��Ԥ��
			System.out.println("��ѡ����Ҫ���еĲ���: 0 ���im��mapper��1 ���ļ���ȡim��mapper. ");
			int c=scan.nextInt();
			if( c==0 )//ѡ��dat�еĲ����������Խ���ctbn�е�im
			{		
				System.out.println("begin to build the ctbn");
				System.out.print("��������Ҫ��������ctbn�Ĺ켣�������� ");
				mount=scan.nextInt();
				if( mount>=total )
				{
					System.out.println("���뷶Χ����");
					return;
				}
				double ta=System.currentTimeMillis();
				ctbn.train(ts, mount);
				double tb=System.currentTimeMillis();
				System.out.println("build ctbn time: "+(tb-ta));
				//ctbn.getIM().print();
				
				Controller.pause();
				
				double tc=System.currentTimeMillis();
				file=new File("data/putmode/model/"+fileName+".im");
				ctbn.writeImToFile(file);
				//file.exists();
				file=new File("data/putmode/model/"+fileName+".mp");
				ctbn.writeMapperToFile(file);
				file.exists();
				double td=System.currentTimeMillis();
				System.out.println("time taken to write im and mapper into files are: "+(td-tc));
				//ctbn.getIM().print();
			}
			else if( c==1 )//ѡ��dat�еı�������������Գ���Ԥ���׼ȷ�Ժ�Ч��
			{
				
				/*TrajectorySet ts;
				file=new File("D:\\workspace\\TrajectoryPrediction0.2\\resources\\"+fileName+".ptts");
				ObjectInputStream in=new ObjectInputStream(new FileInputStream(file));
				ts=(TrajectorySet)in.readObject();
				*/
				
				
				double ta=System.currentTimeMillis();
				Ctbn c2=new Ctbn(edges, nodes);
				System.out.println("��ʼ��ȡim��mapper����");
				file=new File("data/putmode/model/"+fileName+".im");
				c2.readImFromFile(file);
				file=new File("data/putmode/model/"+fileName+".mp");
				c2.readMapperFromFile(file);
				double tb=System.currentTimeMillis();
				System.out.println("time taken to read im and mapper from files are: "+(tb-ta));
				//c2.getIM().print();
				

				System.out.println("read im&mp over!");
				
				Controller.pause();
				
				/***************************************���沿������ѭ��ʵ��********************************************/
				boolean loop=true;
				
				//System.out.println("�������Ѿ���������ctbn�Ĺ켣����Ŀ��");
				int lost=2000;
				int lost1=lost;
				Predictor p=new Predictor(c2);
				double posi;
				double distValve;
				double timeValve;
				double target;
				
				
				
				lost=lost1;
				int exp;

				for( exp=100; exp<=1000; exp=exp+100 )
				{
					posi=0.05;
					distValve=700;
					timeValve=15;
					target=0;
					
					for( int i=lost; i<lost+exp; i++ )//��ÿ�켣�ĵ�һ��slot����Ԥ�⣬Ȼ�������Լ��Ƚϡ�
					{
						Slot s=ts.getTrajectory(i).getSlot(0);
						
						ArrayList<Path> result=null;
						
						result=p.predictPaths(s, posi);
						//System.out.println("size: "+result.size());
						
						
						if( result==null || result.size()==0 )
						{
							continue;
						}
						boolean hit=p.hit(result, ts.getTrajectory(i), distValve, timeValve);

						if( hit==true )
						{
							target++;
						}			
						
					}
					System.out.println(" num="+exp+" hit: "+target+" hit_percentage: "+((double)target/(double)exp));
					lost=lost+exp;
					
				}
				/*
				for( exp=100; exp<=800; exp=exp+100 )
				{
					posi=0.05;
					distValve=600;
					timeValve=18;
					target=0;
					
					for( int i=lost; i<lost+exp; i++ )//��ÿ�켣�ĵ�һ��slot����Ԥ�⣬Ȼ�������Լ��Ƚϡ�
					{
						Slot s=ts.getTrajectory(i).getSlot(0);
						
						ArrayList<Path> result=null;
						
						result=p.predictPaths(s, posi);
						
						
						
						if( result.size()==0 )
							System.out.println("ssԤ�ⲿ������");
						boolean hit=p.hit(result, ts.getTrajectory(i), distValve, timeValve);

						if( hit==true )
						{
							target++;
						}
						
						
						
					}
					System.out.println(" num="+exp+" hit: "+target+" hit_percentage: "+((double)target/(double)exp));
					lost=lost+exp;
					
				}
				
				System.out.println();
				*/
				
				
				
			}
		
			
		}
		catch(Exception ex)
		{
			System.err.println(ex);
			System.exit(0);
		}
	}
	
	
	
}
