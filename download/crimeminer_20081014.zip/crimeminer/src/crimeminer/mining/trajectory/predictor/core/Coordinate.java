package crimeminer.mining.trajectory.predictor.core;

public class Coordinate 
{
	private double x;
	private double y;
	
	public Coordinate()
	{
		x=0;
		y=0;
	}
	public Coordinate(double x, double y)
	{
		this.x=x;
		this.y=y;
	}
	public void setX(double x)
	{
		this.x=x;
	}
	public void setY(double y)
	{
		this.y=y;
	}
	
	public void setVal(double x, double y)
	{
		this.setX(x);
		this.setY(y);
	}
	
	public double getX()
	{
		return x;
	}
	public double getY()
	{
		return y;
	}
	
	public String toString()
	{
		String result="("+x+", "+y+")";
		return result;
	}
}
