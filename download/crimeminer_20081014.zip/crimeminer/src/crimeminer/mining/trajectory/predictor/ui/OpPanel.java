package crimeminer.mining.trajectory.predictor.ui;

import javax.swing.*;
import javax.swing.event.*;

import crimeminer.global.GlobalManager;
import crimeminer.mining.trajectory.predictor.core.Ctbn;
import crimeminer.mining.trajectory.predictor.core.Edges;
import crimeminer.mining.trajectory.predictor.core.Nodes;
import crimeminer.mining.trajectory.predictor.core.Path;
import crimeminer.mining.trajectory.predictor.core.Predictor;
import crimeminer.mining.trajectory.predictor.core.Slot;
import crimeminer.mining.trajectory.predictor.core.Status;
import crimeminer.mining.trajectory.predictor.core.Trajectory;
import crimeminer.mining.trajectory.predictor.core.TrajectorySet;
import crimeminer.ui.CrimeMiner;
import crimeminer.ui.component.Marker;


import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;


public class OpPanel extends JPanel
{
	private static final int slotAmount=50;
	
	Marker marker=CrimeMiner.m_globalManager.getMarker();
	
	EMapPanel mapPanel;
	File f_node, f_edge;
	Nodes nodes;
	Edges edges;
	File f_dataSet_train;
	File f_dataSet_use;
	File f_im_train, f_mp_train;
	File f_im_use, f_mp_use;
	String mode_save_dir;
	//String startDir="data/putmode";
	ArrayList<Slot> slots_fortest=new ArrayList<Slot>(slotAmount);//slotAmount slots supposed to be used while predicting
	int slot_index;
	Slot initSlot;
	boolean last_save, next_save;
	
	ArrayList<Path> result;
	
	
	JTabbedPane tp;
	int original_index=0;
	//3 panels on this JTabbedPane
	JPanel p1;
	JPanel p2;
	JPanel p3;
	
	//Components on the first panel
	FileBrouser fb_node;
	FileBrouser fb_edge;
	//Components on the second panel
	JTextField tf_maxSpeed;
	JTextField tf_modelName;
	FileBrouser fb_dataset;
	//Components on the third panel
		//��ʱ�Ķ���
		FileBrouser fb_im, fb_mp;
	JTextField tf_dataset_use;
	JButton b_browse_dataset_use;
	JLabel l_info;
	JTextField tf_0, tf_1, tf_2, tf_3, tf_4, tf_5;
	JButton b_last;
	JButton b_next;
	JButton b_predConfirm;
	JButton b_predRivise;
	JButton b_pred;
	JButton b_result;
	
	
	public OpPanel(EMapPanel map)
	{
		super(new GridLayout(1,1));
		
		this.mapPanel=map;

		tp=new JTabbedPane();
		p1=new JPanel();
		tp.addTab("choose map", p1);
		p2=new JPanel();
		tp.addTab("build model", p2);
		p3=new JPanel();
		tp.addTab("traj. predict", p3);

		/*
		 * Panel 1: find the map files
		 */
		fb_node=new FileBrouser("data/putmode/map");
		fb_node.setTitle("Find the node file of the map");
		fb_edge=new FileBrouser("data/putmode/map");
		fb_edge.setTitle("Find the edge file of the map");
		p1.setLayout(new GridLayout(10,1));
		
		p1.add(fb_edge);
		p1.add(fb_node);
		
		JButton b_confirm=new JButton("Confirm");
		b_confirm.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				f_node=fb_node.getFile();
				f_edge=fb_edge.getFile();
				if( f_node==null || f_edge==null )
				{
					//System.err.println("please select the nodeFile and the edgeFile first.");
					marker.log("Please set the node and edge file first!");
					return;
				}
				nodes=new Nodes(f_node);
				edges=new Edges(f_edge, nodes);
				setMap(nodes, edges);
			}
		}
		);
		JPanel pb=new JPanel();
		pb.setLayout(new GridBagLayout());
		GridBagConstraints constraints=new GridBagConstraints();
		constraints.gridx=0;
		constraints.gridy=0;
		constraints.weightx=1;
		constraints.fill=GridBagConstraints.HORIZONTAL;
		pb.add(new JPanel(), constraints);
		constraints.gridx=1;
		constraints.weightx=0;
		constraints.fill=GridBagConstraints.NONE;
		pb.add(b_confirm, constraints);
		p1.add(pb);
		
		
		/*
		 * Panel 2: build the prediction model basing on some historical data and set
		 */
		p2.setLayout(new GridLayout(10, 1));
		fb_dataset=new FileBrouser("data/putmode/data");
		
		//the panel to choose the dataset file
		fb_dataset.setTitle("choose the dataset file to train the model");
		p2.add(fb_dataset);
		
		//the panel to set the max speed
		JPanel p_maxSpeed=new JPanel();
		p_maxSpeed.setLayout(new GridBagLayout());
		constraints.gridx=0;
		constraints.gridy=0;
		constraints.anchor=GridBagConstraints.WEST;
		constraints.insets=new Insets(0,0,0,20);
		constraints.weightx=1;
		constraints.fill=GridBagConstraints.HORIZONTAL;
		tf_maxSpeed=new JTextField(10);
		p_maxSpeed.add(tf_maxSpeed, constraints);
		JButton b_confirm_speed=new JButton("Confirm");
		JButton b_revise=new JButton("Revise");
		constraints.gridx=1;
		constraints.anchor=GridBagConstraints.EAST;
		constraints.insets=new Insets(0,20,0,0);
		constraints.weightx=0;
		p_maxSpeed.add(b_confirm_speed, constraints);
		constraints.gridx=2;
		p_maxSpeed.add(b_revise, constraints);
		p_maxSpeed.setBorder(BorderFactory.createTitledBorder("set the max speed for the moving objects"));
		p2.add(p_maxSpeed);
		
		//the panel to set where the trained model file will be stored
		
		JPanel p_model=new JPanel();
		p_model.setLayout(new GridBagLayout());
		tf_modelName=new JTextField(10);
		constraints.gridx=0;
		constraints.gridy=0;
		constraints.insets=new Insets(0,0,0,20);
		constraints.weightx=1;
		constraints.anchor=GridBagConstraints.WEST;
		constraints.fill=GridBagConstraints.HORIZONTAL;
		p_model.add(tf_modelName, constraints);
		
		JButton b_confirm_modelName=new JButton("Confirm");
		JButton b_revise_modelName=new JButton("Revise");
		constraints.weightx=0;
		constraints.gridx=1;
		constraints.anchor=GridBagConstraints.EAST;
		constraints.insets=new Insets(0,20,0,0);
		constraints.weightx=0;
		p_model.add(b_confirm_modelName, constraints);
		constraints.gridx=2;
		p_model.add(b_revise_modelName, constraints);
		p_model.setBorder(BorderFactory.createTitledBorder("set the name of the model to be trained"));
		p2.add(p_model);
		
		
		
		//the "train" button
		JPanel p_train=new JPanel();
		p_train.setLayout(new GridBagLayout());
		
		constraints.gridx=0;
		constraints.gridy=0;
		constraints.anchor=GridBagConstraints.WEST;
		constraints.weightx=1;
		constraints.fill=GridBagConstraints.HORIZONTAL;
		p_train.add(new JPanel(), constraints);
		
		constraints.gridx=1;
		constraints.anchor=GridBagConstraints.EAST;
		constraints.fill=GridBagConstraints.NONE;
		constraints.weightx=0;
		JButton b_train=new JButton("Train Model");
		p_train.add(b_train, constraints);
		
		p2.add(p_train);
		
		b_confirm_speed.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent event)
			{
				try
				{
					if( tf_maxSpeed.getText()==null || tf_maxSpeed.getText().length()==0 )
					{
						marker.log("Please set the max speed for moving objects in this city");
						return;
					}
					double maxspeed=Double.parseDouble(tf_maxSpeed.getText());
					Status.setMaxSpeed(maxspeed);
					tf_maxSpeed.setEditable(false);
				} catch (Exception e)
				{
					System.err.println(e);
					return;
				}
				
				
			}
		});
		
		b_revise.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent event)
			{
				tf_maxSpeed.setText("");
				tf_maxSpeed.setEditable(true);
				
			}
		});
		
		b_confirm_modelName.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent event)
			{
				try
				{
					if( tf_modelName.getText()==null || tf_modelName.getText().length()==0 )
					{
						marker.log("Please set the name of the trained model.");
						return;
					}
					String modelName=tf_modelName.getText();
					f_im_train=new File("data/putmode/model/"+modelName+".im");
					f_mp_train=new File("data/putmode/model/"+modelName+".mp");
					System.out.println(f_im_train);
					System.out.println(f_mp_train);
					tf_modelName.setEditable(false);
				} catch (Exception e)
				{
					System.err.println(e);
					return;
				}
				
			}
		});
		
		b_revise_modelName.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent event)
			{
				tf_modelName.setText("");
				tf_modelName.setEditable(true);
				
			}
		});
		
		b_train.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent event)
			{			
				try
				{
					
					f_dataSet_train=fb_dataset.getFile();
					Ctbn ctbn=new Ctbn(edges, nodes);
					TrajectorySet tSet=new TrajectorySet();
					tSet.buildSet(f_dataSet_train);
					marker.log("training the model...");
					ctbn.train(tSet);
					
					//f_im_train=new File("data/putmod")
					
					
					ctbn.writeImToFile(f_im_train);
					ctbn.writeMapperToFile(f_mp_train);
					marker.log("Training finished!");
					//System.out.println("f_im_train: "+f_im_train);
					//System.out.println("f_mp_train: "+f_mp_train);
					//System.out.println("model training is over!");
				} catch (Exception e)
				{
					System.err.println(e);
					return;
				}
			}
		});
		
		/*
		 * Panel 3: Predict basing on some trained model
		 */
		//the panel to read the trained model
		JPanel p_readModel=new JPanel();
		JTextField tf_model=new JTextField(10);
		JButton tf_readmodel=new JButton("Read");//����Ӧ��������ѡ��ѡ���Ѿ�ѵ����ģʽ����ѵ����ʱ��ѵ���õ�ģʽ������Ӧ�÷ŵ����ݿ��С�
			//����Ϊ��ʱ��ʩ�����ڶ�ȡģ��
		fb_im=new FileBrouser("data/putmode/model");
		fb_im.setTitle("im_file");
		fb_mp=new FileBrouser("data/putmode/model");
		fb_mp.setTitle("mp_file");
		p_readModel.setLayout(new GridLayout(2, 1));
		p_readModel.add(fb_im);
		p_readModel.add(fb_mp);
		p_readModel.setBorder(BorderFactory.createTitledBorder("Choose the trained model"));
		p3.add(p_readModel);
		
		
		
		//the panel contains slot data from a file
		JPanel p_fileData=new JPanel();
		
		JPanel p_browse=new JPanel();
		tf_dataset_use=new JTextField(10);
		tf_dataset_use.setEditable(false);
		b_browse_dataset_use=new JButton("Browse");
		l_info=new JLabel();
		p_browse.setLayout(new GridBagLayout());
		constraints.gridx=0;
		constraints.gridy=0;
		constraints.weightx=1;
		constraints.insets=new Insets(0,0,0,10);
		constraints.anchor=GridBagConstraints.WEST;
		constraints.fill=GridBagConstraints.HORIZONTAL;
		p_browse.add(tf_dataset_use, constraints);
		constraints.gridx=1;
		constraints.weightx=0;
		constraints.insets=new Insets(0,10,0,0);
		constraints.fill=GridBagConstraints.NONE;
		constraints.anchor=GridBagConstraints.EAST;
		p_browse.add(b_browse_dataset_use);
		constraints.gridx=0;
		constraints.gridy=1;
		constraints.gridwidth=2;
		constraints.weightx=0;
		constraints.anchor=GridBagConstraints.CENTER;
		p_browse.add(l_info, constraints);
		
		
		p_browse.setBorder(BorderFactory.createTitledBorder("Choose the dataSet file"));
		
		
		p_fileData.setLayout(new GridLayout(2,1));
		p_fileData.add(p_browse);
		
		JPanel p_control=new JPanel();
		b_last=new JButton("Last");
		b_last.setEnabled(false);
		b_next=new JButton("Next");
		b_next.setEnabled(false);
		
		p_control.setLayout(new GridBagLayout());
		constraints.gridy=0;
		constraints.gridwidth=1;
		constraints.fill=GridBagConstraints.HORIZONTAL;
		constraints.weightx=1;
		constraints.gridx=0;
		p_control.add(new JLabel(), constraints);
		constraints.gridx=1;
		p_control.add(b_last, constraints);
		constraints.gridx=2;
		p_control.add(new JLabel(), constraints);
		constraints.gridx=3;
		p_control.add(b_next, constraints);
		constraints.gridx=4;
		p_control.add(new JLabel(), constraints);
		
		/*
		p_control.setLayout(new GridLayout(1, 5));
		p_control.add(new JLabel());
		p_control.add(b_last);
		p_control.add(new JLabel());
		p_control.add(b_next);
		p_control.add(new JLabel());
		*/
		p_control.setBorder(BorderFactory.createTitledBorder("choose a slot of state data from the file dataset"));
		p_fileData.add(p_control);
		
		
		p3.setLayout(new GridLayout(4, 1));
		p3.add(p_fileData);
		
		//the panel shows original status of the moving object
		JPanel p_showStatus=new JPanel();
		p_showStatus.setLayout(new GridLayout(7, 2));
		JLabel l_0, l_1, l_2, l_3, l_4, l_5;
		
		l_0=new JLabel("X_Coordinate: ");
		l_1=new JLabel("Y_Coordinate: ");
		l_2=new JLabel("Speed: ");
		l_3=new JLabel("Aim_X_Coordinate: ");
		l_4=new JLabel("Aim_Y_Coordinate: ");
		l_5=new JLabel("Valve possibility");
		tf_0=new JTextField(10);
		tf_1=new JTextField(10);
		tf_2=new JTextField(10);
		tf_3=new JTextField(10);
		tf_4=new JTextField(10);
		tf_5=new JTextField(10);
		p_showStatus.add(l_0);
		p_showStatus.add(tf_0);
		p_showStatus.add(l_1);
		p_showStatus.add(tf_1);
		p_showStatus.add(l_2);
		p_showStatus.add(tf_2);
		p_showStatus.add(l_3);
		p_showStatus.add(tf_3);
		p_showStatus.add(l_4);
		p_showStatus.add(tf_4);
		p_showStatus.add(l_5);
		p_showStatus.add(tf_5);
		p_showStatus.add(new JLabel());
		JPanel p_tmp_confirm=new JPanel();
		p_tmp_confirm.setLayout(new GridLayout(1, 2));
		b_predConfirm=new JButton("Comfirm");
		b_predConfirm.setEnabled(false);
		p_tmp_confirm.add(b_predConfirm);
		b_predRivise=new JButton("Revise");
		b_predRivise.setEnabled(false);
		p_tmp_confirm.add(b_predRivise);
		p_showStatus.add(p_tmp_confirm);
		p_showStatus.setBorder(BorderFactory.createTitledBorder("the original status of the moving object"));
		p3.add(p_showStatus);
		
		
		//the panel control the prediction and shows the result using the map
		JPanel p_pred=new JPanel();
		b_pred=new JButton  ("      Predict     ");
		b_result=new JButton("Show result on map");
		p_pred.setLayout(new GridBagLayout());
		constraints.gridx=0;
		constraints.gridy=0;
		constraints.gridwidth=1;
		constraints.fill=GridBagConstraints.NONE;
		constraints.anchor=GridBagConstraints.WEST;
		p_pred.add(b_pred, constraints);
		constraints.gridx=1;
		constraints.anchor=GridBagConstraints.EAST;
		p_pred.add(b_result, constraints);
		p3.add(p_pred);
		
		b_browse_dataset_use.addActionListener(new ActionListener()
		{
		
			@Override
			public void actionPerformed(ActionEvent e)
			{
				JFileChooser fc=new JFileChooser("data/putmode/data");
				fc.setDialogTitle("Choose the file");
				int result=fc.showOpenDialog(OpPanel.this);
				if( result==JFileChooser.APPROVE_OPTION )
				{
					marker.log("Reading data...");
					
					f_dataSet_use=fc.getSelectedFile();
					tf_dataset_use.setText(f_dataSet_use.getAbsolutePath());
					
					TrajectorySet tSet=new TrajectorySet();
					tSet.buildSet(f_dataSet_use);
					for( int i=0; i<tSet.getTrajectoryAmount(); i++ )
					{
						Trajectory trajectory=tSet.getTrajectory(i);
						for( int j=0; j<trajectory.getSlotAmount(); j++ )
						{
							Slot slot=trajectory.getSlot(j);
							slots_fortest.add(slot);
							if( slots_fortest.size()==slotAmount )
							{
								i=tSet.getTrajectoryAmount();
								j=trajectory.getSlotAmount();
							}
						}
					}
					l_info.setForeground(Color.red);
					l_info.setText("There are "+slots_fortest.size()+" slots can be used as initial state of the moving object.");
					
					
					for(int i=0;i<10;i++)
						marker.log("the " +(i+1)+"th");
					
					
					marker.log("Data reading finished!");
					setInitState(slots_fortest.get(0));
					tf_5.setText("0.1");
					slot_index=0;
					b_next.setEnabled(true);
					b_predConfirm.setEnabled(true);
				}
				
			}
		});
		
		b_next.addActionListener(new ActionListener()
		{
		
			@Override
			public void actionPerformed(ActionEvent event)
			{
				slot_index++;
				setInitState(slots_fortest.get(slot_index));
				if (slot_index==slots_fortest.size()-1)
				{
					b_next.setEnabled(false);
				}
				if (slot_index==1)
				{
					b_last.setEnabled(true);
				}
		
			}
		});
		
		b_last.addActionListener(new ActionListener()
		{
		
			@Override
			public void actionPerformed(ActionEvent event)
			{
				slot_index--;
				setInitState(slots_fortest.get(slot_index));
				if (slot_index==0)
				{
					b_last.setEnabled(false);
				}
				if (slot_index==slots_fortest.size()-2)
				{
					b_next.setEnabled(true);
				}
			}
		});
		
		b_predConfirm.addActionListener(new ActionListener()
		{
		
			@Override
			public void actionPerformed(ActionEvent event)
			{
				
				tf_0.setEnabled(false);
				tf_1.setEnabled(false);
				tf_2.setEnabled(false);
				tf_3.setEnabled(false);
				tf_4.setEnabled(false);
				tf_5.setEnabled(false);
				next_save=b_next.isEnabled();
				last_save=b_last.isEnabled();
				b_next.setEnabled(false);
				b_last.setEnabled(false);
				initSlot=slots_fortest.get(slot_index);
				initSlot.printSlot();
				b_predConfirm.setEnabled(false);
				b_predRivise.setEnabled(true);
			}
		});
		
		b_predRivise.addActionListener(new ActionListener()
		{
		
			@Override
			public void actionPerformed(ActionEvent event)
			{
				tf_0.setEnabled(true);
				tf_1.setEnabled(true);
				tf_2.setEnabled(true);
				tf_3.setEnabled(true);
				tf_4.setEnabled(true);
				tf_5.setEnabled(true);
				b_last.setEnabled(last_save);
				b_next.setEnabled(next_save);
				b_predConfirm.setEnabled(true);
				b_predRivise.setEnabled(false);
			}
		});
		
		b_pred.addActionListener(new ActionListener()
		{
		
			@Override
			public void actionPerformed(ActionEvent ev)
			{
				if( b_predConfirm.isEnabled() )
				{
					marker.log("Please set the initial state first!");
					return;
				}
				marker.log("predicting...");
				f_im_use=fb_im.getFile();
				f_mp_use=fb_mp.getFile();
				Ctbn ctbn2=new Ctbn(edges, nodes);
				ctbn2.readImFromFile(f_im_use);
				ctbn2.readMapperFromFile(f_mp_use);
				Predictor predictor=new Predictor(ctbn2);
				double posi=new Double(tf_5.getText());
				result=predictor.predictPaths(initSlot, posi);
				marker.log("Prediction finished!");
			}
		});
		
		
		b_result.addActionListener(new ActionListener() 
		{
		
			@Override
			public void actionPerformed(ActionEvent arg0)
			{
				if (result==null)
				{
					marker.log("This prediction has no result; there's no historical data can be used to predict in this case.");
					return;
				}
				
				mapPanel.printPaths(result);
				mapPanel.setTimeIndex(0);
				int length=0;
				for( int i=0; i<result.size(); i++ )
				{
					if( result.get(i).length()>length)
						length=result.get(i).length();
				}
				mapPanel.setMaxPathLength(length);
				mapPanel.resetMap();
			}
		});
		
		/*
		 * JTabbedPanel's actionListener
		 */
		tp.addChangeListener(new ChangeListener()
		{
			@Override
			public void stateChanged(ChangeEvent arg0)
			{
				int index=tp.getSelectedIndex();
				switch (index)
				{
				case 2:
					
					if (f_node==null || f_edge==null)
					{
						//System.out.println("node&edge file cannot be null");
						marker.log("Please set the node and edge file first!");
						tp.setSelectedIndex(0);
					}
					break;

				default:
					break;
				}
				
				
			}
		});
		
		
		add(tp);
	}
	
	
	private void setInitState(Slot slot)
	{
		//JTextField tf_0, tf_1, tf_2, tf_3, tf_4, tf_5;
		tf_0.setText(new Double(slot.getXCoordinate()).toString());
		tf_1.setText(new Double(slot.getYCoordinate()).toString());
		tf_2.setText(new Double(slot.getSpeed()).toString());
		tf_3.setText(new Double(slot.getNodeXCoordinate()).toString());
		tf_4.setText(new Double(slot.getNodeYCoordinate()).toString());
		repaint();
	}
	
	
	
	
	
	
	public void setMap(Nodes nodes, Edges edges)
	{
		mapPanel.setMap(nodes, edges);
	}
	

	

}
