package crimeminer.mining.trajectory.predictor.ui;

import javax.swing.*;



import crimeminer.mining.trajectory.predictor.core.Edges;
import crimeminer.mining.trajectory.predictor.core.Nodes;
import crimeminer.mining.trajectory.predictor.core.Path;
import crimeminer.mining.trajectory.predictor.core.Stamp;
import crimeminer.ui.CrimeMiner;
import crimeminer.ui.component.Marker;


import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.ArrayList;

public class EMapPanel extends JPanel
{
	Marker marker=CrimeMiner.m_globalManager.getMarker();
	
	EMap map;
	JPanel controlPanel;
	JPanel timePanel;
	JButton timeNextButton;
	JButton timeLastButton;
	JButton b_zoom_in;
	JButton b_left;
	JButton b_up;
	JButton b_reSet;
	JButton b_right;
	JButton b_down;
	JButton b_zoom_out;
	
	int maxPathLength=0;
	int original_size;
	
	//public EMapPanel(Nodes nodes, Edges edges, int size)
	public EMapPanel(int size)
	{
		original_size=size;
		setLayout(new GridBagLayout());
		GridBagConstraints constraints=new GridBagConstraints();
		map=new EMap(size);
		controlPanel=new JPanel();
		controlPanel.setLayout(new FlowLayout());
		
		b_zoom_in=new JButton("In");
		b_zoom_in.addActionListener(new ActionListener() {
		
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				//System.out.println("mapsize: "+map.getsize());
				map.setSize((int)(map.getsize()*1.3));
		
			}
		});
		
		b_left=new JButton("Left");
		b_left.addActionListener(new ActionListener() {
		
			@Override
			public void actionPerformed(ActionEvent e) {
				map.addOffsetX(0-(int)(map.getsize()*0.05));
				repaint();
			}
		});
		
		b_up=new JButton("Up");
		b_up.addActionListener(new ActionListener() {
		
			@Override
			public void actionPerformed(ActionEvent e) {
				map.addOffsetY(0-(int)(map.getsize()*0.05));
				repaint();
				//map.repaint();
			}
		});
		
		b_reSet=new JButton("RESET");
		b_reSet.addActionListener(new ActionListener() {
		
			@Override
			public void actionPerformed(ActionEvent e) {
				resetMap();
		
			}
		});
		
		b_right=new JButton("Right");
		b_right.addActionListener(new ActionListener() {
		
			@Override
			public void actionPerformed(ActionEvent e) {
				map.addOffsetX((int)(map.getsize()*0.05));
				repaint();
			}
		});
		
		b_down=new JButton("Down");
		b_down.addActionListener(new ActionListener() {
		
			@Override
			public void actionPerformed(ActionEvent e) {
				map.addOffsetY((int)(map.getsize()*0.05));
				repaint();
			}
		});
		
		b_zoom_out=new JButton("Out");
		b_zoom_out.addActionListener(new ActionListener() {
		
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				//System.out.println(map.getsize());
				map.setSize((int)(map.getsize()*0.7));
			}
		});
		
		controlPanel.add(b_zoom_in);
		controlPanel.add(b_left);
		controlPanel.add(b_up);
		controlPanel.add(b_reSet);
		controlPanel.add(b_right);
		controlPanel.add(b_down);
		controlPanel.add(b_zoom_out);
		
		timePanel=new JPanel();
		timeNextButton=new JButton(">");
		timeLastButton=new JButton("<");
		timeLastButton.setEnabled(false);
		timeNextButton.setEnabled(false);
		timePanel.setLayout(new GridBagLayout());
		constraints.gridx=0;
		constraints.gridy=0;
		constraints.gridwidth=1;
		constraints.weightx=1;
		constraints.insets=new Insets(0, 0, 0, 40);
		constraints.fill=GridBagConstraints.HORIZONTAL;
		timePanel.add(timeLastButton, constraints);
		constraints.gridx=1;
		constraints.insets=new Insets(0, 0, 0, 0);
		timePanel.add(new JLabel("Time Control"));
		constraints.gridx=2;
		constraints.insets=new Insets(0, 40, 0, 0);
		timePanel.add(timeNextButton, constraints);
		
		constraints.gridx=0;
		constraints.gridy=0;
		constraints.weightx=1;
		constraints.weighty=0.9;
		constraints.gridheight=1;
		constraints.anchor=GridBagConstraints.NORTH;
		constraints.fill=GridBagConstraints.BOTH;
		this.add(map, constraints);
		
		constraints.gridy=1;
		constraints.weighty=0.05;
		constraints.gridheight=1;
		constraints.fill=GridBagConstraints.NONE;
		this.add(controlPanel, constraints);
		
		constraints.gridy=2;
		this.add(timePanel, constraints);
		updateUI();
		
		
		timeNextButton.addActionListener(new ActionListener()
		{
		
			@Override
			public void actionPerformed(ActionEvent e)
			{
				map.setTimeIndex(map.getTimeIndex()+1);
				//System.out.println("timeIndex: "+map.getTimeIndex());
				marker.log("timeIndex: "+map.getTimeIndex());
				repaint();
				
				if (map.getTimeIndex()==maxPathLength-1) 
				{
					timeNextButton.setEnabled(false);
				}
				if( map.getTimeIndex()!=0 )
				{
					timeLastButton.setEnabled(true);
				}
				
			}
		});
		
		timeLastButton.addActionListener(new ActionListener() {
		
			@Override
			public void actionPerformed(ActionEvent arg0) 
			{

				map.setTimeIndex(map.getTimeIndex()-1);
				//System.out.println("timeIndex: "+map.getTimeIndex());
				marker.log("timeIndex: "+map.getTimeIndex());
				repaint();
				
				if (map.getTimeIndex()!=maxPathLength-1) 
				{
					timeNextButton.setEnabled(true);
				}
				if( map.getTimeIndex()==0 )
				{
					timeLastButton.setEnabled(false);
				}
			}
		});
	}
	
	public void setMap(Nodes nodes, Edges edges)
	{
		map.setMap(nodes, edges);
	}
	
	public void setTimeIndex(int index)
	{
		map.setTimeIndex(index);
	}
	
	public void printPaths(ArrayList<Path> paths)
	{
		map.setPaths(paths);
		timeNextButton.setEnabled(true);
	}
	
	public void setMaxPathLength(int length)
	{
		maxPathLength=length;
	}
	
	public void resetMap()
	{
		map.setSize(original_size);
		map.resetOffsets();
	}
	
	public static void main(String [] args)
	{
		/*
		 * read map data
		 */
		//read the node info
		String mapName="oldenburgGen";
		File nodeFile=new File("data/putmode/map/"+mapName+".node");
		//File nodeFile=new File("/home/douglass/workspace/mapManager/data/"+mapName+".node");
		Nodes nodes=new Nodes(nodeFile);
		//read the edge info
		File edgeFile=new File("data/putmode/map/"+mapName+".edge");
		//File edgeFile=new File("/home/douglass/workspace/mapManager/data/"+mapName+".edge");
		Edges edges=new Edges(edgeFile, nodes);
		
		//EMapPanel map=new EMapPanel(nodes, edges, 500);
		EMapPanel map=new EMapPanel(600);
		map.setMap(nodes, edges);
		
		Stamp a=new Stamp();
		Stamp b=new Stamp();
		Stamp c=new Stamp();
		Stamp d=new Stamp();
		a.setVal(19645.0 ,12515.0 ,0);
		b.setVal(19700.92947378259 ,12496.214527889817 ,1);
		c.setVal(19756.858947565182 ,12477.429055779634 ,2);
		d.setVal(19800.913517792484 ,12445.453087687367 ,3);
		Path path=new Path();
		path.addStamp(a);
		path.addStamp(b);
		path.addStamp(c);
		path.addStamp(d);
		ArrayList<Path> paths=new ArrayList<Path>();
		paths.add(path);
		map.printPaths(paths);
		
		
		JFrame frame=new JFrame("EMapPanel");
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(800, 800);
		frame.getContentPane().add(map);
		//frame.pack();
		
	}
}
