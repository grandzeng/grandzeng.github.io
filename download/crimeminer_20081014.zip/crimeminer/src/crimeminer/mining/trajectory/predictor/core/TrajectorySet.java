package crimeminer.mining.trajectory.predictor.core;
import java.util.*;
import java.io.*;
public class TrajectorySet implements Serializable 
{
	private ArrayList<Trajectory> trajectorySet=new ArrayList<Trajectory>();
	
	//to read the data from the file, and create the trajectorySet
	public void buildSet(File fileName)
	{
		try
		{
			BufferedReader br=new BufferedReader( new InputStreamReader( new FileInputStream(fileName)));
			String data=null;
			while ( (data=br.readLine())!=null )
			{				
				//LineTokenSeperater lts=new LineTokenSeperater(data);//to get tokens in a line of the data file
				StringTokenizer lts=new StringTokenizer(data, " \t");
				String s;
				//int i=0;
				while( lts.hasMoreTokens() )
				{
					
					//System.out.println(i++);
					
					s=lts.nextToken();
					if ( s.equals("newpoint") )
					{
						//System.out.println("np");
						int iden=Integer.parseInt(lts.nextToken());
						Trajectory t=new Trajectory(iden);
						int seq=Integer.parseInt(lts.nextToken());
						int class_iden=Integer.parseInt(lts.nextToken());
						int ts=Integer.parseInt(lts.nextToken());
						double x=Double.parseDouble(lts.nextToken());
						double y=Double.parseDouble(lts.nextToken());
						double spd=Double.parseDouble(lts.nextToken());
						double nod_x=Double.parseDouble(lts.nextToken());
						double nod_y=Double.parseDouble(lts.nextToken());
						Slot tmp=new Slot(iden, seq, class_iden, ts, x, y, spd, nod_x, nod_y);
						
						t.addSlot(tmp);
						trajectorySet.add(t);
						
						
					}
					else if( s.equals("point"))
					{
						//System.out.println("p");
						int iden=Integer.parseInt(lts.nextToken());
						int seq=Integer.parseInt(lts.nextToken());
						int class_iden=Integer.parseInt(lts.nextToken());
						int ts=Integer.parseInt(lts.nextToken());
						double x=Double.parseDouble(lts.nextToken());
						double y=Double.parseDouble(lts.nextToken());
						double spd=Double.parseDouble(lts.nextToken());
						double nod_x=Double.parseDouble(lts.nextToken());
						double nod_y=Double.parseDouble(lts.nextToken());
						Slot tmp=new Slot(iden, seq, class_iden, ts, x, y, spd, nod_x, nod_y);
						
						if( trajectorySet.get(iden).getId()==iden)
						{
							trajectorySet.get(iden).addSlot(tmp);
						}
							
						else System.out.println("the slot has been placed into the wrong position");
					}
				}
				
			}
		}
		catch( Exception ex)
		{
			System.out.println(ex);
			System.exit(0);
		}
		
	}

	public void buildSet(File fileName, int base)
	{
		try
		{
			BufferedReader br=new BufferedReader( new InputStreamReader( new FileInputStream(fileName)));
			String data=null;
			while ( (data=br.readLine())!=null )
			{				
				//LineTokenSeperater lts=new LineTokenSeperater(data);//to get tokens in a line of the data file
				StringTokenizer lts=new StringTokenizer(data, " \t");
				String s;
				//int i=0;
				while( lts.hasMoreTokens() )
				{
					
					//System.out.println(i++);
					
					s=lts.nextToken();
					if ( s.equals("newpoint") )
					{
						//System.out.println("np");
						int iden=base+Integer.parseInt(lts.nextToken());
						Trajectory t=new Trajectory(iden);
						int seq=Integer.parseInt(lts.nextToken());
						int class_iden=Integer.parseInt(lts.nextToken());
						int ts=Integer.parseInt(lts.nextToken());
						double x=Double.parseDouble(lts.nextToken());
						double y=Double.parseDouble(lts.nextToken());
						double spd=Double.parseDouble(lts.nextToken());
						double nod_x=Double.parseDouble(lts.nextToken());
						double nod_y=Double.parseDouble(lts.nextToken());
						Slot tmp=new Slot(iden, seq, class_iden, ts, x, y, spd, nod_x, nod_y);
						
						t.addSlot(tmp);
						trajectorySet.add(t);
						
						
					}
					else if( s.equals("point"))
					{
						//System.out.println("p");
						int iden=base+Integer.parseInt(lts.nextToken());
						int seq=Integer.parseInt(lts.nextToken());
						int class_iden=Integer.parseInt(lts.nextToken());
						int ts=Integer.parseInt(lts.nextToken());
						double x=Double.parseDouble(lts.nextToken());
						double y=Double.parseDouble(lts.nextToken());
						double spd=Double.parseDouble(lts.nextToken());
						double nod_x=Double.parseDouble(lts.nextToken());
						double nod_y=Double.parseDouble(lts.nextToken());
						Slot tmp=new Slot(iden, seq, class_iden, ts, x, y, spd, nod_x, nod_y);
						
						if( trajectorySet.get(iden).getId()==iden)
						{
							trajectorySet.get(iden).addSlot(tmp);
						}
							
						else System.out.println("the slot has been placed into the wrong position");
					}
				}
				
			}
		}
		catch( Exception ex)
		{
			System.out.println(ex.getMessage());
			System.exit(0);
		}
		
	}

	
	public void buildSet(File f1, File f2, File f3, File f4)
	{
		this.buildSet(f1);
		this.buildSet(f2, this.getTrajectoryAmount());
		this.buildSet(f3, this.getTrajectoryAmount());
		this.buildSet(f4, this.getTrajectoryAmount());
	}
	
	//to get a string of tokens from a single line(String) seperated by a space
	private class LineTokenSeperater
	{
		private String data;
		private int pointer;
		private ArrayList<Character> tmp=new ArrayList<Character>();
		LineTokenSeperater(String s)
		{
			data=s;
			pointer=0;
		}
		public String nextToken()
		{
			String s;
			tmp.clear();
			if( data.length()==0 || pointer>=data.length()) return null;
			while( data.charAt(pointer)==' ' || data.charAt(pointer)=='\t' )
			{
				pointer++;
			}
			if( data.length()==0 || pointer==data.length()) return null;
			else
			{
				while( pointer!=data.length() && data.charAt(pointer)!=' ' && data.charAt(pointer)!='\t')
				{
					tmp.add(data.charAt(pointer));
					pointer++;
				}
				
				char[] r=new char[tmp.size()];
				for( int i=0; i<tmp.size(); i++ ) r[i]=tmp.get(i);
				s=new String(r);				
				return s;
			}
		}
	}
	
	//to get the array of all x_coordinates of all points in this trajectory
	public double [] getXCoordinates(int trajectoryId)
	{
		if ( trajectoryId>trajectorySet.size() )
		{
			System.out.println("The trajectory is invalid.");
			System.exit(0);
		}
		
		double [] result=new double[trajectorySet.get(trajectoryId).getSlotAmount()];
		for( int i=0; i<result.length; i++ )
		{
			result[i]=trajectorySet.get(trajectoryId).getSlot(i).getXCoordinate();
		}
		return result;
	}
	
	//to get the array of all y_coordinates of all points in this trajectory
	public double [] getYCoordinates(int trajectoryId)
	{
		if ( trajectoryId>trajectorySet.size() )
		{
			System.out.println("The trajectory is invalid.");
			System.exit(0);
		}
		
		double [] result=new double[trajectorySet.get(trajectoryId).getSlotAmount()];
		for( int i=0; i<result.length; i++ )
		{
			result[i]=trajectorySet.get(trajectoryId).getSlot(i).getYCoordinate();
		}
		return result;
	}
	
	//to get the array of all x_coordinates of all points in this trajectory
	public double [] getTimeStamps(int trajectoryId)
	{
		if ( trajectoryId>trajectorySet.size() )
		{
			System.out.println("The trajectory is invalid.");
			System.exit(0);
		}
		
		double [] result=new double[trajectorySet.get(trajectoryId).getSlotAmount()];
		for( int i=0; i<result.length; i++ )
		{
			result[i]=trajectorySet.get(trajectoryId).getSlot(i).getTimeStamp();
		}
		return result;
	}
	
	//to get the array of all x_coordinates of all points in this trajectory
	public double [] getSpeeds(int trajectoryId)
	{
		if ( trajectoryId>trajectorySet.size() )
		{
			System.out.println("The trajectory is invalid.");
			System.exit(0);
		}
		
		double [] result=new double[trajectorySet.get(trajectoryId).getSlotAmount()];
		for( int i=0; i<result.length; i++ )
		{
			result[i]=trajectorySet.get(trajectoryId).getSlot(i).getSpeed();
		}
		return result;
	}
	
	//to get the trajectory by id
	public Trajectory getTrajectory(int id)
	{
		return trajectorySet.get(id);
	}
	
	//to get the amount of all trajectories in it
	public int getTrajectoryAmount()
	{
		return trajectorySet.size();
	}
	
	//to print the content of the trajectorySet
	public void printTrajectorySet()
	{
		System.out.println("******TrajectorySet---Print********");
		for( int i=0; i<trajectorySet.size(); i++ )
			trajectorySet.get(i).printTrajectory();
	}
	public void printTrajectorySet(int n)
	{
		System.out.println("******TrajectorySet---Print********");
		for( int i=0; i<trajectorySet.size(); i++ )
			trajectorySet.get(i).printTrajectory(n);
	}
	public void add(Trajectory t)
	{
		trajectorySet.add(t);
	}
}
