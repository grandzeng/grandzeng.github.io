package crimeminer.mining.trajectory.predictor.core;

import java.io.*;

public class Node implements Serializable
{
	private String name;
	private long id;
	private int x;
	private int y;
	//the status is used to indicate whether it is done or undone in the process of finding hotRegions.
	private boolean status;
	
	public Node()
	{
		name=null;
		id=-1;
		x=0;
		y=0;
		status=false;//the default status of it is undone
	}
	
	public Node(String name, long id, int x, int y)
	{
		this.setName(name);
		this.setId(id);
		this.setX(x);
		this.setY(y);
	}
	
	public Node(long x, long y)
	{
		this.setX((int)x);
		this.setY((int)y);
	}
	
	public Node(double x, double y)
	{
		this.setX((int)x);
		this.setY((int)y);
	}
	
	public void setName(String name)
	{
		this.name=name;
	}
	
	public String getName()
	{
		return name;
	}
	
	public void setId(long id)
	{
		this.id=id;
	}
	
	public long getId()
	{
		return id;
	}
	
	public void setX(int x)
	{
		this.x=x;
	}
	
	public int getX()
	{
		return x;
	}
	
	public void setY(int y)
	{
		this.y=y;
	}
	
	public int getY()
	{
		return y;
	}
	
	public void setStatus(boolean b)
	{
		status=b;
	}
	
	public boolean getStatus()
	{
		return status;
	}
	
	public boolean equals (Object node) {
		if (node == null)
			return false;
		return (id == ((Node)node).getId()); 
	}
	
	public int hashCode()
	{
		return (int)id;
	}
	
	public void print()
	{
		System.out.println("id: "+id+" x: "+x+" y: "+y);
	}
}
