package crimeminer.mining.trajectory.predictor.core;
import java.io.*;

public class Capsule implements Serializable
{
	public int x;
	public int y;
	public double content;
	
	public Capsule(Triple t)
	{
		x=t.getX();
		y=t.getY();
		content=t.getVal();
	}
	public Capsule()
	{
		x=1;
		y=1;
		content=0;
	}
}
