package crimeminer.mining.trajectory.predictor.ui;

import javax.swing.*;


import java.awt.*;
import java.io.File;

public class PutmodePanel extends JPanel
{	
	EMapPanel mapPanel;
	OpPanel opPanel;
	
	public PutmodePanel()
	{
		
		setLayout(new GridLayout(1,2));
		

		/*
		 * read map data
		
		//read the node info
		String mapName="oldenburgGen";
		//File nodeFile=new File("D:\\workspace\\mapManager\\data\\"+mapName+".node");
		File nodeFile=new File("data/putmode/map/"+mapName+".node");
		Nodes nodes=new Nodes(nodeFile);
		//read the edge info
		//File edgeFile=new File("D:\\workspace\\mapManager\\data\\"+mapName+".edge");
		File edgeFile=new File("data/putmode/map/"+mapName+".edge");
		Edges edges=new Edges(edgeFile, nodes);
		 */
		//mapPanel=new EMapPanel(nodes, edges, 500);
		mapPanel=new EMapPanel(400);
		
		add(mapPanel);
		opPanel=new OpPanel(mapPanel);
		add(opPanel);
	}
	
	public static void main(String [] args)
	{
		JFrame frame=new JFrame("putmodePanel");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		PutmodePanel putmodePanel=new PutmodePanel();
		frame.getContentPane().add(putmodePanel);
		frame.setSize(1000, 800);
	}
}
