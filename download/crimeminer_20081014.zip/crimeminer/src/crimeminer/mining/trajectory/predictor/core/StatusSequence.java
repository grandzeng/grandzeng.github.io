package crimeminer.mining.trajectory.predictor.core;
import java.util.*;

public class StatusSequence 
{
	private ArrayList<Integer> statusIds;
	private double prob;//��״̬���еĸ���
	
	public StatusSequence(int statusId)//��״̬���еĵ�һ��״̬id
	{
		statusIds=new ArrayList<Integer>();
		statusIds.add(new Integer(statusId));
		prob=1;
	}
	
	public void addStatus(int statusId, double probability)
	{
		statusIds.add(new Integer(statusId));
		prob=prob*probability;
	}
	
	public double getProbability()
	{
		return prob;
	}
	
	public int getStatusId(int index)
	{
			return statusIds.get(index);
	}
	
	public int getLastStatus()
	{
		return statusIds.get(statusIds.size()-1);
	}
	
	public Object clone()
	{
		StatusSequence result=new StatusSequence(statusIds.get(0));
		result.statusIds=(ArrayList<Integer>)this.statusIds.clone();
		result.prob=this.prob;
		return result;
	}
	
	public int size()
	{
		return statusIds.size();
	}
	
	public void print()
	{
		System.out.print("statuses: ");
		for( int i=0; i<statusIds.size(); i++ )
			System.out.print(statusIds.get(i)+" ");
		System.out.println(" prob: "+this.prob);
	}
	
	public static void main(String [] args)
	{
		StatusSequence s=new StatusSequence(3);
		s.print();
		s.addStatus(2, 0.5);
		s.addStatus(1, 0.5);
		s.print();
		StatusSequence b=(StatusSequence)s.clone();
		b.addStatus(0, 0.5);
		s.print();
		b.print();
		
	}
}
