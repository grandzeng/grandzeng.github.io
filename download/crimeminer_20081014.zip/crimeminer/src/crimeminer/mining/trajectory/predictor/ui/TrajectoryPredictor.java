package crimeminer.mining.trajectory.predictor.ui;

import javax.swing.*;
import java.awt.*;

import crimeminer.mining.Operator;
import crimeminer.ui.component.Marker;
import crimeminer.ui.component.Walker;

public class TrajectoryPredictor extends Operator
{
	private JPanel mainPanel;
	
	public TrajectoryPredictor()
	{
		mainPanel=new JPanel();
		mainPanel.setLayout(new BorderLayout());
	}
	
	public void run()
	{
		PutmodePanel putmodePanel=new PutmodePanel();
		mainPanel.add(putmodePanel, BorderLayout.CENTER);
		Walker walker = globalManager.getWalker();
		walker.removeAll();
		walker.addTab("trajectory predictor", mainPanel);
		Marker marker=globalManager.getMarker();
		marker.log("TrajectoryPredictor started!");
		
	}
}
