package crimeminer.mining.trajectory.predictor.core;
import java.io.*;
import java.util.*;

public class SparseMatrix implements Serializable
{
	private Triple head;
	
	public SparseMatrix()
	{
		head=new Triple();;
	}
	
	public void setVal(int x, int y, double val)
	{
		Triple t=new Triple(x, y, val);
		Triple pointer=head;
		while( pointer.getV_next()!=null && pointer.getV_next().getX()!=x )
			pointer=pointer.getV_next();
		
		if( pointer.getV_next()==null )
		{
			pointer.setV_next(t);
		}
		else
		{
			pointer=pointer.getV_next();
			if( pointer.getY()==y )
			{
				pointer.setVal(val);
				return;
			}
			while( pointer.getH_next()!=null && pointer.getH_next().getY()!=y )
				pointer=pointer.getH_next();
			
			if( pointer.getH_next()==null )
			{
				pointer.setH_next(t);
				return;
			}
			else
			{
				pointer.getH_next().setVal(val);
				return;
			}
		}
	}

	public void addVal(int x, int y, double val)
	{
		Triple t=new Triple(x, y, val);
		Triple pointer=head;
		while( pointer.getV_next()!=null && pointer.getV_next().getX()!=x )
			pointer=pointer.getV_next();
		
		if( pointer.getV_next()==null )
		{
			pointer.setV_next(t);
		}
		else
		{
			pointer=pointer.getV_next();
			if( pointer.getY()==y )
			{
				pointer.setVal(pointer.getVal()+val);
				return;
			}
			while( pointer.getH_next()!=null && pointer.getH_next().getY()!=y )
				pointer=pointer.getH_next();
			
			if( pointer.getH_next()==null )
			{
				pointer.setH_next(t);
				return;
			}
			else
			{
				pointer.getH_next().setVal(pointer.getH_next().getVal()+val);
				return;
			}
		}
	}
	
	public double getVal(int x, int y)
	{
		Triple pointer=head;
		while( pointer.getV_next()!=null && pointer.getV_next().getX()!=x )
			pointer=pointer.getV_next();
		
		if( pointer.getV_next()==null )
		{
			return 0;
		}
		else
		{
			pointer=pointer.getV_next();
			if( pointer.getY()==y )
				return pointer.getVal();
			while( pointer.getH_next()!=null && pointer.getH_next().getY()!=y )
				pointer=pointer.getH_next();
			
			if( pointer.getH_next()==null )
			{
				return 0;
			}
			else
				return pointer.getH_next().getVal();
		}
	}
	
	public void rebuild()//����ָ���ֲ��õ���IMת����������IM
	{
		Triple pointerV=head;
		while( pointerV.getV_next()!=null )
		{
			pointerV=pointerV.getV_next();
			double t=0;
			double mount=0;
			Triple pointerH=pointerV;
			if( pointerH.getX()==pointerH.getY() )
				;//t=pointerH.getVal();
			else
				mount+=pointerH.getVal();
			while( pointerH.getH_next()!=null )
			{
				pointerH=pointerH.getH_next();
				if( pointerH.getX()==pointerH.getY() )
					;//t=pointerH.getVal();
				else
					mount+=pointerH.getVal();
			}
			//System.out.println("time: "+t+" mount: "+mount);
			
			pointerH=pointerV;
			if( pointerH.getX()==pointerH.getY() )
				;//pointerH.setVal(mount/t);
			else
				pointerH.setVal(pointerH.getVal()/mount);
			while( pointerH.getH_next()!=null )
			{
				pointerH=pointerH.getH_next();
				if( pointerH.getX()==pointerH.getY() )
					;//pointerH.setVal(mount/t);
				else
					pointerH.setVal(pointerH.getVal()/mount);
			}
			
		}
		
	}
	
	public void print()
	{
		System.out.println("��ʼ�������");
		Triple pointerV=head;
		while( pointerV.getV_next()!=null )
		{
			//System.out.println("h");
			Triple pointerH=pointerV.getV_next();
			while( pointerH!=null )
			{
				pointerH.print();
				pointerH=pointerH.getH_next();
			}
			pointerV=pointerV.getV_next();
		}
	}
	
	public void println(int x)
	{
		Triple pointerV=head;
		while( pointerV.getV_next()!=null )
		{
			//System.out.println("h");
			if( pointerV.getV_next().getX()==x )
			{
				Triple pointerH=pointerV.getV_next();
				while( pointerH!=null )
				{
					pointerH.print();
					pointerH=pointerH.getH_next();
				}
				return;
			}
			pointerV=pointerV.getV_next();
		}
	}
	
	
	public void writeTo(File f) throws Exception
	{
		ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(f));
		System.out.println("��ʼ���ļ�д�����");
		Triple pointerV=head;
		//out.writeObject(new Capsule());
		
		while( pointerV.getV_next()!=null )
		{
			//System.out.println("h");
			Triple pointerH=pointerV.getV_next();
			while( pointerH!=null )
			{
				//pointerH.print();
				out.writeObject(new Capsule(pointerH));
				out.flush();
				pointerH=pointerH.getH_next();
			}
			pointerV=pointerV.getV_next();
		}
		
	}
	
	public boolean readFrom(File f) throws Exception
	{
		ObjectInputStream in=new ObjectInputStream(new FileInputStream(f));
		System.out.println("��ʼ���ļ���ȡ����");
		this.clear();
		try
		{
			while( true )
			{
				Capsule tmp=(Capsule)in.readObject();
				this.addVal(tmp.x, tmp.y, tmp.content);
			}
		}
		catch(EOFException eof)
		{
			return true;
		}
	}

	
	public void clear()
	{
		head=new Triple();
	}
	
	public boolean getRow(int rowNum,ArrayList<Integer> columnNum, ArrayList<Double> value)//�����кţ��õ��кźͶ�Ӧ�кŵ�ֵ
	{
		Triple pointer=head;
		while( pointer.getV_next()!=null && pointer.getV_next().getX()!=rowNum )
			pointer=pointer.getV_next();
		
		if( pointer.getV_next()==null )
		{
			return false;
		}
		else
		{
			boolean flag=false;
			pointer=pointer.getV_next();
			if( pointer.getVal()!=0 )
				flag=true;
			while( pointer!=null )
			{
				columnNum.add(new Integer(pointer.getY()));
				value.add(new Double(pointer.getVal()));
				pointer=pointer.getH_next();
			}
			return true;
		}
	}
	
	
	
	
	public static void main(String [] args)
	{
		
		SparseMatrix s=new SparseMatrix();
		s.setVal(0, 0, 14);
		s.setVal(0, 1, 0.3);
		s.setVal(0, 2, 0.7);
		s.setVal(1, 0, 1);
		s.setVal(1, 1, 2);
		//s.setVal(1, 2, 0);
		s.setVal(2, 0, 0);
		s.setVal(2, 1, 0);
		s.setVal(2, 2, 0);
		ArrayList<Integer> column=new ArrayList<Integer>();
		ArrayList<Double> value=new ArrayList<Double>();
		System.out.println(s.getRow(2, column, value));
		for( int i=0; i<column.size(); i++ )
			System.out.println(column.get(i).intValue()+" ");
		for( int i=0; i<column.size(); i++ )
			System.out.println(value.get(i).doubleValue()+" ");
		
		s.println(0);
		//s.getRow(0, column, value);
		//s.rebuild();
		//s.print();
	}

}
