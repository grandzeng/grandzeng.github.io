package crimeminer.mining.trajectory.predictor.core;

import java.awt.print.Printable;


public class Status 
{
	public static int NORTH=0;
	public static int SOUTH=1;
	public static int EAST=2;
	public static int WEST=3;
	
	public static int L_1=4;
	public static int L_2=5;
	public static int L_3=6;
	public static int L_4=7;
	public static int L_5=8;
	public static int L_6=9;
	
	//this is for the oldenburg data set
	public static double L=33.5;
	public static double ML=75;
	public static double M=100.5;
	public static double MH=150;
	public static double H=183.5;
	
	
	/*
	//this is for the CA data set
	public static double L=324.5;
	public static double ML=649;
	public static double M=973.5;
	public static double MH=1298;
	public static double H=1622.5;
	*/
	
	private long edgeId;//�������ڱߵı��
	//private double duration;//�����ڸ�������������ʱ��
	private int direction;//�����ڸ������ϵ��˶�����
	private int speedLevel;//������ٶȴ�С�����٣����٣�����
	
	public Status(long edgeId, int direction, int speedLevel)
	{
		this.edgeId=edgeId;
		this.direction=direction;
		this.speedLevel=speedLevel;
	}
	public Status()
	{
		this.setDirection(-1);
		this.setEdgeId(-1);
		this.setSpeedLevel(-1);
	}
	
	public static void setMaxSpeed(double highestSpeed)
	{
		Status.H=highestSpeed;
		Status.L=Status.H/5;
		Status.ML=Status.L*2;
		Status.M=Status.L*3;
		Status.MH=Status.L*4;
	}
	
	public void setEdgeId(long id)
	{
		edgeId=id;
	}
	
	public long getEdgeId()
	{
		return edgeId;
	}
	
	public void setDirection(int i)
	{
		direction=i;
	}
	
	public int getDirection()
	{
		return direction;
	}
	
	public void setSpeedLevel(int l)
	{
		speedLevel=l;
	}
	
	public int getSpeedLevel()
	{
		return speedLevel;
	}
	
	public double getSpeed()
	{
		if( this.speedLevel==Status.L_1 )
			return Status.L/2;
		else if( this.speedLevel==Status.L_2 )
			return (Status .L+Status.ML)/2.0;
		else if( this.speedLevel==Status.L_3 )
			return (Status .ML+Status.M)/2.0;
		else if( this.speedLevel==Status.L_4 )
			return (Status .M+Status.MH )/2.0;
		else if( this.speedLevel==Status.L_5 )
			return (Status.MH+Status.H )/2.0;
		else if( this.speedLevel==Status.L_6 )
			return Status.H+Status.L/2;
		else
		{
			System.err.println("something wrong happened in Status.getspeed()");
			return 0;
		}
	}
	
	public void print()
	{
		System.out.println("edgeId: "+edgeId+" direction: "+direction+" speedLevel: "+speedLevel);
		//System.out.println("speedL: "+L+" speedML: "+ML+" speedM: "+M+" speedMH: "+MH+" speedH: "+H);
	}
	
	public boolean equals(Object status)
	{
		Status s=(Status)status;
		if( status==null )
			return false;
		else if( s.getDirection()==this.getDirection() && s.getEdgeId()==this.getEdgeId() && s.getSpeedLevel()==this.getSpeedLevel() )
			return true;
		else
			return false;
	}
	
	
	
}
