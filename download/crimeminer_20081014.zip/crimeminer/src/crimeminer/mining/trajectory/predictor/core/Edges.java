package crimeminer.mining.trajectory.predictor.core;

import java.util.*;
import java.io.*;

public class Edges implements Serializable
{
	private Hashtable<Edge, Edge> hashtable=null;
	//private long edgeCounter=0;
	
	public Edges(File edgefile, Nodes nodes)
	{
		hashtable=new Hashtable<Edge, Edge>(10000);
		try
		{
			
			DataInput in=new DataInputStream(new FileInputStream(edgefile));
			while( true )
			{
				Edge tmp=this.read(in, nodes);
				if( tmp==null )
					break;
				this.addEdge(tmp);
			}
			
		}
		catch(IOException ex)
		{
			System.err.println(ex);
			System.exit(0);
		}
	}
	
	private void addEdge(Edge edge)
	{
		hashtable.put(edge, edge);
	}
	
	private Edge read(DataInput in, Nodes nodes)
	{
		try
		{
			long id1=in.readLong();
			long id2=in.readLong();
			byte len=in.readByte();
			Node node1=nodes.getNode(id1);
			Node node2=nodes.getNode(id2);
			//System.err.println(id1+","+id2);
			if( len>0 )
			{
				byte[] data=new byte[len];
				in.readFully(data);
				long eId=in.readLong();
				int eClass=in.readInt();
				return new Edge(node1, node2, new String(data), eId, eClass);
			}
			else
			{
				long eId=in.readLong();
				int eClass=in.readInt();
				return new Edge(node1, node2, null, eId, eClass);
			}
		}
		catch(EOFException ex)
		{
			return null;
		}
		catch(Exception ex)
		{
			System.err.println(ex);
			System.exit(0);
			return null;
		}
	}
	
	//get the edge that contains the nodes with id nodeId1 and nodeId2
	public Edge getEdge(long nodeId1, long nodeId2)
	{
		
		Node node1=new Node(null,nodeId1,0,0);
		Node node2=new Node(null,nodeId2,0,0);
		Edge e=new Edge( node1, node2, null, 0, 0);
		Edge result= hashtable.get(e);
		if( result!=null )
			return result;
		else
		{
			e=new Edge( node2, node1, null, 0, 0);
			return hashtable.get(e);
		}
	}
	
	//get edge by id
	public Edge getEdge(long edgeId)
	{
		Enumeration<Edge> e=hashtable.keys();
		while( e.hasMoreElements() )
		{
			Edge edge=e.nextElement();
			if( edge.getId()==edgeId )
				return edge;
		}
		return null;
	}
	
	//get the edges that contain the node n
	public ArrayList<Edge> getEdges(Node n)
	{
		ArrayList<Edge> result=new ArrayList<Edge>();
		Enumeration<Edge> e=hashtable.keys();
		while(e.hasMoreElements())
		{
			Edge edge=e.nextElement();
			if( edge.getNode1().getId()==n.getId() || edge.getNode2().getId()==n.getId() )
				result.add(edge);
		}
		return result;
	}
	
	public Enumeration<Edge> getAllEdges()
	{
		Enumeration<Edge> e=hashtable.keys();
		return e;
	}
	
	public int getEdgeNum()
	{
		int c=0;
		Enumeration<Edge> e=hashtable.keys();
		if( e==null )
			return -1;
		while(e.hasMoreElements())
		{
			e.nextElement();
			c++;
		}
		
		return c;
	}
	

	
	public void print()
	{
		//System.out.println("flag1");
		Enumeration<Edge> e=hashtable.keys();
		if( e==null )
			return;
		//int c=0;
		while( e.hasMoreElements() )
		{
			//c++;
			Edge edge=e.nextElement();
			//System.out.println("flag2");
			edge.print();
		}
		//System.out.println(c+" edges in total!");
		
	}
	


	
}

