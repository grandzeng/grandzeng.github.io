package crimeminer.mining.trajectory.predictor.core;
import java.util.*;


public class Path 
{
	private ArrayList<Stamp> stamps;
	public Path()
	{
		stamps=new ArrayList<Stamp>();
	}
	
	public void addStamp(Stamp stamp)
	{
		stamps.add(stamp);
	}
	
	public Stamp getStamp(int sn)
	{
		return stamps.get(sn);
	}
	
	public int getStampNum()
	{
		return stamps.size();
	}
	public void print()
	{
		System.out.println("path: ");
		for( int i=0; i<stamps.size(); i++ )
			System.out.print(" "+stamps.get(i));
			
	}
	
	public int length()
	{
		return stamps.size();
	}
	public void print(int n)
	{
		System.out.println("path: ");
		for( int i=0; i<(stamps.size()<n? stamps.size(): n); i++ )
			System.out.println(" "+stamps.get(i));
			
	}
}
