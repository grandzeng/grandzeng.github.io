package crimeminer.mining.reproccess;

import crimeminer.mining.Operator;
import javax.swing.*;
public class Help extends Operator {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		this.globalManager.getMarker().log("Help.run() is called ");
		JOptionPane.showMessageDialog(null, "Crime miner 1.0", "About crime miner", JOptionPane.INFORMATION_MESSAGE);
		
	}

}
