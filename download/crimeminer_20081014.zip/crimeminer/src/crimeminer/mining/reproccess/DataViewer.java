package crimeminer.mining.reproccess;

import crimeminer.core.Instances;
import crimeminer.mining.Operator;
import crimeminer.ui.component.Walker;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;

public class DataViewer extends Operator {

	private JPanel viewPane = new JPanel();
	private JTable table;

	public DataViewer() {
		viewPane.setLayout(new BorderLayout());
		if (globalManager.getInstances() == null) {
			table = new JTable();
		} else {
			table = new JTable(new DataViewerModel());
			setCellEditor();
		}
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		if (globalManager.getInstances() == null) {
			JLabel label = new JLabel("Please Load data set first");
			label.setForeground(Color.RED);
			label.setHorizontalAlignment(SwingConstants.CENTER);
			label.setBorder(BorderFactory.createEtchedBorder());
			viewPane.add(label, BorderLayout.CENTER);
		} else {
			JScrollPane pane = new JScrollPane(table);
			viewPane.add(pane, BorderLayout.CENTER);
		}
		Walker walker = globalManager.getWalker();
		walker.removeAll();
		walker.addTab("data view", viewPane);
	}

	private void setCellEditor() {
		if (globalManager.getInstances() == null)
			return;
		TableColumnModel columnModel = table.getColumnModel();
		Instances instances = globalManager.getInstances();

		for (int i = 0; i < instances.getAttributesNum(); i++) {
			if (instances.getAttributeAt(i).isNominalType()) {
				JComboBox combo = new JComboBox();
				combo.setEditable(true);
				int count = instances.getAttributeAt(i).getNominalCount();
				for (int j = 0; j < count; j++) {
					Object value = instances.getAttributeAt(i)
							.MapToValue(j + 1);
					combo.addItem(value);
				}
				columnModel.getColumn(i).setCellEditor(
						new DefaultCellEditor(combo));
			}
		}
	}

	class DataViewerModel extends DefaultTableModel {

		@Override
		public int getColumnCount() {
			if (globalManager.getInstances() == null)
				return 0;
			return globalManager.getInstances().getAttributesNum();
		}

		@Override
		public int getRowCount() {
			if (globalManager.getInstances() == null)
				return 0;
			return globalManager.getInstances().getInstancesNum();
		}

		@Override
		public Object getValueAt(int row, int column) {
			if (globalManager.getInstances().getAttributeAt(column)
					.isNominalType()
					|| globalManager.getInstances().getAttributeAt(column)
							.isDateType()) {
				int value = (int) globalManager.getInstances().getInstanceAt(
						row).getValueAt(column);
				return globalManager.getInstances().getAttributeAt(column)
						.MapToValue(value);
			}
			return globalManager.getInstances().getInstanceAt(row).getValueAt(
					column);

		}

		@Override
		public void setValueAt(Object value, int row, int column) {
			// TODO Auto-generated method stub
			Instances instances = globalManager.getInstances();
			if (instances.getAttributeAt(column).isNominalType()) {
				double v = (double) instances.getAttributeAt(column)
						.addAttributeValue(value);
				instances.getInstanceAt(row).setValueAt(column, v);
			} else if (globalManager.getInstances().getAttributeAt(column)
					.isDateType()) {
				double v;
				if (value.equals(""))
					v = (double) instances.getAttributeAt(column)
							.addAttributeValue(value);
				else {
					java.sql.Date date = java.sql.Date.valueOf((String) value);
					v = (double) instances.getAttributeAt(column)
							.addAttributeValue(date);
				}
				instances.getInstanceAt(row).setValueAt(column, v);
			} else {
				double v;
				try {
					v = Double.parseDouble((String) value);
				} catch (Exception ex) {
					// ex.printStackTrace();
					globalManager.getMarker().log("converting error due to some format error");
					return;
				}
				instances.getInstanceAt(row).setValueAt(column, v);
			}
		}

		@Override
		public String getColumnName(int column) {
			if (globalManager.getInstances() == null)
				return null;
			return globalManager.getInstances().getAttributeAt(column)
					.getName();
		}
	}

}
