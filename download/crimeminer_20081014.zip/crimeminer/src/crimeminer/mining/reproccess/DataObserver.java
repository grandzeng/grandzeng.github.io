package crimeminer.mining.reproccess;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import crimeminer.util.dbi.*;
import crimeminer.core.*;
import crimeminer.global.GlobalManager;
import crimeminer.mining.*;
import crimeminer.ui.*;

import org.jfree.chart.JFreeChart;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.PolarChartPanel;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

public class DataObserver extends JPanel {
	// ���ݿ���ʽӿ�
	private DBI dbi = new DBI();

	// �г��������ݿ��еı�
	private JComboBox tables;

	// ��ǰѡ�еı�������������ʾ�����table��
	private JTable attributes;

	// ��ѡ��һ�ű���һ�����Ժ���Ӧ��������Ϣ��
	private JTable selectedAttribute;

	// ��ȡ���ı����ݣ���ʾΪһ��Instances
	private Instances instances;

	// ѡ������
	private Boolean[] checked;

	// ���еı���
	private ArrayList<String> tableNames;

	// ȫ�ֶ����������Ҳ�ǳ���Ľӿ�
	private GlobalManager globalManager;
	// ����JfreeChart ��dataset
	private DefaultCategoryDataset dataset = new DefaultCategoryDataset();
	// ����JFreeChart ͼ
	private JFreeChart chart = ChartFactory.createBarChart("Bar Chart",
			"Category", "Value", dataset, PlotOrientation.VERTICAL, true, true,
			false);
	private ChartPanel chartPanel = new ChartPanel(chart);
	// ���е����Եļ���Ϣ
	private Properties[] props;
	// ��ǰѡ�е����Ա��
	private int attribute_index = 0;
	// ��ǰѡ�еı���
	private String table_name;

	// ���캯��
	public DataObserver() {

		globalManager = CrimeMiner.m_globalManager;
		initTables();
		read();
		deploy();

	}

	// ���캯��
	public DataObserver(GlobalManager gm) {
		this();
		globalManager = gm;
	}

	// ��ʼ�����г����еı���
	public void initTables() {
		try {
			tableNames = dbi.listTables();
			if (tableNames == null || tableNames.size() == 0)
				throw new Exception("There is no tables in the database");
			table_name = tableNames.get(0);
		} catch (Exception ex) {
			globalManager.getMarker().log(ex.toString());
			ex.printStackTrace();
		}
	}

	// read the data from a specific table in the database
	// ��ȡ���ݴ�ѡ�������ݱ���
	public void read() {
		try {
			instances = dbi.readInstances(table_name);

			int size = instances.getAttributesNum();
			checked = new Boolean[size];
			for (int i = 0; i < size; i++) {
				checked[i] = Boolean.FALSE;
			}
			// ͳ�����Ե�ֵ
			props = new Properties[size];
			for (int index = 0; index < size; index++) {
				props[index] = new Properties();
				if (instances.getAttributeAt(index).isNumericType()) {
					double min = Double.MAX_VALUE, max = Double.MIN_VALUE, mean = 0.0;
					for (int j = 0; j < instances.getInstancesNum(); j++) {
						double temp = instances.getInstanceAt(j).getValueAt(
								index);
						min = (min > temp) ? temp : min;
						max = (max < temp) ? temp : max;
						mean += temp;
					}
					mean = mean / instances.getInstancesNum();
					props[index].put("min", min);
					props[index].put("max", max);
					props[index].put("mean", mean);
				} else if (instances.getAttributeAt(index).isNominalType()
						|| instances.getAttributeAt(index).isDateType()) {
					int count = instances.getAttributeAt(index)
							.getNominalCount();
					if (count == -1)
						continue;
					int[] counter = new int[count];
					for (int j = 0; j < instances.getInstancesNum(); j++) {
						double temp = instances.getInstanceAt(j).getValueAt(
								index);
						if (temp > 0 && temp <= count)
							counter[((int) temp - 1)]++;
					}

					for (int v = 0; v < counter.length; v++) {
						Object key = instances.getAttributeAt(index)
								.MapToValue(v + 1);
						props[index].put(key, counter[v]);
					}

				}
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			globalManager.getMarker().log(e.toString());
			e.printStackTrace();
		}
	}

	// deploy the ui interface
	public void deploy() {

		setLayout(new BorderLayout());
		alignTop();
		alignCenter();
		alignBottom();
	}

	// deploy the top panel
	private void alignTop() {
		JPanel top = new JPanel();

		JLabel left = new JLabel();
		JLabel right = new JLabel();

		// temp
		String[] values = new String[tableNames.size()];
		for (int i = 0; i < tableNames.size(); i++) {
			values[i] = tableNames.get(i);
		}
		tables = new JComboBox(values);
		tables.setSelectedItem(values[0]);

		// tables.setBorder(BorderFactory.createTitledBorder("choose"))
		top.setLayout(new GridBagLayout());
		GridBagConstraints constraints = new GridBagConstraints();
		constraints.gridx = 0;
		constraints.gridy = 0;
		constraints.gridwidth = 1;
		constraints.gridheight = 1;
		constraints.anchor = GridBagConstraints.NORTHWEST;
		constraints.fill = GridBagConstraints.HORIZONTAL;
		constraints.weightx = 100;
		constraints.weighty = 0;
		top.add(left, constraints);

		constraints.gridx = 1;
		top.add(tables, constraints);

		constraints.gridx = 2;
		top.add(right, constraints);

		top.setBorder(BorderFactory.createTitledBorder("choose the table"));
		add(top, BorderLayout.NORTH);

		tables.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				table_name = (String) tables.getSelectedItem();
				read();
				attributes.clearSelection();
				attribute_index = 0;
				((DefaultTableModel) (attributes.getModel()))
						.fireTableDataChanged();
				// attributes.clearSelection();
				attributes.setRowSelectionInterval(0, 0);

				// attributes.addRowSelectionInterval(0, 0);
			}

		});

	}

	// deploy the center panel
	private void alignCenter() {
		JPanel center = new JPanel();
		JSplitPane Scenter = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, true);
		center.setLayout(new BorderLayout());
		center.add(Scenter, BorderLayout.CENTER);
		Scenter.setOneTouchExpandable(true);
		Scenter.setResizeWeight(0);

		attributes = new JTable(new AttributesModel());
		attributes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		attributes.getSelectionModel().addListSelectionListener(
				new ListSelectionListener() {
					@Override
					public void valueChanged(ListSelectionEvent e) {
						attribute_index = attributes.getSelectedRow();
						((DefaultTableModel) selectedAttribute.getModel())
								.fireTableDataChanged();
						// return;
						// ��Ӧ��JFreeChart��ͼ�ı仯
						if (attribute_index == -1)
							return;
						dataset = new DefaultCategoryDataset();
						// �������������
						if (instances.getAttributeAt(attribute_index)
								.isNumericType()) {
							double min = (Double) props[attribute_index]
									.get("min");
							double max = (Double) props[attribute_index]
									.get("max");
							// �����������Զ�����Ϊ5�����䣬��ͳ��ÿ�����������
							double intervals[] = new double[4];
							for (int i = 1; i <= intervals.length; i++)
								intervals[i - 1] = min + i * ((max - min) / 5);

							int counts[] = new int[5];
							String series[] = new String[5];

							for (int i = 0; i < series.length; i++) {
								if (i == 0)
									series[i] = "[" + min + "," + intervals[i]
											+ "]";
								else if (i == series.length - 1)
									series[i] = "[" + intervals[i - 1] + ","
											+ max + "]";
								else
									series[i] = "[" + intervals[i - 1] + ","
											+ intervals[i] + "]";
							}
							// ͳ�ƶ�Ӧ���������
							for (int j = 0; j < instances.getInstancesNum(); j++) {
								double temp = instances.getInstanceAt(j)
										.getValueAt(attribute_index);
								for (int t = 0; t <= intervals.length; t++) {

									if (t == intervals.length) {
										counts[t]++;
									} else {
										if (temp <= intervals[t]) {
											counts[t]++;
											break;
										}
									}
								}
							}
							// ����Jfree chart�����ݼ�
							for (int index = 0; index < series.length; index++) {
								dataset.addValue(counts[index], series[index],
										"count");
							}

						}
						// ���������������
						else if (instances.getAttributeAt(attribute_index)
								.isNominalType()
								|| instances.getAttributeAt(attribute_index)
										.isDateType()) {
							for (int index = 0; index < instances
									.getAttributeAt(attribute_index)
									.getNominalCount(); index++) {
								String value = (String) instances
										.getAttributeAt(attribute_index)
										.MapToValue(index + 1).toString();
								int count;
								if (instances.getAttributeAt(attribute_index)
										.isNominalType())
									count = ((Integer) props[attribute_index]
											.get(value)).intValue();
								else {
									if (value.equals(""))
										count = ((Integer) props[attribute_index]
												.get(value)).intValue();
									else
										count = ((Integer) props[attribute_index]
												.get(java.sql.Timestamp
														.valueOf(value)))
												.intValue();
								}
								dataset.addValue(count, value, "count");
								globalManager.getMarker().log(
										index
												+ "/"
												+ instances.getAttributeAt(
														attribute_index)
														.getNominalCount());
//								System.out.println(index
//										+ "/"
//										+ instances.getAttributeAt(
//												attribute_index)
//												.getNominalCount());
							}
						}

						boolean legend = true;
						if (dataset.getRowCount() > 100)
							legend = false;

						chart = ChartFactory.createBarChart("Attributes",
								"Attribute", "Value", dataset,
								PlotOrientation.VERTICAL, legend, true, false);
						// CategoryPlot plot = chart.getCategoryPlot();

						chartPanel.setChart(chart);
					}
				});
		// attributes.setPreferredSize(new Dimension(50,50));
		JPanel left = new JPanel();
		left.setLayout(new BorderLayout());
		JScrollPane sleft = new JScrollPane(attributes);
		left.add(sleft, BorderLayout.CENTER);
		JButton remove = new JButton("Remove");
		remove.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				int count = 0;
				for (int m = 0; m < checked.length; m++)
					if (checked[m])
						count++;
				if (count == checked.length) {
					JOptionPane.showMessageDialog(null,
							"can not be remove all the attributes");
					return;
				}
				for (int i = checked.length - 1; i >= 0; i--) {
					if (checked[i]) {
						instances.removeAttributeAt(i);
					}
				}

				Properties[] pTmp = new Properties[checked.length - count];
				Boolean[] ck = new Boolean[checked.length - count];
				for (int j = 0, c = 0; j < checked.length; j++) {
					if (!checked[j]) {
						pTmp[c] = props[j];
						ck[c] = checked[j];
						c++;
					}
				}
				props = pTmp;
				checked = ck;
				attributes.clearSelection();
				attribute_index = 0;
				((DefaultTableModel) attributes.getModel())
						.fireTableDataChanged();
				attributes.getSelectionModel().addSelectionInterval(0, 0);
				((DefaultTableModel) selectedAttribute.getModel())
						.fireTableDataChanged();
			}
		});
		left.add(remove, BorderLayout.SOUTH);
		left.setBorder(BorderFactory
				.createTitledBorder("list all the attributes"));
		Scenter.setLeftComponent(left);

		selectedAttribute = new JTable(new AttributeDetail());
		// selectedAttribute.setPreferredSize(new Dimension(50,50));
		JScrollPane selected = new JScrollPane(selectedAttribute);
		selected.setBorder(BorderFactory
				.createTitledBorder("selected attribute in detail"));

		JScrollPane Schart = new JScrollPane(chartPanel);

		JPanel right = new JPanel();
		right.setLayout(new BorderLayout());

		JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT, true);
		split.setTopComponent(selected);
		split.setBottomComponent(Schart);
		split.setOneTouchExpandable(true);
		split.setDividerLocation(0.5);

		right.add(split, BorderLayout.CENTER);
		Scenter.setRightComponent(right);

		add(center, BorderLayout.CENTER);

		attributes.addRowSelectionInterval(0, 0);
	}

	// deploy the bottom panel
	private void alignBottom() {
		JPanel bottom = new JPanel();
		bottom.setLayout(new FlowLayout());
		bottom.setBorder(BorderFactory.createTitledBorder("load data"));

		JButton load = new JButton("Load");
		load.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				globalManager.setInstances(instances);
				new DataViewer().run();
			}
		});
		bottom.add(load);

		add(bottom, BorderLayout.SOUTH);
	}

	// the model is used for the attributes table
	class AttributesModel extends DefaultTableModel {

		public AttributesModel() {
			super();
		}

		@Override
		public int getColumnCount() {
			// TODO Auto-generated method stub
			return 3;
		}

		@Override
		public String getColumnName(int column) {
			// TODO Auto-generated method stub
			if (column == 0)
				return "checked";
			if (column == 1)
				return "Name";
			if (column == 2)
				return "type";
			else
				return "unknown";
		}

		@Override
		public int getRowCount() {
			// TODO Auto-generated method stub
			return instances.getAttributesNum();
		}

		@Override
		public Object getValueAt(int row, int column) {
			// TODO Auto-generated method stub
			if (column == 0)
				return checked[row];
			if (column == 1)
				return instances.getAttributeAt(row).getName();
			if (column == 2)
				return instances.getAttributeAt(row).getTypeName();
			return null;
		}

		@Override
		public boolean isCellEditable(int row, int column) {
			// TODO Auto-generated method stub
			if (column == 0)
				return true;
			else
				return false;
			// return (column == 0)? true: false;
		}

		@Override
		public Class<?> getColumnClass(int columnIndex) {
			// TODO Auto-generated method stub
			if (columnIndex == 0)
				return Boolean.class;
			return super.getColumnClass(columnIndex);
		}

		@Override
		public void setValueAt(Object value, int row, int column) {
			// TODO Auto-generated method stub
			if (value instanceof Boolean && column == 0)
				checked[row] = (Boolean) value;
			else
				super.setValueAt(value, row, column);
		}

	}

	// this model is used for the attribute in detail
	class AttributeDetail extends DefaultTableModel {

		@Override
		public int getColumnCount() {
			// TODO Auto-generated method stub
			return 2;
		}

		@Override
		public String getColumnName(int column) {
			// TODO Auto-generated method stub
			if (column == 0)
				return "key";
			if (column == 1)
				return "value";
			else
				return "unknown";

		}

		@Override
		public int getRowCount() {
			// TODO Auto-generated method stub
			return props[attribute_index].size();
		}

		@Override
		public Object getValueAt(int row, int column) {
			// TODO Auto-generated method stub
			if (column == 0) {
				if (instances.getAttributeAt(attribute_index).isNumericType()) {
					switch (row) {
					case 0:
						return "min";
					case 1:
						return "max";
					case 2:
						return "mean";
					default:
						return null;
					}
				} else if (instances.getAttributeAt(attribute_index)
						.isNominalType()
						|| instances.getAttributeAt(attribute_index)
								.isDateType()) {
					Object value = instances.getAttributeAt(attribute_index)
							.MapToValue(row + 1);
					return value;
				} else
					return null;
			} else {
				return props[attribute_index].get(getValueAt(row, 0));
			}

		}

		@Override
		public boolean isCellEditable(int row, int column) {
			// TODO Auto-generated method stub
			return false;
		}

	}

	// this method is used to test the panel is right
	public static void main(String args[]) {
		JFrame frame = new JFrame();
		Container cont = frame.getContentPane();
		cont.setLayout(new BorderLayout());
		DataObserver dataObserver = new DataObserver();
		cont.add(dataObserver, BorderLayout.CENTER);

		frame.setSize(500, 500);
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		frame.setVisible(true);
	}
}
