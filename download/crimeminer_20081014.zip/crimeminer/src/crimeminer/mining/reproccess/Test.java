package crimeminer.mining.reproccess;

import java.awt.Color;

import crimeminer.mining.Operator;
import crimeminer.ui.component.Walker;

import javax.swing.*;

public class Test extends Operator {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		JPanel p = new JPanel();
		p.setBackground(Color.BLUE);
		Walker walker = globalManager.getWalker();
		walker.removeAll();
		walker.addTab("Test", p);
	}
}
