package crimeminer.mining.cluster;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.table.*;
import java.util.*;

import crimeminer.core.*;
import crimeminer.ui.*;
import crimeminer.ui.component.Marker;
import crimeminer.global.*;

public class ClusterPanel extends JPanel
{
	Marker marker=CrimeMiner.m_globalManager.getMarker();
	
	/*
	 * ��������ģ��
	 */
	//ѡ���㷨�����������
	private AlgPanel algPanel;
	//�������ã��ж��Ƿ�����
	private AttribPanel attribPanel;
	//ͼ�λ���ʾ������
	private ResultPanel resultPanel;
	//��װ��������panel������
	private JPanel dispPanel;
	
	/*
	 * ����ȫ�ֲ���
	 */
	int alg=0;
	Instances table;//��ǰ�����ı�
	Record [] recordList;//��װ������ݼ�
	RecordMode rm=null;//�������Ե�ģʽ�����ǲ�α�����
	
	
	public ClusterPanel(GlobalManager g)
	{
		//���ݳ�ʼ��
		table=g.getInstances();
		
		//GUI��ʼ��
		algPanel=new AlgPanel();
		attribPanel=new AttribPanel();
		resultPanel=new ResultPanel();
		dispPanel=new JPanel();
		dispPanel.setLayout(new GridLayout(1,2));
		dispPanel.add(attribPanel);
		dispPanel.add(resultPanel);
		setLayout(new BorderLayout());
		add(algPanel, BorderLayout.NORTH);
		add(dispPanel, BorderLayout.CENTER);
		
		
	}
	
	/*
	 * �����ĸ�JPanel�Ǿ�������в�ͬ���ֵĲ���
	 */
	private class AlgPanel extends JPanel
	{
		private JComboBox algorithm;
		private String [] algorithms={"DBSCAN","SimpleHierachical"};//*************�����㷨����*********************************
		public JPanel [] panels=new JPanel[2];
		private JPanel current;
		
		
		AlgPanel()
		{
			//��ʼ���㷨ѡ�����panel
			//*****************************************���Ӷ�Ӧ�㷨�Ĳ����������
			panels[0]=new DBSCAN_Panel();
			panels[1]=new SHier_Panel();
			
			setLayout(new GridBagLayout());
			GridBagConstraints constraints = new GridBagConstraints();
			constraints.gridx = 0;
			constraints.gridy = 0;
			constraints.gridwidth = 1;
			constraints.gridheight = 1;
			constraints.anchor = GridBagConstraints.NORTHWEST;
			constraints.fill = GridBagConstraints.HORIZONTAL;
			constraints.weightx = 100;
			constraints.weighty = 0;
			
			
			//�㷨ѡ�񲿷�
			JPanel left=new JPanel();
			left.add(new JLabel("Algorithm:"));
			algorithm=new JComboBox(algorithms);
			algorithm.setSelectedIndex(0);
			left.add(algorithm);
			add(left, constraints);
			
			
			//�����м�ռ�
			JPanel middle=new JPanel();
			constraints.gridx=1;
			add(middle, constraints);
			
			
			//�㷨��Ӧ��������
			constraints.gridx=2;
			current=panels[0];
			add(current, constraints);
			
			
			
			setBorder(BorderFactory.createTitledBorder("Choose the algorithm"));
			
			//algorithm��listener
			algorithm.addActionListener( new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					GridBagConstraints constraints2 = new GridBagConstraints();
					constraints2.gridx = 2;
					constraints2.gridy = 0;
					constraints2.gridwidth = 1;
					constraints2.gridheight = 1;
					constraints2.anchor = GridBagConstraints.NORTHWEST;
					constraints2.fill = GridBagConstraints.HORIZONTAL;
					constraints2.weightx = 100;
					constraints2.weighty = 0;
					
					
					//alg_name=(String)algorithm.getSelectedItem();
					alg=algorithm.getSelectedIndex();
					//System.out.println(alg);
					algPanel.remove(current);
					current=panels[alg];
					algPanel.add(current, constraints2);
					updateUI();
				}
			});
			
		}
		
		
	}
	
	private class AttribPanel extends JPanel
	{
		int [][] attribSet;//���ڴ洢���������ѡ�����
		MyTable mt;
		
		
		//��������ʵ��Ϊ�˷�װ��ǰ�㷨���м���������
		
		
		Hierachical_tree [] h_trees;
		int recordAmount;
		double max_min[][];
		int scalarsAmount=0, enumsAmount=0, hierasAmount=0;
		
		
		AttribPanel()
		{
			//������ѡ���Եı��������ṩ���û�ѡ����Щ��������Щ�ǲ���ͱ���
			setLayout(new BorderLayout());
			mt=new MyTable();
			JTable jtable=new JTable(mt);
			add(new JScrollPane(jtable), BorderLayout.CENTER);
			
			JButton b_execute=new JButton("Begin clustering");
			b_execute.addActionListener( new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					try 
					{
						attribPanel.saveAttribSet();
						attribPanel.dataPreProcess();
						attribPanel.execute();
						resultPanel.removeAll();
						ResultViewPanel result=new ResultViewPanel(recordList, rm);
						resultPanel.add(result);
						updateUI();
						marker.log("Clustered successfully!");
						for( int i=0; i<recordList.length; i++ )
						{
							if (recordList[i].getClusterId()!=-2 )
							{
								marker.log("record id: "+(i+1)+" cluster id: "+recordList[i].getClusterId());
							}
							else
							{
								marker.log("record id: "+(i+1)+" cluster id: noise");
							}
						}
					} catch (Exception e2) {
						System.err.println(e2);
						marker.log("error: \n"+e2);
					}
				}
				
			});
			add(b_execute, BorderLayout.SOUTH);
			
			setBorder(BorderFactory.createTitledBorder("mark out hierachical variables"));
			
		}
		
		/*
		 * ������������ѡ��������
		 */
		private void saveAttribSet()
		{
			attribSet=new int[table.getAttributesNum()][2];//for every attribute, the first cell indicates whether this attribute is selected to be clustered; 
															//and if it is norminal, the second cell will indicate whether it is an hierachical variable or not.
			for ( int i=0; i<table.getAttributesNum(); i++ )
			{
				if( (Boolean)mt.getValueAt(i, 1)==true ) attribSet[i][0]=1;
				else attribSet[i][0]=0;
				
				if( (Boolean)mt.getValueAt(i, 3)==true ) attribSet[i][1]=1;
				else attribSet[i][1]=0;
				
				//System.out.println(attribSet[i][0]+" "+attribSet[i][1]);
			}
			
		}
		
		/*
		 * ���������ݽ��ж��봦��
		 */
		private void dataPreProcess()
		{
			//to count the amount of 3 kinds of attributes
			
			for ( int i=0; i<table.getAttributesNum(); i++ )//******************************�˴�����datetime�Ĵ�����Ҫ�޸�
			{
				if( table.getAttributeAt(i).isNumericType() && attribSet[i][0]==1 )
				{
					scalarsAmount++;
					
				}
				else if( (table.getAttributeAt(i).isNominalType()|| table.getAttributeAt(i).isDateType()) && attribSet[i][0]==1 && attribSet[i][1]==0 )
				{
					enumsAmount++;
					
				}
				else if( (table.getAttributeAt(i).isNominalType() || table.getAttributeAt(i).isDateType()) && attribSet[i][0]==1 && attribSet[i][1]==1 )
				{
					hierasAmount++;
					
				}
			}
			
			
			//System.out.println("s: "+scalarsAmount+" e: "+enumsAmount+" hierasAmount: "+hierasAmount);
			recordList = new Record[table.getInstancesNum()];
			max_min=new double[scalarsAmount][2];//to store the max and min value of every scalar variable
			//System.out.println(table.getAttributeAt(0).MapToValue(table.getAttributeAt(0).MapToIndex("003")));
						
			{
				int i=0;
				Record tmp=new Record(scalarsAmount, enumsAmount, hierasAmount);
				rm=new RecordMode(scalarsAmount, enumsAmount, hierasAmount);
				//System.out.println("sa: "+rm.getSAmount()+" ea: "+rm.getEAmount()+" ha: "+rm.getHAmount());
				for( int j=0; j<table.getAttributesNum(); j++ )
				{
					if (attribSet[j][0]==1)
					{
						//System.out.println(table.getAttributeAt(i).getTypeName(table.getAttributeAt(i).getType()));
						if ( table.getAttributeAt(j).isNumericType() )
						{
							double d=table.getInstanceAt(i).getValueAt(j);
							int scalarId=tmp.addScalar(d);
							max_min[scalarId][0]=max_min[scalarId][1]=d;
							rm.addSname(table.getAttributeAt(j).getName());
							//System.out.println("scalar here!");
						}
						else if( table.getAttributeAt(j).isNominalType() || table.getAttributeAt(j).isDateType())
						{
							if ( attribSet[j][1]==1 )
							{
								int d=(int)table.getInstanceAt(i).getValueAt(j);
								tmp.addhiera(table.getAttributeAt(j).MapToValue(d).toString());
								rm.addHname(table.getAttributeAt(i).getName());
								//System.out.println(table.getAttributeAt(j).MapToValue(d).toString());
							}
							else
							{
								int d=(int)table.getInstanceAt(i).getValueAt(j);
								tmp.addenum(table.getAttributeAt(j).MapToValue(d).toString());
								rm.addEname(table.getAttributeAt(i).getName());
								//System.out.println(table.getAttributeAt(j).MapToValue(d).toString());
							}
						}
					}
				}
				recordList[i]=tmp;	
				rm.setRecordAmount(table.getInstancesNum());
			}
			//get all data from the Instances Object into the RecordList

			for ( int i=1; i<table.getInstancesNum(); i++ )
			{
				Record tmp=new Record(scalarsAmount, enumsAmount, hierasAmount);
				for( int j=0; j<table.getAttributesNum(); j++ )
				{
					if (attribSet[j][0]==1)
					{
						if ( table.getAttributeAt(j).isNumericType() )
						{
							double d=table.getInstanceAt(i).getValueAt(j);
							int scalarId=tmp.addScalar(d);
							max_min[scalarId][0] = max_min[scalarId][0]>d?  max_min[scalarId][0]: d;
							max_min[scalarId][1] = max_min[scalarId][1]<d?  max_min[scalarId][1]: d;
						}
						
						else if( table.getAttributeAt(j).isNominalType() || table.getAttributeAt(j).isDateType())
						{
							if ( attribSet[j][1]==1 )
							{
								int d=(int)table.getInstanceAt(i).getValueAt(j);
								tmp.addhiera(table.getAttributeAt(j).MapToValue(d).toString());
							}
							else
							{
								int d=(int)table.getInstanceAt(i).getValueAt(j);
								tmp.addenum(table.getAttributeAt(j).MapToValue(d).toString());
							}
						}
					}
				}
				recordList[i]=tmp;				
			}
			
			recordAmount=table.getInstancesNum();
			for( int i=0;  i<recordAmount; i++ )
			{
				recordList[i].printRecord();
			}
			
			
			//to formalize all scalars
			h_trees=new Hierachical_tree[hierasAmount];
			for ( int i=0; i<hierasAmount; i++ )
			{
				h_trees[i]=new Hierachical_tree();
			}
			
			for ( int i=0; i<recordAmount; i++ )
			{
				Record record=recordList[i];
				for ( int j=0; j<scalarsAmount; j++ )
				{
					double c=(record.getScalar(j)-max_min[j][1])/(max_min[j][0]-max_min[j][1]);
					record.setScalar(j, c);
				}					
				//to establish all hierachical trees
				for ( int j=0; j<hierasAmount; j++ )
				{
					h_trees[j].buildTree(recordList[i].getHiera(j));
				}
			}
			
			
		}
		
		/*
		 * ִ�о���
		 */
		private void execute()//*******************�����Ӧ�����㷨��Ҫִ�еĺ���*************************
		{
			switch( alg )
			{
			case 0:
				marker.log("DBSCANing...");
				dbscan();
				break;
			case 1:
				marker.log("SimpleHierachicaling...");
				sHierachical();
				break;
			}
				
		}
		
		/*
		 * �������õ��ľ��뺯��
		 */
		private double dist(Record ra, Record rb)
		{
			double sum=0;
			for ( int i=0; i<scalarsAmount; i++ )
			{
				sum+=Math.pow(ra.getScalar(i)-rb.getScalar(i), 2);
			}
			for ( int i=0; i<enumsAmount; i++ )
			{
				if( ra.getEnums(i)!=rb.getEnums(i)) sum++;
			}
			
			for ( int i=0; i<hierasAmount; i++ )
			{
				sum+=Math.pow(h_trees[i].dist(ra.getHiera(i), rb.getHiera(i)), 2);
			}
			return Math.sqrt(sum);
		}
		
		/*****
		 * ���²����Ǿ���ľ����㷨��ʵ��
		 */
		
			/*
			 * DBSCAN
			 */
		private void dbscan()
		{
			//�����������Ƿ���ȷ
			DBSCAN_Panel pe=(DBSCAN_Panel)algPanel.panels[0];
			
			double epselon;
			int minPts;
			try 
			{
				epselon=pe.get_epselon();
				minPts=pe.get_minPts();
			} catch (Exception e) {
				marker.log("illegal input of epselon or minPts, please try it again." );
				return;
			}
			
			int clusterId=0;//��ǰ���ĵ�����Ĵر��
			
			
			//�����ж�����ɲ������κ�һ�ص�״̬
			for( int i=0; i<recordList.length; i++ )
			{
				recordList[i].setClusterId(-1);
				recordList[i].setRecordId(i);
			}
			
			//��recordList��ÿ��δ����Ķ�����п���
			for( int i=0; i<recordList.length; i++ )
			{
				//����ǰ��������Ѿ�����ĳ���ػ򱻱��δ�������򿼲���һ������
				if( recordList[i].getClusterId()!=-1 )
					continue;
				
				//Ѱ������
				ArrayList<Record> neighbors=getNeighbors(recordList[i], epselon);
				//������̫С���ܹ��ɺ��ģ�����Ϊ�����㣬������һ��
				if( neighbors.size()<minPts )
				{
					recordList[i].setClusterId(-2);
					continue;
				}
				
				//�����к��ĵ���Χ�Ķ�����Ϊ��ǰ��
				for ( int j=0; j<neighbors.size(); j++ )
				{
					neighbors.get(j).setClusterId(clusterId);
					if( neighbors.get(j).getRecordId()==i )
					{
						neighbors.remove(j);
						j--;
					}
				}
				
				//���������ж��������
				for ( int j=0; j<neighbors.size(); j++ )
				{
					ArrayList<Record> neighbors2=getNeighbors(neighbors.get(j), epselon);
					if( neighbors2.size()>=minPts )
					{
						for( int k=0; k<neighbors2.size(); k++ )
						{
							Record r=neighbors2.get(k);
							if( r.getClusterId()==-1 || r.getClusterId()==-2 )
							{
								if( r.getClusterId()==-1 )
									neighbors.add(r);
							}
							r.setClusterId(clusterId);
						}
					}
					neighbors.remove(j);
					j--;
				}
				
				clusterId++;
			}
			/*
			for( int i=0; i<recordList.length; i++ )
			{
				System.out.println("i: "+i+" clusterId: "+recordList[i].getClusterId());
			}
			*/
		}
		
		//Ѱ��һ��Record������
		private ArrayList<Record> getNeighbors(Record r, double epselon)
		{
			ArrayList<Record> result=new ArrayList<Record>();
			for( int i=0; i<recordList.length; i++ )
			{
				if( dist(r, recordList[i])<=epselon )
					result.add(recordList[i]);
			}			
			return result;
		}
		
		
		
		
		
			/*
			 * K-MEANS
			 */
		private void sHierachical()
		{
			
		}
	}
	private class ResultPanel extends JPanel
	{
		ResultPanel()
		{
			setBorder(BorderFactory.createTitledBorder("The result of the clustering"));
			add(new JLabel("The result of clustering will be displayed here!"));
		}
	}
	
	
	/*
	 * ����JPanel�Ǹ����㷨��Ӧ�Ĳ����������
	 */
	//***************************���Ӿ����㷨�����������******************************
	private class DBSCAN_Panel extends JPanel
	{
		JTextField tf_epselon;
		JTextField tf_minPts;
		DBSCAN_Panel()
		{
			setLayout(new GridLayout(1,4));
			JLabel l_epselon=new JLabel("epselon: ");
			JLabel l_minPts=new JLabel("minPts: ");
			tf_epselon=new JTextField();
			tf_minPts=new JTextField();
			add(l_epselon);
			add(tf_epselon);
			add(l_minPts);
			add(tf_minPts);
		}
		public double get_epselon()
		{
			return Double.parseDouble(tf_epselon.getText());
		}
		public int get_minPts()
		{
			return Integer.parseInt(tf_minPts.getText());
		}
	}
	private class SHier_Panel extends JPanel
	{
		public SHier_Panel()
		{
			setLayout(new GridLayout(1, 2));
			add(new JLabel("Cluster number"));
			add(new JTextField(10));
		}
	}
	
	/*
	 * ������attribPanel����Ҫ�õ��Ķ���Ķ���
	 */
	private class MyTable extends AbstractTableModel
	{
		int attribNum;
		Object [][] attribs;				
		String [] name = {"Name","To be clustered","Type","As hierachical"};
		
		MyTable()
		{
			attribNum=table.getAttributesNum();
			attribs=new Object [attribNum][4];
			
			for( int i=0; i<attribNum; i++ )
			{
				attribs[i][0]=table.getAttributeAt(i).getName();
				attribs[i][1]=new Boolean(false);
				attribs[i][2]=table.getAttributeAt(i).getTypeName();
				attribs[i][3]=new Boolean(false);
			}
		}
		
		public int getColumnCount()
		{
			return name.length;
		}
		public int getRowCount()
		{
			return attribNum;
		}
		public Object getValueAt(int row, int col)
		{
			return attribs[row][col];
		}
		public String getColumnName(int c)
		{
			return name[c];
		}
		public Class getColumnClass(int c)
		{
			return getValueAt(0, c).getClass();
		}
		
		public Object getObj(int r, int c)
		{
			return attribs[r][c];
		}
		
		public boolean isCellEditable( int r, int c)
		{
			return true;
		}
		
		public void setValueAt(Object value, int r, int c)
		{
			attribs[r][c]=value;
			fireTableCellUpdated(r, c);
		}
	}
}
