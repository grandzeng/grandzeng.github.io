package crimeminer.mining.cluster;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;


public class ResultViewPanel extends JPanel
{
	
	JPanel p_xy;
	JComboBox cb_attrib_x;
	JComboBox cb_attrib_y;
	JButton b_confirm;
	
	GraphPanel p_Coordinate;
	
	JPanel p_info;
	JPanel p_co;
	
	
	Record [] recordList;
	RecordMode rm;
	
	ArrayList<Color> colorList;
	
	public ResultViewPanel(Record [] a, RecordMode rm)
	{
		setLayout(new BorderLayout());
		this.recordList=a;
		this.rm=rm;
		
		p_xy=new JPanel();
		p_xy.setLayout(new GridLayout(1, 5));
		p_xy.add(new JLabel("��ѡ����Ϊx���������:"));
		String [] content=new String[rm.getSAmount()+rm.getEAmount()];
		int c;
		for( c=0; c<rm.getSAmount(); c++ )
		{
			content[c]=rm.getSname(c);
		}
		for( ; c<rm.getSAmount()+rm.getEAmount(); c++ )
		{
			content[c]=rm.getEname(c-rm.getSAmount());
		}
		cb_attrib_x=new JComboBox(content);
		p_xy.add(cb_attrib_x);
		p_xy.add(new JLabel("��ѡ����Ϊy���������:"));
		cb_attrib_y=new JComboBox(content);
		p_xy.add(cb_attrib_y);
		b_confirm=new JButton("�鿴���");
		b_confirm.addActionListener(new B_confirmListener());
		p_xy.add(b_confirm);
		add(p_xy, BorderLayout.NORTH);
		
		colorList=new ArrayList<Color>();
		colorList.add(Color.black);
		colorList.add(Color.red);
		colorList.add(Color.pink);
		colorList.add(Color.orange);
		colorList.add(Color.blue);
		colorList.add(Color.cyan);
		colorList.add(Color.gray);
		colorList.add(Color.green);
		colorList.add(Color.yellow);
		
	}
	
	private class B_confirmListener implements ActionListener
	{
		public void actionPerformed(ActionEvent even)
		{
			if ( p_Coordinate!=null ) remove(p_Coordinate);
			
			String x=(String)cb_attrib_x.getSelectedItem();
			String y=(String)cb_attrib_y.getSelectedItem();
			//System.out.println("x: "+x+" y: "+y);
			
			p_Coordinate=new GraphPanel(recordList, rm, x, y);
			//p_Coordinate.setBackground(Color.gray);
			p_Coordinate.setPreferredSize(new Dimension(400, 400));
			//p_Coordinate.add(new JLabel("fuck!"));
			
			//p_Coordinate.add(new Label("FUXK!"));
			
			add(p_Coordinate, BorderLayout.CENTER);
			updateUI();
			//p_Coordinate.repaint();
		}
	}
	
	
	
	private class GraphPanel extends JPanel
	{
		private Record [] recordList;
		private RecordMode rm;
		private String x, y;//columnName
		private int recordAmount;
		
		
		GraphPanel(Record [] r, RecordMode rm, String x, String y )
		{
			
			this.recordList=r;
			this.rm=rm;
			this.x=x;
			this.y=y;
			recordAmount=rm.getRecordAmount();
		}
		
		
		protected void paintComponent(Graphics g)
		{
			//p_Coordinate.repaint();
			updateUI();
			super.paintComponent(g);			
			g.drawLine(9, 10, 390, 10);
			g.drawLine(10, 9, 10, 390);
			//*************�ж���ѡ�������Ƿ���ö������
			int x_index=-1;//x��record�ж�Ӧ�����е�λ��
			int y_index=-1;
			
			int x_flag=0;//��ʾxΪ������1����ö������0��
			for ( int i=0; i<rm.getSAmount(); i++ )
			{
				if ( rm.getSname(i)==x )
				{
					x_index=i;
					x_flag=1;
				}

			}
			if ( x_flag==0 )
			{
				for( int i=0; i<rm.getEAmount(); i++ )
				{
					if ( rm.getEname(i)==x ) x_index=i;
				}
			}
			int y_flag=0;//��ʾyΪ������1����ö������0��
			for ( int i=0; i<rm.getSAmount(); i++ )
			{
				if ( rm.getSname(i)==y )
				{
					y_index=i;
					y_flag=1;
				}
			}
			if ( y_flag==0 )
			{
				for( int i=0; i<rm.getEAmount(); i++ )
				{
					if ( rm.getEname(i)==y ) y_index=i;
				}
			}
			
			
			ArrayList<String> eSetx=new ArrayList<String>();
			ArrayList<String> eSety=new ArrayList<String>();
			ArrayList<Integer> clusters = new ArrayList<Integer>();
			//*******************ͳ�ƴص�����������ö�����ԣ�������б��
			for( int i=0; i<recordAmount; i++ )
			{
				int n=recordList[i].getClusterId();
				if ( n!=-1 && n!=-2)
				{
					if ( !clusters.contains(n) ) clusters.add(n);
				}
					
				if( x_flag==0 )//xΪö�ٱ���
				{
					String tmp=recordList[i].getEnums(x_index);
					if( eSetx.contains(tmp)==false ) eSetx.add(tmp);
				}
				if( y_flag==0 )//yΪö�ٱ���
				{
					String tmp=recordList[i].getEnums(y_index);
					if( eSety.contains(tmp)==false ) eSety.add(tmp);
				}
			}
			//���
			for ( int i=0; i<recordAmount; i++ )
			{
				double x_co, y_co;//���x��y����
				if ( x_flag==1 && y_flag==1 )
				{
					x_co=recordList[i].getScalar(x_index);
					y_co=recordList[i].getScalar(y_index);
				}
				else if( x_flag==1 && y_flag==0 )
				{
					x_co=recordList[i].getScalar(x_index);
					y_co=(double)(eSety.indexOf(recordList[i].getEnums(y_index)))/(double)(eSety.size());
					//System.out.println("y_co"+y_co);
				}
				else if( x_flag==0 && y_flag==1 )
				{
					x_co=(double)(eSetx.indexOf(recordList[i].getEnums(x_index)))/(double)(eSetx.size());
					//System.out.println("x_co"+x_co);
					y_co=recordList[i].getScalar(y_index);
				}
				else
				{
					x_co=(double)(eSetx.indexOf(recordList[i].getEnums(x_index)))/(double)(eSetx.size());
					y_co=(double)(eSety.indexOf(recordList[i].getEnums(y_index)))/(double)(eSety.size());
					
					
				}
				//
				x_co=x_co*350+40;
				y_co=y_co*350+40;
				
				
				
				
				
				
				if ( recordList[i].getClusterId()!=-1 && recordList[i].getClusterId()!=-2 )
				{			
					int m=recordList[i].getClusterId();
					int cid=m-m/colorList.size();
					Color color=colorList.get(m);
					//Color color=new Color((m+1)/3*a, (m+2)/3*a , (m+3)/3*a);
					
					g.setColor(color);
					g.fillOval((int)x_co, (int)y_co, 4, 4);
				}	
			}
			
			p_Coordinate.updateUI();
		}
	}	
}
