package crimeminer.mining.cluster;


public class Hierachical_tree 
{
	private H_tree_node root=new H_tree_node();
	private double [] weightArray=new double[20];//ÿ����ε�Ȩֵ�����֧��20��
	public Hierachical_tree()
	{
		for ( int i=0; i<20; i++ ) weightArray[i]=1;
	}
	public void setWeight(int layer, double weight)
	{
		weightArray[layer]= weight;
	}
	public double getWeight( int layer )
	{
		return weightArray[layer];
	}
	public H_tree_node getRoot()
	{
		return root;
	}
	public void buildTree(String s)
	{
		H_tree_node currentNode = root;
		int i=0;
		while ( i<s.length() )
		{
			if ( currentNode.getChild()==null )
			{
				currentNode.setChild(new H_tree_node(s.charAt(i)));
				currentNode=currentNode.getChild();
				i++;
			}
			
			else
			{
				currentNode=currentNode.getChild();
				while ( currentNode.getValue()!=s.charAt(i) && currentNode.getSibling()!=null )
				{
					currentNode=currentNode.getSibling();
				}
				if( currentNode.getValue()==s.charAt(i) )
				{
					i++;								
					continue;
				}
				if (currentNode.getSibling()==null)
				{
					currentNode.setSibling( new H_tree_node( s.charAt(i)) );
					currentNode=currentNode.getSibling();
				}
				i++;
			}
		}
	}
	
	public double dist( String s1, String s2 )
	{
		int l, s;
		double dist=0;
		if( s1.length()>s2.length() )
		{
			l=s1.length();
			s=s2.length();
		}
		else
		{
			l=s2.length();
			s=s1.length();
		}
		int i;
		for ( i=0; i<s; i++ )
		{
			if ( s1.charAt(i)==s2.charAt(i) ) continue;
			break;
		}
		for( ; i<s; i++) dist+=2*this.getWeight(i);
		for ( ; i<l; i++ ) dist+=this.getWeight(i);
		return dist/(s1.length()+s2.length());//�Բ�λ������ľ�����б�׼��
	}
	
	private class H_tree_node //���
	{
		private H_tree_node child;
		private H_tree_node sibling;
		private char value;
		
		H_tree_node()
		{
			child=null;
			sibling=null;
		}
		H_tree_node(char c)
		{
			child=null;
			sibling=null;
			value=c;
		}
		
		public void setChild(H_tree_node a)
		{
			child=a;
		}
		public H_tree_node getChild()
		{
			return child;
		}
		public void setSibling(H_tree_node a)
		{
			sibling=a;
		}
		public H_tree_node getSibling()
		{
			return sibling;
		}
		public void setValue(char c)
		{
			value=c;
		}
		public char getValue()
		{
			return value;
		}
	}

}
