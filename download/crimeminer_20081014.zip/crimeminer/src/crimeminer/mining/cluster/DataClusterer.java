package crimeminer.mining.cluster;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.*;

import crimeminer.mining.Operator;
import crimeminer.ui.component.Walker;

public class DataClusterer extends Operator
{
	private JPanel pane=new JPanel();
	
	public DataClusterer()
	{
		pane.setLayout(new BorderLayout());
	}
	
	@Override
	public void run()
	{
		if( globalManager.getInstances()==null )
		{
			JLabel label = new JLabel("Please Load data set first");
			label.setForeground(Color.RED);
			label.setHorizontalAlignment(SwingConstants.CENTER);
			label.setBorder(BorderFactory.createEtchedBorder());
			pane.add(label, BorderLayout.CENTER);
		}
		else
		{
			ClusterPanel clusterPanel=new ClusterPanel(globalManager);
			pane.add(clusterPanel, BorderLayout.CENTER);
		}
		Walker walker = globalManager.getWalker();
		walker.removeAll();
		walker.addTab("data cluster", pane);
	}
}
