package crimeminer.mining.classifier.core;

import java.util.*;
import crimeminer.core.*;

public class Distribution implements Cloneable {
	// ����������
	private int index = -1;

	// ���Ե�ֵ
	private double value = 0.0;

	// ����������ֵ��ʵ����������
	ArrayList<Integer> instanceIndices = new ArrayList<Integer>();

	public Distribution() {

	}

	public Distribution(int index, double value) {
		this.index = index;
		this.value = value;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public String getAttributeName(Instances data) {
		return data.getAttributeAt(index).getName();
	}

	public double getValue() {
		return value;
	}

	public void setValue(double value) {
		this.value = value;
	}

	public Object getValue(Instances data) {
		return data.getAttributeAt(index).MapToValue((int) value);
	}

	public int getInstancesSize() {
		return instanceIndices.size();
	}

	public ArrayList<Integer> getInstances() {
		return instanceIndices;
	}

	public void addInstance(int inst_index) {
		instanceIndices.add(inst_index);
	}

	public void removeAllInstance() {
		instanceIndices.clear();
	}

	public void removeInstance(int inst_index) {
		for (int i = 0; i < instanceIndices.size(); i++)
			if (instanceIndices.get(i).intValue() == inst_index)
				instanceIndices.remove(i);
	}

	// @Override
	// public int hashCode() {
	// final int prime = 31;
	// int result = 1;
	// result = prime * result + index;
	// result = prime * result
	// + ((instanceIndices == null) ? 0 : instanceIndices.hashCode());
	// long temp;
	// temp = Double.doubleToLongBits(value);
	// result = prime * result + (int) (temp ^ (temp >>> 32));
	// return result;
	// }

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final Distribution other = (Distribution) obj;
		if (index != other.index)
			return false;
		if (Double.doubleToLongBits(value) != Double
				.doubleToLongBits(other.value))
			return false;

		if (instanceIndices == null) {
			if (other.instanceIndices != null)
				return false;
		} else {
			if (instanceIndices.size() != other.instanceIndices.size())
				return false;
			for (int index = 0; index < instanceIndices.size(); index++) {
				if (!instanceIndices.get(index).equals(
						other.instanceIndices.get(index)))
					return false;
			}
		}

		return true;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		Distribution ds = (Distribution) super.clone();
		ds.setIndex(index);
		ds.setValue(value);

		for (int i = 0; i < instanceIndices.size(); i++) {
			ds.addInstance(instanceIndices.get(i));
		}
		return ds;
	}

}
