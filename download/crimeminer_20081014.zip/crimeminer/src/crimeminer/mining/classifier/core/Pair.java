package crimeminer.mining.classifier.core;

public final class Pair implements Cloneable {

	private String key = "";

	private double value = 0.0;
	
	public Pair(){
		key = "";
		value = -1;
	}
	
	public Pair(String key, double value) {
		this.key = key;
		this.value = value;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public double getValue() {
		return value;
	}

	public void setValue(double value) {
		this.value = value;
	}

	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((key == null) ? 0 : key.hashCode());
		long temp;
		temp = Double.doubleToLongBits(value);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final Pair other = (Pair) obj;
		if (key == null) {
			if (other.key != null)
				return false;
		} else if (!key.equals(other.key))
			return false;
		if (Double.doubleToLongBits(value) != Double
				.doubleToLongBits(other.value))
			return false;
		return true;
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		Pair pair = (Pair)super.clone();
		pair.setKey(key);
		pair.setValue(value);
		return pair;
	}

	@Override
	public String toString() {
		String ret = "Pair[" + key + "]= " + value;
		return ret;
	}
	
}
