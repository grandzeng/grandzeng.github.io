package crimeminer.mining.classifier.core;

import java.util.*;

public class Node implements Cloneable{
	// comment: is information-gain necessary to encapsulated in this class
	// Node?
	// this is a undetermined question and we will review it again later on.
	private double m_informationGain = 0.0;

	private Pair m_splitAttr = new Pair();

	private Pair m_branchValue = new Pair();

	private Pair m_classValue = new Pair();

	private Node m_parent = null;

	private ArrayList<Node> m_children = new ArrayList<Node>();

	private ArrayList<Distribution> m_classDistribution = new ArrayList<Distribution>();

	public Node() {

	}

	public double getInformationGain() {
		return m_informationGain;
	}

	public void setInformationGain(double gain) {
		m_informationGain = gain;
	}

	public Pair getSplitAttr() {
		return m_splitAttr;
	}

	public void setSplitAttr(Pair sa) {
		m_splitAttr = sa;
	}

	public String getSplitAttrLabel() {
		return m_splitAttr.getKey();
	}

	public void setSplitAttrLabel(String label) {
		m_splitAttr.setKey(label);
	}

	public int getSplitAttrIndex() {
		return (int) m_splitAttr.getValue();
	}

	public void setSplitAttrIndex(int index) {
		m_splitAttr.setValue(index);
	}

	public Pair getFinalClass() {
		return m_classValue;
	}

	public void setFinalClass(Pair c) {
		m_classValue = c;
	}

	public String getClassLabel() {
		return m_classValue.getKey();
	}

	public void setClassLabel(String label) {
		m_classValue.setKey(label);
	}

	public double getClassValue() {
		return m_classValue.getValue();
	}

	public void setClassValue(double v) {
		m_classValue.setValue(v);
	}

	public Pair getBranch() {
		return m_branchValue;
	}

	public void setBranch(Pair branch) {
		m_branchValue = branch;
	}

	public String getBranchLabel() {
		return m_branchValue.getKey();
	}

	public void setBranchLabel(String label) {
		m_branchValue.setKey(label);
	}

	public double getBranchValue() {
		return m_branchValue.getValue();
	}

	public void setBranchValue(double v) {
		m_branchValue.setValue(v);
	}

	public Node getParent() {
		return m_parent;
	}

	public void setParent(Node m_parent) {
		this.m_parent = m_parent;
	}

	public int getChildrenCount() {
		return m_children.size();
	}

	public boolean isLeaf() {
		if (getChildrenCount() == 0)
			return true;
		else
			return false;
	}

	public boolean isRoot() {
		if (m_parent == null)
			return true;
		return false;
	}

	public ArrayList<Node> getChildren() {
		return m_children;
	}

	public void setChildren(ArrayList<Node> children) {
		m_children = children;
	}

	public Node getChildAt(int index) {
		if (index < 0 || index >= m_children.size())
			return null;
		return m_children.get(index);
	}

	public void addChild(Node node) {
		m_children.add(node);
	}

	public boolean removeChildAt(int index) {
		if (index < 0 || index >= m_children.size())
			return false;
		m_children.remove(index);
		return true;
	}

	public void removeAllChildren() {
		m_children.clear();
	}

	public boolean insertChildAt(int index, Node node) {
		if (index < 0 || index > m_children.size())
			return false;
		m_children.add(index, node);
		return true;
	}

	public ArrayList<Distribution> getDistribution() {
		return m_classDistribution;
	}

	public void setDistribution(ArrayList<Distribution> ds) {
		m_classDistribution = ds;
	}

	public Distribution getClassDistributionAt(int index) {
		if (index < 0 || index >= m_classDistribution.size())
			return null;
		return m_classDistribution.get(index);
	}

	public boolean addClassDistribution(Distribution cd) {
		for (int i = 0; i < m_classDistribution.size(); i++) {
			if (m_classDistribution.equals(cd))
				return false;
		}
		m_classDistribution.add(cd);
		return true;
	}

	public boolean removeClassDistributionAt(int index) {
		if (index < 0 || index >= m_classDistribution.size())
			return false;
		m_classDistribution.remove(index);
		return true;
	}

	public void removeAllClassDistribution() {
		m_classDistribution.clear();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (this.getClass() != obj.getClass())
			return false;
		final Node other = (Node) obj;

		if (Double.doubleToLongBits(m_informationGain) != Double
				.doubleToLongBits(other.m_informationGain))
			return false;

		if (m_splitAttr == null) {
			if (other.m_splitAttr != null)
				return false;
		} else if (!m_splitAttr.equals(other.m_splitAttr))
			return false;

		if (m_branchValue == null) {
			if (other.m_branchValue != null)
				return false;
		} else if (!m_branchValue.equals(other.m_branchValue))
			return false;

		if (m_classValue == null) {
			if (other.m_classValue != null)
				return false;
		} else if (!m_classValue.equals(other.m_classValue))
			return false;

		if (m_parent == null) {
			if (other.m_parent != null)
				return false;
		} else if (!m_parent.equals(other.m_parent))
			return false;

		if (m_children == null) {
			if (other.m_children != null)
				return false;
		} else {
			if (m_children.size() != other.m_children.size())
				return false;
			for (int index = 0; index < m_children.size(); index++) {
				if (!m_children.get(index).equals(other.m_children.get(index)))
					return false;
			}
		}

		if (m_classDistribution == null) {
			if (other.m_classDistribution != null)
				return false;
		} else {
			if (m_classDistribution.size() != other.m_classDistribution.size())
				return false;
			for (int index = 0; index < m_classDistribution.size(); index++) {
				if (!m_classDistribution.get(index).equals(
						other.m_classDistribution.get(index)))
					return false;
			}
		}

		return true;
	}

	@Override
	public Object clone() throws CloneNotSupportedException {

		Node node = (Node) super.clone();

		node.setFinalClass((Pair) m_classValue.clone());
		node.setSplitAttr((Pair) m_splitAttr.clone());
		node.setBranch((Pair) m_branchValue.clone());
		node.setInformationGain(m_informationGain);

		if (m_parent == null)
			node.setParent(null);
		else
			node.setParent((Node) m_parent.clone());

		for (int index = 0; index < m_children.size(); index++) {
			node.addChild((Node) getChildAt(index).clone());
		}

		for (int index = 0; index < m_classDistribution.size(); index++) {
			node.addClassDistribution((Distribution) getClassDistributionAt(
					index).clone());
		}

		return node;
	}
	
	public String toString(){
		if(isLeaf())
			return this.getClassLabel();
		else
			return this.getSplitAttrLabel()+"?";
	}
}
