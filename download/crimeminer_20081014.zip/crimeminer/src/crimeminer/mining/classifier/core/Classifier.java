package crimeminer.mining.classifier.core;

import crimeminer.core.*;
import crimeminer.ui.CrimeMiner;
import java.io.IOException;
import java.sql.SQLException;
import java.util.*;
import crimeminer.util.dbi.*;

public class Classifier {

	private Instances m_dataSet = null;

	private ArrayList<Integer> m_attributeIndices = new ArrayList<Integer>();

	private int m_classIndex = 0;

	public Classifier(Instances data) {
		m_dataSet = data;
	}

	public Classifier() {
	}

	public Instances getDateset() {
		return m_dataSet;
	}

	public void setDateSet(Instances dataSet) {
		m_dataSet = dataSet;
	}

	public int getAttributeIndicesSize() {
		return m_attributeIndices.size();
	}

	public int getAttribute(int index) {
		return m_attributeIndices.get(index);
	}

	public void addAttribute(int index) {
		m_attributeIndices.add(index);
	}

	public int getClassIndex() {
		return m_classIndex;
	}

	public void setClassIndex(int classIndex) {
		m_classIndex = classIndex;
	}

	public int getAttributePos(int index) {
		return m_attributeIndices.get(index).intValue();
	}

	public ArrayList<Distribution> getStatisticAt(int attr_index,
			ArrayList<Integer> instanceIndices) {
		ArrayList<Distribution> distributions = new ArrayList<Distribution>();
		int attr_value_count = m_dataSet.getAttributeAt(attr_index)
				.getNominalCount();
		for (int increment = 0; increment < attr_value_count; increment++) {
			distributions.add(new Distribution(attr_index, increment + 1));
		}

		for (int i = 0; i < instanceIndices.size(); i++) {
			int pos = instanceIndices.get(i);
			double value = m_dataSet.getInstanceAt(pos).getValueAt(attr_index);
			distributions.get(((int) value) - 1).addInstance(pos);
		}

		return distributions;
	}

	public double findMajorClass(ArrayList<Integer> instanceIndices) {
		ArrayList<Distribution> distributions = getStatisticAt(m_classIndex,
				instanceIndices);
		int size = 0;
		double value = -1;
		for (int i = 0; i < distributions.size(); i++) {
			int tempSize = distributions.get(i).getInstancesSize();
			if (size < tempSize) {
				value = distributions.get(i).getValue();
				size = tempSize;
			}
		}

		return value;
	}

	public boolean pureClass(ArrayList<Integer> instanceIndices) {

		ArrayList<Distribution> distributions = getStatisticAt(m_classIndex,
				instanceIndices);
		int count = 0;
		for (int i = 0; i < distributions.size(); i++) {
			if (distributions.get(i).getInstancesSize() != 0)
				count++;
		}

		return count == 1;
	}

	public double information(ArrayList<Integer> instanceIndices) {
		double information = 0.0;
		ArrayList<Distribution> distributions = getStatisticAt(m_classIndex,
				instanceIndices);

		double total = instanceIndices.size();
		// for (int i = 0; i < distributions.size(); i++) {
		// total += distributions.get(i).getInstancesSize();
		// }

		for (int i = 0; i < distributions.size(); i++) {
			int tempSize = distributions.get(i).getInstancesSize();
			if (tempSize != 0) {
				double p = tempSize / total;
				information += (-1) * p * Math.log(p);
			}
		}

		return information;
	}

	public double entropy(ArrayList<Integer> instanceIndices, int attr_index) {
		double entropy = 0.0;
		ArrayList<Distribution> distributions = getStatisticAt(attr_index,
				instanceIndices);
		double total = instanceIndices.size();
		for (int i = 0; i < distributions.size(); i++) {
			int tempSize = distributions.get(i).getInstancesSize();
			if (tempSize != 0) {
				double p = tempSize / total;
				entropy += p * information(distributions.get(i).getInstances());
			}
		}
		return entropy;
	}

	public double gain(ArrayList<Integer> instanceIndices, int attr_index) {
		return information(instanceIndices)
				- entropy(instanceIndices, attr_index);
	}

	public int chooseSplittingAttr(ArrayList<Integer> instanceIndices,
			ArrayList<Integer> attrList) {
		int attr_index = -1;
		double gain = -1.0;
		for (int i = 0; i < attrList.size(); i++) {
			int ai = attrList.get(i);
			double tempGain = gain(instanceIndices, ai);

			if (tempGain > gain) {
				gain = tempGain;
				attr_index = ai;
			}
		}
		return attr_index;
	}

	public ArrayList<Integer> removeAttrIndex(ArrayList<Integer> attrList,
			int index) {

		ArrayList<Integer> rAttrList = new ArrayList<Integer>();

		for (int i = 0; i < attrList.size(); i++) {
			int temp = attrList.get(i);
			if (temp != index)
				rAttrList.add(temp);
		}

		return rAttrList;
	}

	public Node produceNode(ArrayList<Integer> attrList,
			ArrayList<Integer> instanceIndices, Node parent, Pair branch) {

		Node node = new Node();
		node.setParent(parent);
		node.setBranch(branch);

		if (instanceIndices.size() == 0) {
			try {
				node.setFinalClass((Pair) parent.getFinalClass().clone());
				// �����¡���ܵ��¶�ջ���
				// ArrayList<Distribution> temp = new ArrayList<Distribution>();
				// for (int i = 0; i < parent.getDistribution().size(); i++) {
				// temp.add((Distribution) parent.getClassDistributionAt(i)
				// .clone());
				// }
				//node.setDistribution(parent.getDistribution());

				return node;
			} catch (CloneNotSupportedException e) {
				CrimeMiner.m_globalManager.getMarker().log(e.toString());
				e.printStackTrace();
			}

		}

		Pair classValue = new Pair();
		classValue.setValue(findMajorClass(instanceIndices));
		Object object = m_dataSet.getAttributeAt(m_classIndex).MapToValue(
				(int) classValue.getValue());
		classValue.setKey(object.toString());
		node.setFinalClass(classValue);

		ArrayList<Distribution> ds = getStatisticAt(m_classIndex,
				instanceIndices);
		node.setDistribution(ds);

		if (pureClass(instanceIndices) || attrList == null
				|| attrList.size() == 0) {
			return node;
		}

		int attr_index = chooseSplittingAttr(instanceIndices, attrList);

		ArrayList<Distribution> distributions = getStatisticAt(attr_index,
				instanceIndices);
		for (int i = 0; i < distributions.size(); i++) {
			Distribution dis = distributions.get(i);
			Pair br = new Pair();
			br.setValue(dis.getValue());
			Object o = m_dataSet.getAttributeAt(attr_index).MapToValue(
					(int) dis.getValue());
			br.setKey(o.toString());

			ArrayList<Integer> al = removeAttrIndex(attrList, attr_index);
			Node child = produceNode(al, dis.getInstances(), node, br);
			node.addChild(child);

			Pair split = new Pair();
			split.setValue(attr_index);
			split.setKey(m_dataSet.getAttributeAt(attr_index).getName());
			node.setSplitAttr(split);
		}

		return node;
	}

	public DTree buildTree() throws Exception {
		DTree tree = new DTree();
		ArrayList<Integer> instanceIndices = new ArrayList<Integer>();
		if (m_dataSet == null || m_dataSet.getInstancesNum() == 0)
			throw new Exception("data set can not be empty");

		if (!allNominal())
			throw new Exception("there exists non-nominal attribute");

		if (existMissing())
			throw new Exception("can not handle missing value");

		for (int i = 0; i < m_dataSet.getInstancesNum(); i++)
			instanceIndices.add(i);

		Node root = produceNode(m_attributeIndices, instanceIndices, null, null);
		tree.setRoot(root);
		tree.caculateAccuracy();
		return tree;
	}

	public boolean allNominal() {
		for (int i = 0; i < m_attributeIndices.size(); i++) {
			if (!m_dataSet.getAttributeAt(m_attributeIndices.get(i))
					.isNominalType())
				return false;
		}
		return true;
	}

	public boolean existMissing() {
		for (int i = 0; i < m_attributeIndices.size(); i++) {
			for (int j = 0; j < m_dataSet.getInstancesNum(); j++) {
				if (m_dataSet.getInstanceAt(j).isMissing(i))
					return true;
			}
		}
		return false;

	}

	public Pair predict(DTree tree, Instance instance) {
		Node root = tree.getRoot();
		return predict(root, instance);
	}

	public Pair predict(Node node, Instance instance) {
		if (node == null)
			return null;
		if (node.isLeaf()) {
			return node.getFinalClass();
		}

		int split = node.getSplitAttrIndex();
		if (instance.isMissing(split))
			return node.getFinalClass();
		double dvalue = instance.getValueAt(split);
		int size = node.getChildrenCount();
		Node child = null;
		for (int i = 0; i < size; i++) {
			child = node.getChildAt(i);
			if (child.getBranchValue() == dvalue)
				break;
		}
		return predict(child, instance);
	}

	// test
	public static void main(String args[]) {
		DBI dbi = new DBI();
		Classifier classifier = new Classifier();
		try {
			Instances data = dbi.readInstances("weather_nominal");
			classifier.setDateSet(data);
			classifier.setClassIndex(5);
			for (int i = 1; i < 5; i++)
				classifier.addAttribute(i);
			DTree tree = classifier.buildTree();
			for (int i = 0; i < data.getInstancesNum(); i++) {
				Pair pair = classifier.predict(tree, data.getInstanceAt(i));
				System.out.println(pair);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
