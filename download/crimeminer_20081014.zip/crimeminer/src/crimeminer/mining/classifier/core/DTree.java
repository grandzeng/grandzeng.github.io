package crimeminer.mining.classifier.core;

public class DTree implements Cloneable {

	private Node m_root = null;

	private double m_accuracy = 0.0;

	public class Accuracy {
		public double accurate = 0.0;
		public double total = 0.0;
	}

	public DTree() {
	}

	public String getClassLabel() {
		return m_root.getClassLabel();
	}

	public Node getRoot() {
		return m_root;
	}

	public void setRoot(Node root) {
		this.m_root = root;
	}

	public double getAccuracy() {
		return m_accuracy;
	}

	public void setAccuracy(double accuracy) {
		this.m_accuracy = accuracy;
	}

	public void caculateAccuracy() {
		Accuracy acc = caculateAccuracy(m_root);
		double total = acc.total;
		double accurate = acc.accurate;
		if (total == 0.0) {
			m_accuracy = 0.0;
		} else
			m_accuracy = accurate / total;
	}

	// ���㾫ȷ��,��ȱ�����
	public Accuracy caculateAccuracy(Node node) {
		Accuracy acc = new Accuracy();
		if (node.isLeaf()) {
			double class_value = node.getClassValue();
			int size = node.getDistribution().size();
			double total = 0.0;
			double accurate = 0.0;
			for (int i = 0; i < size; i++) {
				Distribution dis = node.getClassDistributionAt(i);
				total += dis.getInstancesSize();
				if (dis.getValue() == class_value)
					accurate = dis.getInstancesSize();
			}
			acc.total = total;
			acc.accurate = accurate;
			// if(total != 0.0)
			// return accurate/total;
			// else
			// return 0.0;
			return acc;
		} else {
			int childrenCount = node.getChildrenCount();
			Accuracy ret = new Accuracy();
			for (int i = 0; i < childrenCount; i++) {
				ret.total += (caculateAccuracy(node.getChildAt(i)).total);
				ret.accurate += (caculateAccuracy(node.getChildAt(i)).accurate);
			}
			return ret;
		}

	}

	/*
	 * @Override public int hashCode() { final int prime = 31; int result = 1;
	 * long temp; temp = Double.doubleToLongBits(m_accuracy); result = prime *
	 * result + (int) (temp ^ (temp >>> 32)); result = prime * result + ((m_root ==
	 * null) ? 0 : m_root.hashCode()); return result; }
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final DTree other = (DTree) obj;
		if (Double.doubleToLongBits(m_accuracy) != Double
				.doubleToLongBits(other.m_accuracy))
			return false;
		if (m_root == null) {
			if (other.m_root != null)
				return false;
		} else if (!m_root.equals(other.m_root))
			return false;
		return true;
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		DTree tree = (DTree) super.clone();

		tree.setAccuracy(m_accuracy);
		tree.setRoot(m_root);

		return tree;
	}
}
