package crimeminer.mining.classifier;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import crimeminer.core.*;
import crimeminer.global.GlobalManager;

import java.util.*;

public class ID3 extends JPanel {

	JPanel viewPane = new JPanel();

	private AttributeWrap m_classIndex = new AttributeWrap();

	private ArrayList<AttributeWrap> m_attributes = new ArrayList<AttributeWrap>();

	private JComboBox class_comboBox = new JComboBox();

	private JTable attr_table = new JTable();

	private GlobalManager globalManager = null;

	private boolean checked[];

	private JButton classify = new JButton("Classify");

	private JPanel right = new JPanel(new BorderLayout());

	public AttributeWrap getClassIndex() {
		return m_classIndex;
	}

	public void setClassIndex(AttributeWrap index) {
		m_classIndex = index;
	}

	public ArrayList<AttributeWrap> getAttributes() {
		return m_attributes;
	}

	public void setAttributes(ArrayList<AttributeWrap> m_attributes) {
		this.m_attributes = m_attributes;
	}

	public void clearAttributes() {
		this.m_attributes.clear();
	}

	public AttributeWrap getAttributeAt(int index) {
		AttributeWrap attr_index = m_attributes.get(index);
		return attr_index;
	}

	public void addAttribute(AttributeWrap attr_index) {
		this.m_attributes.add(attr_index);
	}

	public int getAttributeCount() {
		return this.m_attributes.size();
	}

	public ID3(GlobalManager gm) {
		super();
		this.globalManager = gm;
		if (globalManager.getInstances() == null) {
			JLabel label = new JLabel("Please Load data set first");
			label.setForeground(Color.RED);
			label.setHorizontalAlignment(SwingConstants.CENTER);
			label.setBorder(BorderFactory.createEtchedBorder());
			add(label, BorderLayout.CENTER);
			return;
		}
		int size = gm.getInstances().getAttributesNum();
		checked = new boolean[size];
		for (boolean value : checked) {
			value = false;
		}
		ArrayList<Attribute> attList = gm.getInstances().getAttributes();
		for (int i = 0; i < attList.size(); i++) {
			AttributeWrap e = new AttributeWrap();
			e.index = i;
			e.name = attList.get(i).getName();
			e.type_name = attList.get(i).getTypeName();
			m_attributes.add(e);
		}

		setLayout(new BorderLayout());

		final JSplitPane splitPane = new JSplitPane();
		add(splitPane, BorderLayout.CENTER);
		splitPane.setLeftComponent(deployLeft());
		splitPane.setOneTouchExpandable(true);
		splitPane.setRightComponent(deployRight("", null));

	}

	private JPanel deployAttributes() {
		attr_table = new JTable(new AttributesModel());
		attr_table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		JScrollPane spane = new JScrollPane(attr_table);
		final JPanel pane = new JPanel();
		pane.setLayout(new BorderLayout());
		pane.add(spane, BorderLayout.CENTER);
		pane.setBorder(BorderFactory
				.createTitledBorder("select the attribute(nominal)"));
		JPanel bp = new JPanel();
		JButton button = new JButton("OK");
		bp.add(button);
		button.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				class_comboBox.removeAllItems();
				for (int i = 0; i < checked.length; i++) {
					if (checked[i])
						class_comboBox.addItem(m_attributes.get(i));
				}
				class_comboBox.updateUI();
			}

		});
		pane.add(bp, BorderLayout.SOUTH);
		return pane;
	}

	private JPanel deployClassifier() {
		class_comboBox = new JComboBox();
		class_comboBox.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				AttributeWrap aw = (AttributeWrap) class_comboBox
						.getSelectedItem();
				if (aw == null)
					m_classIndex = new AttributeWrap();
				else
					m_classIndex = aw;
			}

		});
		JLabel label = new JLabel("class attribute");
		JPanel temp = new JPanel();
		temp.setLayout(new FlowLayout());
		temp.add(label);
		temp.add(class_comboBox);
		temp.setBorder(BorderFactory
				.createTitledBorder("selected the class attribute"));
		JPanel buttonP = new JPanel();
		buttonP.setLayout(new FlowLayout());
		buttonP.add(classify);

		classify.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ArrayList<Integer> attList = new ArrayList<Integer>();
				for (int i = 0; i < checked.length; i++) {
					if (checked[i]&&!m_attributes.get(i).type_name.equals("NOMINAL")) {
						JOptionPane.showMessageDialog(null,
								"can not select non-nominal attribute");
						return;
					}
					int help = m_attributes.get(i).index;
					if (checked[i] && help != m_classIndex.index)
						attList.add(help);
				}
				TreeView view = new TreeView(globalManager.getInstances(),
						attList, m_classIndex.index);
				right.removeAll();
				deployRight(view.getClassify_Message(), view);
				right.updateUI();
			}

		});

		final JPanel pane = new JPanel(new BorderLayout());
		pane.add(temp, BorderLayout.CENTER);
		pane.add(buttonP, BorderLayout.SOUTH);
		return pane;
	}

	public JPanel deployLeft() {
		JPanel left = new JPanel();

		left.setLayout(new BorderLayout());

		left.add(deployAttributes(), BorderLayout.CENTER);
		left.add(deployClassifier(), BorderLayout.SOUTH);

		return left;
	}

	public JPanel deployRight(String message, TreeView view) {
		right.setPreferredSize(new Dimension(300, 300));
		if (view == null)
			return right;
		JLabel mess = new JLabel();

		right.add(new JLabel(message), BorderLayout.NORTH);
		right.add(view, BorderLayout.CENTER);
		return right;
	}

	class AttributesModel extends DefaultTableModel {

		public AttributesModel() {
			super();
		}

		@Override
		public int getColumnCount() {
			// TODO Auto-generated method stub
			return 3;
		}

		@Override
		public String getColumnName(int column) {
			// TODO Auto-generated method stub
			if (column == 0)
				return "checked";
			if (column == 1)
				return "Name";
			if (column == 2)
				return "type";
			else
				return "unknown";
		}

		@Override
		public int getRowCount() {
			// TODO Auto-generated method stub
			return globalManager.getInstances().getAttributesNum();
		}

		@Override
		public Object getValueAt(int row, int column) {
			// TODO Auto-generated method stub
			if (column == 0)
				return checked[row];
			if (column == 1)
				return m_attributes.get(row).name;
			if (column == 2)
				return m_attributes.get(row).type_name;
			return null;
		}

		@Override
		public boolean isCellEditable(int row, int column) {
			// TODO Auto-generated method stub
			if (column == 0)
				return true;
			else
				return false;
			// return (column == 0)? true: false;
		}

		@Override
		public Class<?> getColumnClass(int columnIndex) {
			// TODO Auto-generated method stub
			if (columnIndex == 0)
				return Boolean.class;
			return super.getColumnClass(columnIndex);
		}

		@Override
		public void setValueAt(Object value, int row, int column) {
			// TODO Auto-generated method stub
			if (value instanceof Boolean && column == 0)
				checked[row] = (Boolean) value;
			else
				super.setValueAt(value, row, column);
		}

	}

}
