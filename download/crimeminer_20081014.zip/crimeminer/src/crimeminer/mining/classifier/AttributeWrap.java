package crimeminer.mining.classifier;

public class AttributeWrap {
	public int index = -1;
	public String name = "";
	public String type_name ="";
	
	public AttributeWrap(int index,String name,String type_name){
		this.index = index;
		this.name = name;
		this.type_name = type_name;
	}
	
	public AttributeWrap(){}
	
	public String toString(){
		return name;
	}
	
	public boolean equals(Object obj){
		if(this == obj)
			return true;
		if(obj == null)
			return false;
		if(obj.getClass() != this.getClass())
			return false;
		final AttributeWrap other = (AttributeWrap) obj;
		if(other.index != index)
			return false;
		return true;
	}
}
