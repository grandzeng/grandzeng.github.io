package crimeminer.mining.classifier;

import crimeminer.mining.Operator;
import crimeminer.mining.reproccess.DataObserver;
import crimeminer.ui.component.Walker;

public class Classify extends Operator {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		Walker walker = globalManager.getWalker();
		walker.removeAll();
		walker.addTab("ID3-Classifier", new ID3(globalManager));
	}

}
