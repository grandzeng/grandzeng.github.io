package crimeminer.mining.classifier;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.swing.*;
import crimeminer.ui.CrimeMiner;
import crimeminer.core.Attribute;
import crimeminer.core.Instances;
import crimeminer.mining.classifier.core.*;
import crimeminer.mining.classifier.*;
import crimeminer.util.dbi.DBI;
import edu.uci.ics.jung.algorithms.layout.Layout;
import edu.uci.ics.jung.algorithms.layout.PolarPoint;
import edu.uci.ics.jung.algorithms.layout.RadialTreeLayout;
import edu.uci.ics.jung.algorithms.layout.TreeLayout;
import edu.uci.ics.jung.graph.*;
import edu.uci.ics.jung.visualization.GraphZoomScrollPane;
import edu.uci.ics.jung.visualization.Layer;
import edu.uci.ics.jung.visualization.VisualizationServer;
import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.control.CrossoverScalingControl;
import edu.uci.ics.jung.visualization.control.DefaultModalGraphMouse;
import edu.uci.ics.jung.visualization.control.ModalGraphMouse;
import edu.uci.ics.jung.visualization.control.ScalingControl;
import edu.uci.ics.jung.visualization.decorators.*;
import edu.uci.ics.jung.visualization.layout.LayoutTransition;
import edu.uci.ics.jung.visualization.renderers.Renderer.VertexLabel.Position;
import edu.uci.ics.jung.visualization.util.Animator;

import org.apache.commons.collections15.*;
import org.apache.commons.collections15.functors.ConstantTransformer;

public class TreeView extends JPanel {
	
	private String classifying_message = "";

	private Forest<Node, Edge> graph;

	private Factory<DirectedGraph<Node, Edge>> graphFactory = new Factory<DirectedGraph<Node, Edge>>() {
		public DirectedGraph<Node, Edge> create() {
			return new DirectedSparseMultigraph<Node, Edge>();
		}
	};

	private Factory<Tree<Node, Edge>> treeFactory = new Factory<Tree<Node, Edge>>() {

		@Override
		public Tree<Node, Edge> create() {
			// TODO Auto-generated method stub
			return new DelegateTree<Node, Edge>(graphFactory);
		}

	};

	private VisualizationViewer<Node, Edge> vv;

	private VisualizationServer.Paintable rings;

	private TreeLayout<Node, Edge> treeLayout;

	private RadialTreeLayout<Node, Edge> radialLayout;

	public TreeView(Instances data,ArrayList<Integer> attList,int classIndex) {
		graph = new DelegateForest<Node, Edge>();

		createTree(data,attList,classIndex);// initialize the tree

		treeLayout = new TreeLayout<Node, Edge>(graph);
		radialLayout = new RadialTreeLayout<Node, Edge>(graph);
		radialLayout.setSize(new Dimension(300, 300));
		vv = new VisualizationViewer<Node, Edge>(treeLayout, new Dimension(300,
				300));
		vv.setBackground(Color.white);
		

		Transformer<Node, Paint> vertextPaint = new Transformer<Node, Paint>() {

			@Override
			public Paint transform(Node arg0) {
				// TODO Auto-generated method stub
				if (arg0.isLeaf())
					return Color.GREEN;
				else
					return Color.RED;
			}
		};
		
		vv.getRenderContext().setVertexFillPaintTransformer(vertextPaint);
		vv.getRenderContext().setEdgeShapeTransformer(new EdgeShape.Line());
		vv.getRenderContext().setVertexLabelTransformer(new ToStringLabeller());
		vv.getRenderContext().setEdgeLabelTransformer(new ToStringLabeller());
		vv.setVertexToolTipTransformer(new ToStringLabeller());
		vv.getRenderContext().setArrowFillPaintTransformer(
				new ConstantTransformer(Color.lightGray));
		vv.getRenderer().getVertexLabelRenderer().setPosition(Position.CNTR);
		rings = new Rings();

		setLtoR(vv);
		this.setLayout(new BorderLayout());
		// Container content = getContentPane();
		final GraphZoomScrollPane panel = new GraphZoomScrollPane(vv);
		add(panel);

		final DefaultModalGraphMouse graphMouse = new DefaultModalGraphMouse();

		vv.setGraphMouse(graphMouse);

		JComboBox modeBox = graphMouse.getModeComboBox();
		modeBox.addItemListener(graphMouse.getModeListener());
		graphMouse.setMode(ModalGraphMouse.Mode.TRANSFORMING);

		final ScalingControl scaler = new CrossoverScalingControl();

		JButton plus = new JButton("+");
		plus.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				scaler.scale(vv, 1.1f, vv.getCenter());
			}

		});

		JButton minus = new JButton("-");
		minus.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				scaler.scale(vv, 1 / 1.1f, vv.getCenter());
			}
		});

		JToggleButton radial = new JToggleButton("Radial");
		radial.addItemListener(new ItemListener() {

			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {

					LayoutTransition<Node, Edge> lt = new LayoutTransition<Node, Edge>(
							vv, treeLayout, radialLayout);
					Animator animator = new Animator(lt);
					animator.start();
					vv.getRenderContext().getMultiLayerTransformer()
							.setToIdentity();
					vv.addPreRenderPaintable(rings);
				} else {
					LayoutTransition<Node, Edge> lt = new LayoutTransition<Node, Edge>(
							vv, radialLayout, treeLayout);
					Animator animator = new Animator(lt);
					animator.start();
					vv.getRenderContext().getMultiLayerTransformer()
							.setToIdentity();
					setLtoR(vv);
					vv.removePreRenderPaintable(rings);
				}

				vv.repaint();
			}
		});

		JPanel scaleGrid = new JPanel(new GridLayout(1, 0));
		scaleGrid.setBorder(BorderFactory.createTitledBorder("Zoom"));

		JPanel controls = new JPanel();
		scaleGrid.add(plus);
		scaleGrid.add(minus);
		controls.add(radial);
		controls.add(scaleGrid);
		controls.add(modeBox);
		add(controls, BorderLayout.SOUTH);
	}

	private void fillTree(Node node) {
		if (node.isLeaf())
			return;
		ArrayList<Node> nodes = node.getChildren();
		for (int i = 0; i < nodes.size(); i++) {
			Node temp = nodes.get(i);
			graph.addEdge(new Edge(temp.getBranchLabel()), node, temp);
			fillTree(temp);
		}
	}
	public String getClassify_Message(){
		return this.classifying_message;
	}
	private void createTree(Instances data,ArrayList<Integer> attList,int classIndex) {
		//DBI dbi = new DBI();
		Classifier classifier = new Classifier();
		try {
			//Instances data = dbi.readInstances("weather_nominal");
			classifier.setDateSet(data);
			classifier.setClassIndex(classIndex);
			for (int i = 0; i < attList.size(); i++)
				classifier.addAttribute(attList.get(i));
			DTree dTree = classifier.buildTree();
			// for (int i = 0; i < data.getInstancesNum(); i++) {
			// Pair pair = classifier.predict(dTree, data.getInstanceAt(i));
			// System.out.println(pair);
			// }
			dTree.caculateAccuracy();
			classifying_message ="class label:" + dTree.getClassLabel()+"   "+"accuracy:"+dTree.getAccuracy();
			
			graph.addVertex(dTree.getRoot());
			fillTree(dTree.getRoot());
		} catch (Exception e) {
			CrimeMiner.m_globalManager.getMarker().log(e.toString());
			e.printStackTrace();
		}
	}

	private void setLtoR(VisualizationViewer<Node, Edge> vv) {
		Layout<Node, Edge> layout = vv.getModel().getGraphLayout();
		Dimension d = layout.getSize();
		Point2D center = new Point2D.Double(d.width / 2, d.height / 2);
		vv.getRenderContext().getMultiLayerTransformer().getTransformer(
				Layer.LAYOUT).rotate(-Math.PI / 2, center);
	}

	class Rings implements VisualizationServer.Paintable {

		Collection<Double> depths;

		public Rings() {
			depths = getDepths();
		}

		private Collection<Double> getDepths() {
			Set<Double> depths = new HashSet<Double>();
			Map<Node, PolarPoint> polarLocations = radialLayout
					.getPolarLocations();
			for (Node v : graph.getVertices()) {
				PolarPoint pp = polarLocations.get(v);
				depths.add(pp.getRadius());
			}
			return depths;
		}

		public void paint(Graphics g) {
			g.setColor(Color.lightGray);

			Graphics2D g2d = (Graphics2D) g;
			Point2D center = radialLayout.getCenter();

			Ellipse2D ellipse = new Ellipse2D.Double();
			for (double d : depths) {
				ellipse.setFrameFromDiagonal(center.getX() - d, center.getY()
						- d, center.getX() + d, center.getY() + d);
				Shape shape = vv.getRenderContext().getMultiLayerTransformer()
						.getTransformer(Layer.LAYOUT).transform(ellipse);
				g2d.draw(shape);
			}
		}

		public boolean useTransform() {
			return true;
		}
	}

	public static void main(String args[]) {
		JFrame frame = new JFrame();
		Container content = frame.getContentPane();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		DBI dbi = new DBI();
		Instances data;
		try {
			data = dbi.readInstances("weather_nominal");
			ArrayList<Attribute> al = data.getAttributes();
			ArrayList<Integer> attList =new ArrayList<Integer>();
			for(int i= 1;i<al.size()-1;i++){
				attList.add(i);
			}
			int classIndex = al.size() -1;
			content.add(new TreeView(data,attList,classIndex));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		frame.pack();
		frame.setVisible(true);
	}
}
