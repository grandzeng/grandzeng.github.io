package crimeminer.mining.classifier;

public class Edge {
	private String split_value="";
	
	public Edge(String split){
		this.split_value = split;
	}
	public String toString(){
		return split_value;
	}
}
