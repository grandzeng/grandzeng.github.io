package packageAoristic;
import org.eclipse.swt.*;

import org.eclipse.swt.widgets.*;
import org.eclipse.swt.events.*;
import java.sql.*;
import org.eclipse.swt.layout.*;

public class UserInterface {
	public void buildWindow()
	{
		final Display display = new Display();
		final Shell shell = new Shell(display);
		shell.setSize(500,500);
//		shell.setLayout(new GridLayout(10,true));
		shell.setText("Aoristic Analyse");
	
		final Label label = new Label(shell,SWT.NONE);
		label.setText("Please choose crime place: ");
		label.setBounds(10, 50,180, 50);
		String[] item=new String[]{
			"Beijing","Shanghai","Chengdu"
		};
		final Combo combo = new Combo(shell,SWT.READ_ONLY);
		combo.setBounds(200,50,100,25);
		combo.setItems(item);
		
		final Label label1=new Label(shell,SWT.NONE);
		label1.setText("Please choose the crime type:");
		label1.setBounds(10,150,180,50);
		String[] item1=new String[]{
			"Stealing","Assaults","Drugs"
		};
		final Combo combo1 = new Combo(shell,SWT.READ_ONLY);
		combo1.setBounds(200,150,100,25);
		combo1.setItems(item1);
		
		final Label label2=new Label(shell,SWT.NONE);
		label2.setText("Please choose the dimension:");
		label2.setBounds(10,250,180,50);
		String[] item2=new String[]{
			"hour","day","month"
		};
		final Combo combo2 = new Combo(shell,SWT.READ_ONLY);
		combo2.setBounds(200,250,100,25);
		combo2.setItems(item2);
		
		final Button button = new Button(shell,SWT.PUSH);
		button.setText("Analyse");
		button.setBounds(100,300, 100, 25);
		button.addSelectionListener(new SelectionAdapter()
		{
			public void widgetSelected(SelectionEvent event)
			{
				MainProcess main = new MainProcess();
				try
				{
					main.process(shell);
				}
				catch (SQLException e)
				{
				//	e.printStackTrace(System.err);
					MessageBox mb = new MessageBox(shell,SWT.OK);
					mb.setText("warning");
					mb.setMessage(e.getMessage());
				}
				catch (ClassNotFoundException e)
				{
				//	e.printStackTrace(System.err);
					MessageBox mb = new MessageBox(shell,SWT.OK);
					mb.setText("warning");
					mb.setMessage(e.getMessage());
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
		
	//	shell.layout();
	//	shell.pack();
		shell.open();
		while (!shell.isDisposed())
		{
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}