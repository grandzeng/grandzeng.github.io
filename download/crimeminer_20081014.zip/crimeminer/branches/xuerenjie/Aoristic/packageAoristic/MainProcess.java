package packageAoristic;
import org.eclipse.swt.*;
import org.eclipse.swt.widgets.*;
import java.sql.*;
import org.eclipse.swt.awt.*;
import java.awt.Frame;
import org.eclipse.swt.layout.*;
import org.jfree.chart.*;
import org.jfree.data.category.*;
import org.jfree.chart.plot.*;

public class MainProcess 
{

	/*this is the main function to 
	 *process the event "selection"
	 *when you push the botton analyse
	 */ 
	public void process(Shell s)
	throws SQLException,ClassNotFoundException,Exception
	{
		Control[] control = s.getChildren();
		Combo combo = (Combo)control[1];
		Combo combo1 = (Combo)control[3];
		Combo combo2 = (Combo)control[5];
		if (combo.getText().length()==0||combo1.getText().length()==0
				||combo2.getText().length()==0)
		{
			MessageBox mb= new MessageBox(s,SWT.OK);
			mb.setText("Prompt");
			mb.setMessage("You should choose the crime place "+
					"and crime type and the dimension");
			mb.open();
		}
		else
		{
			//build a connection to mysql database
			Connection connection = DataAccess.buildConnection("","");
			ResultSet set = DataAccess.getResult(connection, 
					combo.getText(), combo1.getText());
			DataProcess dp = new DataProcess();
			String p = combo2.getText();
			int pc=0;
			if (p.equals("month")) pc = ConstantData.month;
			else if (p.equals("day")) pc = ConstantData.day;
			else pc = ConstantData.hour;
			//invoke the function to make a statistic
			double[] res = dp.statistic(set,pc);
			// to show the result use swt-awt
			Output out = new Output();
			out.showResult(res,s,pc,combo.getText());
		}
	}
	public static void main(String[] arg)
	{
		UserInterface ui = new UserInterface();
		ui.buildWindow();
	}
}
