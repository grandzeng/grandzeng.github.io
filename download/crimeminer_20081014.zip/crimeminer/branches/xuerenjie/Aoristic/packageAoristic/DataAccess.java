package packageAoristic;
//import com.mysql.jdbc.*;
import java.sql.*;

public class DataAccess {
	static ResultSet res;
//	static Connection con;
	public static Connection buildConnection(String user,String pwd)
	throws SQLException,ClassNotFoundException
	{
		String url="jdbc:mysql://localhost/xrj";	
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection(url, user, pwd);
		return con;
	}
	public static ResultSet getResult(Connection con,
			String cmPlace,String cmType)
	throws SQLException
	{
		Statement s = con.createStatement();
		res = s.executeQuery("select * from CrimeRecord "+
				"where CrimePlace="+"'"+cmPlace+"'"+" and CrimeType="+
				"'"+cmType+"'");
		return res;
	}
}
