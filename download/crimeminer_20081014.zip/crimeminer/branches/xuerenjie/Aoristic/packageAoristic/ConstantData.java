package packageAoristic;

public class ConstantData {
	final static int month = 12;
	final static int day = 31;
	final static int hour = 24;
}
