package packageAoristic;

//import java.io.LineNumberReader;
//import java.io.FileReader;

import spatialindex.rtree.*;
import spatialindex.spatialindex.*;
import spatialindex.storagemanager.*;

import org.geotools.data.FeatureSource;
import org.geotools.feature.FeatureCollection;
import org.geotools.feature.FeatureIterator;
import org.geotools.feature.Feature;
import org.geotools.geometry.jts.ReferencedEnvelope;

//import RTreeQuery.MyVisitor;

public class RStarTree {

	public Integer buildRStarTree(FeatureSource featureSource, String tree_file,int type) {
		Integer indexID = new Integer(-1);
		try {
			/*
			 * if (args.length != 4) { System.err.println("input_file tree_file
			 * capacity query_type [intersection | 10NN]."); System.exit(-1); }
			 * 
			 * LineNumberReader lr = null;
			 * 
			 * try { lr = new LineNumberReader(new FileReader(args[0])); } catch
			 * (FileNotFoundException e) { System.err.println("Cannot open data
			 * file " + args[0] + "."); System.exit(-1); }
			 */

			// Create a disk based storage manager.
			PropertySet ps = new PropertySet();

//			Boolean b = new Boolean(true);
			ps.setProperty("Overwrite", true);
			// overwrite the file if it exists.

			ps.setProperty("FileName", tree_file);
			// .idx and .dat extensions will be added.

//			Integer i = new Integer(4096);
			ps.setProperty("PageSize", 4096);
			// specify the page size. Since the index may also contain user
			// defined data
			// there is no way to know how big a single node may become. The
			// storage manager
			// will use multiple pages per node if needed. Off course this will
			// slow down performance.

			IStorageManager diskfile = new DiskStorageManager(ps);
			IBuffer file = new RandomEvictionsBuffer(diskfile, 10, false);
			// applies a main memory random buffer on top of the persistent
			// storage manager
			// (LRU buffer, etc can be created the same way).

			// Create a new, empty, RTree with dimensionality 2, minimum load
			// 70%, using "file" as
			// the StorageManager and the RSTAR splitting policy.
			PropertySet ps2 = new PropertySet();

			Double f = new Double(0.7);
			ps2.setProperty("FillFactor", f);

			Integer i = new Integer(20);
			ps2.setProperty("IndexCapacity", i);
			ps2.setProperty("LeafCapacity", i);
			// Index capacity and leaf capacity may be different.

			i = new Integer(2);
			ps2.setProperty("Dimension", i);
			
			ISpatialIndex tree = new RTree(ps2, file,type);

			int id=1;
			long start = System.currentTimeMillis();
			// String line = lr.readLine();
			FeatureCollection fc = featureSource.getFeatures();
			FeatureIterator fi = fc.features();
			
			while (fi.hasNext()) {
				Feature feature = fi.next();
				ReferencedEnvelope en = feature.getBounds();
				double[] p1 = new double[2];
				double[] p2 = new double[2];
				p1[0] = en.getMinX();
				p1[1] = en.getMinY();
				p2[0] = en.getMaxX();
				p2[1] = en.getMaxY();
				Region region = new Region(p1, p2);
				tree.insertData(null, region, id);
				id++;
			}
			long end = System.currentTimeMillis();

			// System.err.println("Operations: " + count);
			System.err.println(tree);
			System.err.println("Minutes: " + ((end - start) / 1000.0f) / 60.0f);

			// since we created a new RTree, the PropertySet that was used to
			// initialize the structure
			// now contains the IndexIdentifier property, which can be used
			// later to reuse the index.
			// (Remember that multiple indices may reside in the same storage
			// manager at the same time
			// and every one is accessed using its unique IndexIdentifier).
			indexID = (Integer) ps2.getProperty("IndexIdentifier");
			System.err.println("Index ID: " + indexID);

			boolean ret = tree.isIndexValid();
			if (ret == false)
				System.err.println("Structure is INVALID!");

			// flush all pending changes to persistent storage (needed since
			// Java might not call finalize when JVM exits).
			tree.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (indexID.equals((Integer) (-1))) {
			return null;
		} else {
			return indexID;
		}
	}

	public static boolean[] r = new boolean[50]; 
	public boolean[] QueryRStarTree(Point p,int k, int indexID,int type) {
		try {
			// Create a disk based storage manager.as
			PropertySet ps = new PropertySet();

			ps.setProperty("FileName", Output.tree_file);
			// .idx and .dat extensions will be added.

//			ps.setProperty("OverWrite", true);
			
			ps.setProperty("PageSize", 4096);
			IStorageManager diskfile = new DiskStorageManager(ps);

			IBuffer file = new RandomEvictionsBuffer(diskfile, 10, false);
			// applies a main memory random buffer on top of the persistent
			// storage manager
			// (LRU buffer, etc can be created the same way).

			PropertySet ps2 = new PropertySet();

			// If we need to open an existing tree stored in the storage
			// manager, we only
			// have to specify the index identifier as follows
			// Integer i = new Integer(1); // INDEX_IDENTIFIER_GOES_HERE
			// (suppose I know that in this case it is equal to 1);
			ps2.setProperty("IndexIdentifier", indexID);
			// this will try to locate and open an already existing r-tree index
			// from file manager file.
			ISpatialIndex tree = new RTree(ps2, file,type);
			
			long start = System.currentTimeMillis();

			MyVisitor vis = new MyVisitor();
			for (int i=0;i<50;i++)
				r[i]=false;
			tree.nearestNeighborQuery(k, p, vis);
			
			long end = System.currentTimeMillis();
			System.err.println(tree);
			System.err.println("Minutes: " + ((end - start) / 1000.0f) / 60.0f);
			System.out.println("----------------------------------");
			for (int i=0;i<50;i++)
				if (r[i])
					System.out.println(i);
			tree.flush();
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
		return r;
	}

	// example of a Visitor pattern.
	// see RTreeQuery for a more elaborate example.
	class MyVisitor implements IVisitor {
		public void visitNode(final INode n) {
		}

		public void visitData(final IData d) {
			r[d.getIdentifier()]= true;
			System.out.println(d.getIdentifier());
			// the ID of this data entry is an answer to the query. I will just
			// print it to stdout.
		}
	}
}
