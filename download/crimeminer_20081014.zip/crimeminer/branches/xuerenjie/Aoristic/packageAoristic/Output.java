package packageAoristic;

import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.events.*;
import org.eclipse.swt.SWT;
import org.eclipse.swt.awt.SWT_AWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.layout.RowLayout;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import java.awt.Frame;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//import java.awt.Point;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.charset.Charset;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import javax.swing.filechooser.FileFilter;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JComponent;

import org.geotools.data.FeatureSource;
import org.geotools.data.shapefile.ShapefileDataStore;
import org.geotools.factory.CommonFactoryFinder;
import org.geotools.feature.FeatureType;
import org.geotools.gui.swing.JMapPane;
import org.geotools.map.DefaultMapContext;
import org.geotools.map.MapContext;
import org.geotools.renderer.lite.StreamingRenderer;
import org.geotools.styling.FeatureTypeStyle;
import org.geotools.styling.Fill;
import org.geotools.styling.LineSymbolizer;
import org.geotools.styling.PointSymbolizer;
import org.geotools.styling.PolygonSymbolizer;
import org.geotools.styling.TextSymbolizer;
import org.geotools.styling.Rule;
import org.geotools.styling.SLD;
import org.geotools.styling.SLDParser;
import org.geotools.styling.Style;
import org.geotools.styling.StyleFactory;
import org.geotools.styling.Symbolizer;
import org.opengis.filter.FilterFactory;
import org.opengis.referencing.crs.CoordinateReferenceSystem;
import org.geotools.referencing.CRS;
import org.geotools.feature.FeatureCollection;
import org.geotools.feature.FeatureIterator;
import org.geotools.feature.Feature;
import org.geotools.styling.StyleBuilder;

import com.vividsolutions.jts.geom.LineString;
import com.vividsolutions.jts.geom.MultiLineString;
import com.vividsolutions.jts.geom.MultiPolygon;
import com.vividsolutions.jts.geom.Polygon;
import com.vividsolutions.jts.geom.Envelope;
//import com.vividsolutions.jts.geom.Point;

import spatialindex.spatialindex.SpatialIndex;
import spatialindex.spatialindex.Point;

public class Output {
	
	
	//	create the result chart
	private static JFreeChart createJFreeChart(double[] res,int pc,String place)
	{
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();
		int i;
		for (i=1;i<res.length;i++)
		{
			String value = ""+i;
			dataset.addValue(res[i],"Aoristic",value);
		}
		String category="";
		if (pc==ConstantData.month) category = "month";
		else if (pc==ConstantData.day) category = "day";
		else category = "hour";
		JFreeChart chart = ChartFactory.createBarChart(
				place,category, "Value",dataset,PlotOrientation.VERTICAL,
				true,true, false);
		return chart;
	}
	
	
	static StyleFactory styleFactory = CommonFactoryFinder.getStyleFactory(null);
	static FilterFactory filterFactory = CommonFactoryFinder.getFilterFactory(null);
	static FeatureSource featureSource;
	static String tree_file = "E:\\tree";
	public void showResult(double[] res,Shell s,int pc,String place)
	throws Exception
	{
    	
//		File file = getShapeFile(new String[]{"D:\\data\\bou2_4p.shp"});
		File file = getShapeFile(new String[]{"D:\\data\\cities\\cities.shp"});
        ShapefileDataStore shapefile = new ShapefileDataStore(file.toURL());
        String[] typeNames = shapefile.getTypeNames();
        featureSource = shapefile.getFeatureSource();
      
  /*      {
        	FeatureCollection fc = featureSource.getFeatures();
        	FeatureIterator fi = fc.features();
        	int cnt=0;
        	while (fi.hasNext())
        	{
        		cnt++;
        		Feature f = fi.next();
        	}
        	System.out.println("Cnt="+cnt);
        }
   */
        FeatureType schema = featureSource.getSchema();
        MapContext map = new DefaultMapContext();
        Style style = createStyle(file, schema);
        map.addLayer(featureSource, style);
        
        file = getShapeFile(new String[]{"D:\\data\\res1_4m.shp"});
        shapefile = new ShapefileDataStore(file.toURL());
        shapefile.setStringCharset(Charset.forName("GBK"));
        featureSource = shapefile.getFeatureSource();  
        schema = featureSource.getSchema();
        style = createStyle(file,schema);
        map.addLayer(featureSource,style);
        
        FeatureCollection fc = featureSource.getFeatures();
        FeatureIterator iterator = fc.features();
        while (iterator.hasNext())
        {
        	Feature f = iterator.next();
        	int n= f.getNumberOfAttributes();
        	for (int i=0;i<n;i++)
        		System.out.println(f.getAttribute(i));
  //      	if (((String)f.getAttribute(n-1)).equals("Shanghai"))
    //    		System.out.println("Shanghai");
 //       	break;
        }
        showMap(map,res,s,pc,place);
	}
	
	   private static Style createStyle(File file, FeatureType schema) {
	        File sld = toSLDFile(file);
	        if (sld.exists()) {
	            return createFromSLD(sld);
	        }
	        Class type = schema.getDefaultGeometry().getBinding();
	        if (type.isAssignableFrom(Polygon.class)
	                || type.isAssignableFrom(MultiPolygon.class)) {
	            return createPolygonStyle();
	        } else if (type.isAssignableFrom(LineString.class)
	                || type.isAssignableFrom(MultiLineString.class)) {
	            return createLineStyle();
	        } else {
	            return createPointStyle();
	        }
	    }

	    private static Style createFromSLD(File sld) {
	        SLDParser stylereader;
	        try {
	            stylereader = new SLDParser(styleFactory, sld.toURL());
	            Style[] style = stylereader.readXML();
	            return style[0];
	        } catch (Exception e) {
	            JOptionPane.showMessageDialog(null, e.getMessage());
	            System.exit(0);
	        }
	        return null;
	    }

	    private static Style createPointStyle() {
	        Style style;
	        PointSymbolizer symbolizer = styleFactory.createPointSymbolizer();
	        symbolizer.getGraphic().setSize(filterFactory.literal(1));
	        Rule rule = styleFactory.createRule();
	        rule.setSymbolizers(new Symbolizer[] { symbolizer });
	        FeatureTypeStyle fts = styleFactory.createFeatureTypeStyle();
	        fts.setRules(new Rule[] { rule });
	        style = styleFactory.createStyle();
	        style.addFeatureTypeStyle(fts);
	        return style;
	    }

	    private static Style createLineStyle() {
	        Style style;

	        LineSymbolizer symbolizer = styleFactory.createLineSymbolizer();
	        SLD.setLineColour(symbolizer, Color.BLUE);
	        symbolizer.getStroke().setWidth(filterFactory.literal(1));
	        symbolizer.getStroke().setColor(filterFactory.literal(Color.BLUE));

	        Rule rule = styleFactory.createRule();
	        rule.setSymbolizers(new Symbolizer[] { symbolizer });
	        FeatureTypeStyle fts = styleFactory.createFeatureTypeStyle();
	        fts.setRules(new Rule[] { rule });
	        style = styleFactory.createStyle();
	        style.addFeatureTypeStyle(fts);
	        return style;
	    }

	    private static Style createPolygonStyle(){
	    Style style;
	    PolygonSymbolizer symbolizer = styleFactory.createPolygonSymbolizer();
	    Fill fill = styleFactory.createFill(
	            filterFactory.literal("#FFAA00"),
	            filterFactory.literal(0.5)
	    );
	    symbolizer.setFill(fill);
	    Rule rule = styleFactory.createRule();
	    TextSymbolizer testSymbolizer = createTextSymbolizer(); 
	    rule.setSymbolizers(new Symbolizer[] { symbolizer,testSymbolizer});
	    FeatureTypeStyle fts = styleFactory.createFeatureTypeStyle();
	    fts.setRules(new Rule[] { rule });
	    style = styleFactory.createStyle();
	    style.addFeatureTypeStyle(fts);
	    return style;
	    }
	    
	    private static TextSymbolizer createTextSymbolizer()
	    {
	    	StyleBuilder sb = new StyleBuilder();
	    	org.geotools.styling.Font font = sb.createFont(new java.awt.Font(
	    			"Arial", java.awt.Font.PLAIN, 15));
	    	TextSymbolizer tsArch = sb.createTextSymbolizer(Color.BLACK, font,
	    			"DSKLFJSDJ");
	    	tsArch.setHalo(sb.createHalo(Color.WHITE, 1, 1));

	    	return tsArch;
	    }

	    private static Shell shell;
	    private static void showMap(MapContext map,double[] res,
	    		Shell s, int pc,String place) throws IOException {
	    	
	    	shell = new Shell(s);
			shell.setSize(1000,600);
			shell.setText("Aoristic Result");
			shell.setLayout(new FillLayout());
			shell.layout();
			
			Composite com = new Composite(shell,SWT.EMBEDDED);
			com.setLayout(new FillLayout());
//			com.setSize(1000,300);
			com.layout();
			com.setVisible(true);
			Frame frame = SWT_AWT.new_Frame(com);
			
			
	        final JMapPane mapPane = new JMapPane(new StreamingRenderer(), map);
	        mapPane.setMapArea(map.getLayerBounds());
	        frame.setLayout(new BorderLayout());
	        frame.add(mapPane, BorderLayout.CENTER);
	        ChartPanel chartPanel = new ChartPanel(createJFreeChart(res,pc,place));
	        chartPanel.setSize(300, 100);
	        FeatureCollection fc = map.getLayer(1).getFeatureSource().getFeatures();
	        Envelope ee = fc.getBounds();
	        System.out.println("MinX="+ee.getMinX()+"MaxX="+ee.getMaxX()
	        		+"MinY="+ee.getMinY()+"MaxY="+ee.getMaxY());
	        FeatureIterator fi = fc.features();
	      //  Point pt=null;
	        while (fi.hasNext())
	        {
	        	Feature feature = fi.next();
	        	System.out.println(feature);
	        	System.out.println(feature.getBounds());
	        	int n = feature.getNumberOfAttributes();
	      //  	for (int i=0;i<n;i++) 
	        //		System.out.println(feature.getAttribute(i));
	    /*    	if (((String)feature.getAttribute(n-1)).equals(place))
	        	{
	        		double x = ((com.vividsolutions.jts.geom.Point)feature.getAttribute(0)).getX()+0.5;
	        		double y = ((com.vividsolutions.jts.geom.Point)feature.getAttribute(0)).getY();
	        		System.out.println(x+" "+y);
	        		pt = new Point((int)(x+0.5),(int)(y+0.5));
	        		break;
	        	}
	       */
	        }
	        chartPanel.setLocation(0,0);
	        mapPane.add(chartPanel);
	        JPanel buttons = new JPanel();
	        Button searchButton = new Button(shell,SWT.PUSH);
	        searchButton.setText("KNN search");
//	        searchButton.setLocation(500,550);
	        searchButton.addSelectionListener(new SelectionAdapter() {
	        	public void widgetSelected(SelectionEvent e)
	        	{
	      /*  		JFrame jframe = new JFrame("df");
	        		jframe.setSize(300, 300);
	        		jframe.setLocation(500, 500);
	        		JButton bb1 = new JButton("dsf");
	        		bb1.setBounds(40, 40, 100, 100);
	        		jframe.add(bb1);
	        		jframe.setVisible(true);
	       */ 		
	        		Shell subShell = new Shell(shell);
	        		subShell.setSize(300,400);
	        		subShell.setText("Input Arguments");
	        		Label title = new Label(subShell,SWT.NONE);
	        		title.setText("K Nearest Neighbour Search");
	        		title.pack();
	        		title.setLocation(100, 50);
	        		Label arg1 =new Label(subShell,SWT.NONE);
	        		arg1.setText("Search Centre:");
	        		arg1.pack();
	        		arg1.setLocation(50, 100);
	        		Combo place = new Combo(subShell,SWT.DROP_DOWN|SWT.READ_ONLY);
	        		String[] items = new String[]{"Beijing","Shanghai","Chengdu"};
	        		place.setItems(items);
	        		place.pack();
	        		place.setLocation(150, 100);
	        		Label arg2 = new Label(subShell,SWT.NONE);
	        		arg2.setText("The k:");
	        		arg2.pack();
	        		arg2.setLocation(50, 150);
	        		Text text =new Text(subShell,SWT.BORDER);
	        		text.setEditable(true);
	        		text.setSize(50,50);
	        		text.pack();
	        		text.setLocation(150, 150);
	        		Group group = new Group(subShell,SWT.NONE);
	        		group.setText("Choose Method");
	        		group.setLayout(new RowLayout());
	        		group.setLocation(0,200);	        		
	        		Button gb1 = new Button(group,SWT.RADIO);
	        		gb1.setText("quadratic rtree");
	        		Button gb2 = new Button(group,SWT.RADIO);
	        		gb2.setText("r* rtree");
	        		Button gb3 = new Button(group,SWT.RADIO);
	        		gb3.setText("linear rtree");
	        		group.pack();
	        		Button b1 = new Button(subShell,SWT.PUSH);
	        		b1.setText("OK");
	        		b1.setLocation(50, 250);
	        		b1.pack();
	        		b1.addSelectionListener(new SelectionAdapter(){
	        			private void showKNNResult(boolean[] res,Shell shell,int k,String searchedID)
	        		    {
	        				try
	        				{
	        					String s ="";
	        					FeatureIterator fi = featureSource.getFeatures().features();
	        					while (fi.hasNext())
		        				{
		        					Feature feature = fi.next();
		        					int n =feature.getNumberOfAttributes();
		        					String id = feature.getID();
		        					if (id.equals(searchedID)) continue;
		        					int start = id.indexOf('.');
		        					int value=0;
		        					for (int i=start+1;i<id.length();i++)
		        						value=value*10+id.charAt(i)-'0';
		        					System.out.println(value);
		        					if (res[value])
		        						s+=feature.getAttribute(n-1)+" ";
		        				}
	        					MessageBox mb = new MessageBox(shell,SWT.OK);
	        					mb.setText("Result");
	        					mb.setMessage("The nearest "+k+" cities "+"are "+s);
	        					mb.open();
	        				}
	        				catch (Exception e)
	        				{
	        					e.printStackTrace();
	        				}
	        				
	        		    }
	        			public void widgetSelected(SelectionEvent event)
	        			{
	        				Shell ss = ((Button)event.getSource()).getShell();
	        				Control[] con = ss.getChildren();
	        				Combo combo = (Combo)con[2];
	        				Text text = (Text)con[4];
	        				
	        				if (combo.getText().length()==0||text.getText().length()==0)
	        				{
	        					MessageBox mb = new MessageBox(ss,SWT.OK);
	        					mb.setMessage("please input the place and the k");
	        					mb.setText("warning");
	        					mb.open();
	        				}
	        				else
	        				{
	        					Group g = (Group)con[5];
	        					Control[] buttons = g.getChildren();
	        					Button button1 = (Button)buttons[0];
	        					Button button2 = (Button)buttons[1];
	        					Button button3 = (Button)buttons[2];
	        					if (!button1.getSelection()&&!button2.getSelection()
	        							&&!button3.getSelection())
	        					{
	        						MessageBox mb1 = new MessageBox(ss,SWT.OK);
	        						mb1.setText("warning");
	        						mb1.setMessage("Please select the algorithm");
	        						mb1.open();
	        					}
	        					else
	        					{
	        						//call the search algorithm according user's choice;
	        						//there are linearRTree,TR*Tree,QuadRTree
	        						
	        						int type=0;
	        						if (button1.getSelection())
	        						{
	        							//quadratic rtree
	        							type = SpatialIndex.RtreeVariantQuadratic;
	        						}
	        						else if (button2.getSelection())
	        						{
	        							//r* rtree
	        							type = SpatialIndex.RtreeVariantRstar;
	        											}
	        						else
	        						{
	        							type = SpatialIndex.RtreeVariantLinear;
	        						}
	        						RStarTree rst = new RStarTree();
        							Integer indexID = rst.buildRStarTree(featureSource, tree_file,type);
        							//indexID = rst.buildRStarTree(featureSource, tree_file);
        							String str = text.getText().trim();
        							int m = str.length();
        							int value=0;
        							for (int i=0;i<m;i++)
        								value=value*10+str.charAt(i)-'0';
        							try
        							{
        								FeatureCollection fc = featureSource.getFeatures();
        								FeatureIterator fi = fc.features();
        								Point p=null;
        								String place = combo.getText();
        								String searchedID="";
        								while (fi.hasNext())
        								{
        									Feature feature = fi.next();
        									m=feature.getNumberOfAttributes();
        									if (((String)feature.getAttribute(m-1)).equals(place))
        									{
        										com.vividsolutions.jts.geom.Point p1 = (com.vividsolutions.jts.geom.Point)(feature.getAttribute(0));
        										double[] f = new double[2];
        										f[0] = p1.getX();f[1]=p1.getY();
        										p = new Point(f);
        										searchedID = feature.getID();
        										break;
        									}
        								}
        								boolean[] res =rst.QueryRStarTree(p,value+1,indexID,type);
        								System.out.println("---------------------------------");
        								for (int i=0;i<50;i++)
        									if (res[i])
        										System.out.println(i);
        								showKNNResult(res,ss,value,searchedID);
        								
        							}
        							catch (IOException e)
        							{
        								e.printStackTrace();
        							}
        							//ss.dispose();
	        					}
	        				}
	        				
	        			}
	        		});
	        		Button b2 = new Button(subShell,SWT.PUSH);
	        		b2.setText("CANCEL");
	        		b2.setLocation(150, 250);
	        		b2.pack();
	        		b2.addSelectionListener(new SelectionAdapter(){
	        			public void widgetSelected(SelectionEvent event)
	        			{
	        				(((Button)event.getSource()).getShell()).dispose();
	        			}
	        		});

	        		subShell.open();
	        	}
	        });
//	        buttons.add(searchButton);
	        
	        JButton zoomInButton = new JButton("Zoom In");
	        zoomInButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	                mapPane.setState(JMapPane.ZoomIn);
	            }
	        });
	        buttons.add(zoomInButton);

	        JButton zoomOutButton = new JButton("Zoom Out");
	        zoomOutButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	                mapPane.setState(JMapPane.ZoomOut);
	            }
	        });
	        buttons.add(zoomOutButton);

	        JButton pamButton = new JButton("Move");
	        pamButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	                mapPane.setState(JMapPane.Pan);
	            }
	        });
	        buttons.add(pamButton);

	        frame.add(buttons, BorderLayout.NORTH);

//	        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	        frame.setSize(600, 400);
	        frame.setVisible(true);
	        shell.open();
	        
/*			Shell shell = new Shell(s);
			shell.setSize(600,200);
			shell.setText("Aoristic Result");
			shell.setLayout(new FillLayout());
			shell.layout();
			
			Composite com = new Composite(shell,SWT.EMBEDDED);
			com.setLayout(new FillLayout());
			com.layout();
			com.setVisible(true);
			Frame frame = SWT_AWT.new_Frame(com);
			frame.add(new ChartPanel(createJFreeChart(res,pc,place)));
			frame.pack();
			frame.setVisible(true);
			shell.open();
//			shell.close();
*/
	    }

	    
	    private static File getShapeFile(String[] args)
	            throws FileNotFoundException {
	        File file;
	        if (args.length == 0) {
	            JFileChooser chooser = new JFileChooser();
	            chooser.setDialogTitle("Open Shapefile for Reprojection");
	            chooser.setFileFilter(new FileFilter() {
	                public boolean accept(File f) {
	                    return f.isDirectory() || f.getPath().endsWith("shp")
	                            || f.getPath().endsWith("SHP");
	                }

	                public String getDescription() {
	                    return "Shapefiles";
	                }
	            });
	            int returnVal = chooser.showOpenDialog(null);

	            if (returnVal != JFileChooser.APPROVE_OPTION) {
	                System.exit(0);
	            }
	            file = chooser.getSelectedFile();

	            System.out
	                    .println("You chose to open this file: " + file.getName());
	        } else {
	            file = new File(args[0]);
	        }
	        if (!file.exists()) {
	            throw new FileNotFoundException(file.getAbsolutePath());
	        }
	        return file;
	    }

	    /** Figure out the URL for the "sld" file */
	    public static File toSLDFile(File file)  {
	        String filename = file.getAbsolutePath();
	        if (filename.endsWith(".shp") || filename.endsWith(".dbf")
	                || filename.endsWith(".shx")) {
	            filename = filename.substring(0, filename.length() - 4);
	            filename += ".sld";
	        } else if (filename.endsWith(".SLD") || filename.endsWith(".SLD")
	                || filename.endsWith(".SLD")) {
	            filename = filename.substring(0, filename.length() - 4);
	            filename += ".SLD";
	        }
	        return new File(filename);
	    }
}
