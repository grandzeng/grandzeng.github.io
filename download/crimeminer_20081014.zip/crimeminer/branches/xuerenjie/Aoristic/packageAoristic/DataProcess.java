package packageAoristic;
import java.sql.*;

public class DataProcess {
	
	private double[] res;
	private int start_year;
	private int start_month;
	private int end_year;
	private int end_month;
	private int start_day;
	private int end_day;
	private Date start_date;
	private Date end_date;
	final private int[] month={0,31,28,31,30,31,30,31,31,30,31,30,31};
	int[] dayCnt;
	int[] hourCnt;
	private boolean isBigMonth(int m)
	{
		return m==1||m==3||m==5||m==7||m==8||m==10||m==12;
	}
	private boolean isLeapYear(int year)
	{
		return year%4==0&&year%100!=0||year%400==0;
	}
	
	private void getDays()
	{		
		int i;
		for (i=1;i<=31;i++)
			dayCnt[i]=0;
		if (start_year==end_year)
			if (start_month==end_month)
			{
				for (i=start_day;i<=end_day;i++) 
					dayCnt[i]++;
			}
			else
			{
				
				for (i=1;i<=30;i++)
				{
					dayCnt[i]+=end_month-start_month-1;
					dayCnt[i]+=(i>=start_day&&i<=month[start_month]?1:0);
					dayCnt[i]+=(i<=end_day?1:0);
				}
				for (i=start_month+1;i<=end_month-1;i++)
					if (isBigMonth(i))
						dayCnt[31]++;
				if (start_month<2&&end_month>2)
				{
					dayCnt[30]--;
					if (!isLeapYear(start_year))
						dayCnt[29]--;
				}
			}
		else
		{
			for (i=1;i<=30;i++)
			{
				dayCnt[i]+=12*(end_year-start_year-1);
				dayCnt[i]+=ConstantData.month-start_month;
				dayCnt[i]+=end_month-1;
				dayCnt[i]+=(i>=start_day&&i<=month[start_month]?1:0);
				dayCnt[i]+=(i<=end_day?1:0);
			}
			dayCnt[31]+=7*(end_year-start_year-1);
			dayCnt[30]-=(end_year-start_year-1);
			for (i=start_year+1;i<=end_year-1;i++)
				if (!isLeapYear(i))
					dayCnt[29]--;
			for (i=start_month+1;i<=ConstantData.month;i++)
				if (isBigMonth(i))
					dayCnt[31]++;
			if (start_month<2)
			{
				dayCnt[30]--;
				if (!isLeapYear(start_year))
					dayCnt[29]--;
			}
			if (end_month>2)
			{
				dayCnt[30]--;
				if (!isLeapYear(end_year))
					dayCnt[29]--;
			}		
		}
	}
	/*calculate how many months or how mays days 
	 *or how many hours between the start_date and 
	 *the end_date of the crime record according to 
	 *the precision(dimension) the user choose and then
	 *calculate the prossibility of every month or every 
	 *day or every hour the crime may happen and store into
	 *the array res[] 
	 */
	public double[] statistic(ResultSet set,int precision)
	throws SQLException
	{
		res = new double[precision+1];
		if (precision!=ConstantData.month)
			dayCnt= new int[ConstantData.day+1];
		if (precision==ConstantData.hour)
			hourCnt = new int[ConstantData.hour+1];
		while (set.next())
		{
			start_date = set.getDate("StartTime");
			end_date = set.getDate("EndTime");
			start_year = start_date.getYear()+1900;
			end_year = end_date.getYear()+1900;
			start_month=start_date.getMonth()+1;
			end_month=end_date.getMonth()+1;
			start_day=start_date.getDate();
			end_day = end_date.getDate();
			int i;
			int total_day=0;
			switch (precision)
			{
			case ConstantData.month:
				int total_month=0;
				if (start_year==end_year)
					total_month=end_month-start_month+1;
				else
					total_month=ConstantData.month-start_month+1
					+end_month+(end_year-start_year-1)
					*ConstantData.month;
				double t=(double)1/total_month;
				if (start_year==end_year)
					for (i=start_month;i<=end_month;i++)
						res[i]+=t;
				else
				{
					for (i=start_month;i<=ConstantData.month;i++)
						res[i]+=t;
					for (i=1;i<=end_month;i++)
						res[i]+=t;
					for (i=1;i<=ConstantData.month;i++)
						res[i]+=t*(end_year-start_year-1);
				}
				break;
			case ConstantData.day:
				getDays();
				for (i=1;i<=31;i++)
					total_day+=dayCnt[i];
				for (i=1;i<=31;i++)
					res[i]+=(double)dayCnt[i]/total_day;
				break;
			case ConstantData.hour:
				Time start_time = set.getTime("StartTime");
				Time end_time = set.getTime("EndTime");
				int start_hour = start_time.getHours();
				int end_hour = end_time.getHours();
				int total_hour=0;
				if (start_date.equals(end_date))
				{
					for (i=start_hour;i<=end_hour+1;i++)
					{
						total_hour++;
						hourCnt[i]++;
					}
				}
				else
				{
					getDays();
					dayCnt[start_date.getDate()]--;
					dayCnt[end_date.getDate()]--;
					for (i=1;i<=31;i++)
						total_day+=dayCnt[i];
					for (i=0;i<24;i++)
						hourCnt[i]=total_day;
					total_hour=24*total_day;
					for (i=start_hour;i<24;i++)
					{
						total_hour++;
						hourCnt[i]++;
					}
					for (i=0;i<=end_hour+1;i++)
					{
						total_hour++;
						hourCnt[i]++;
					}
				}
				for (i=0;i<24;i++)
					res[i]+=(double)hourCnt[i]/total_hour;
				break;
			}
		}
		return res;
	}
}
