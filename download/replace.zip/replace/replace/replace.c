/*
 * replace.c
 *
 *  Created on: Jan 27, 2010
 *      Author: grand
 */
#define _FILE_OFFSET_BITS 64
#define __USE_FILE_OFFSET64
#define __USE_LARGEFILE64
#define _LARGEFILE64_SOURCE

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define BUFF_SIZE 1024
#define true 1
#define false 0

char in_buff[BUFF_SIZE];
char out_buff[BUFF_SIZE];

//the pattern string
char* pPat = NULL;
unsigned int len_pat = 0;
//the new value for pattern string
char* pVal = NULL;
unsigned int len_val = 0;

//statics result
unsigned long long inTotal = 0;
unsigned long long match = 0;
unsigned long long outTotal = 0;

void usage()
{
	printf("replace <srcFile> <destFile> <val> <pat>\n");
}

void outBuff(FILE * pDest, char* pBuff, int in_start, int in_end, int flush)
{

	static unsigned int outPos = 0;
	//force to write data to file.
	if (flush == true)
	{
		outTotal += fwrite(out_buff, sizeof(char), outPos, pDest);
		return;
	}
	//write data into out_buffer
	if (BUFF_SIZE-outPos > in_end - in_start)
	{
		memcpy(out_buff + outPos, pBuff + in_start, in_end - in_start);
		outPos += in_end - in_start;
	}
	//the out_buff is full, so write data to file.
	else
	{
		outTotal += fwrite(out_buff, sizeof(char), outPos, pDest);
		outTotal += fwrite(pBuff + in_start, sizeof(char), in_end - in_start,
				pDest);
		outPos = 0;
	}
}

int inBuff(FILE * pSrc)
{
	int c;
	c = fread(in_buff, sizeof(char), BUFF_SIZE,pSrc);
	inTotal += c;
	return c;
}

int adjust(int patPos, FILE* pDest)
{
	int help = patPos;
	int temp = 1;
	int beg = 1;
	patPos = 0;
	while (temp < help)
	{
		if (pPat[patPos] == pPat[temp])
		{
			patPos++;
			temp++;
		}
		else
		{
			beg++;
			temp = beg;
			patPos = 0;
		}
	}
	outBuff(pDest, pPat, 0, help - patPos, false);
	return patPos;

}

void matchPat(FILE* pSrc, FILE* pDest)
{
	int inPos = 0;
	int patPos = 0;
	int in_len = 0;
	int i;
	in_len = inBuff(pSrc);
	while (true)
	{
		for (i = inPos; i < in_len && patPos < len_pat;)
		{
			if (*(in_buff + i) != *(pPat + patPos))
			{
				if (i - patPos < 0)
				{
					patPos = adjust(patPos, pDest);
				}
				else
				{
					i = i - patPos + 1;
					patPos = 0;
				}
			}
			else
			{
				i++;
				patPos++;
			}
		}
		// reach the end of the in_buff
		if (i == in_len)
		{
			if (in_len - patPos > inPos)
				outBuff(pDest, in_buff, inPos, in_len - patPos, false);
			inPos = 0;
			if (feof(pSrc))
			{
				outBuff(pDest, NULL,0, 0, true);
				return;
			}
			in_len = inBuff(pSrc);
		}
		// succeed in matching a pattern
		else
		{
			if (i - patPos > inPos)
				outBuff(pDest, in_buff, inPos, i - patPos, false);
			inPos = i;
			outBuff(pDest, pVal, 0, len_val, false);
			patPos = 0;
			match++;
		}
	}
}

int main(int argc, char** argv)
{
	FILE* pSrc = NULL;
	FILE* pDest = NULL;

	if (argc < 4)
	{
		usage();
		return 1;
	}
	if ((pSrc = fopen(argv[1], "rb")) == NULL)
	{
		printf("can not open the src file:%s \n", argv[1]);
		return 1;
	}
	if ((pDest = fopen(argv[2], "wb")) == NULL)
	{
		printf("can not open the dest file:%s \n", argv[2]);
		return 1;
	}

	if ((pVal = malloc(strlen(argv[3]) * sizeof(char))) == NULL)
	{
		printf("encounter error when allocating memory for value\n");
		return 1;
	}

	len_val = strlen(argv[3]);
	memcpy(pVal, argv[3], len_val);
if(argc>4){
		if ((pPat = malloc(strlen(argv[4]) * sizeof(char))) == NULL)
		{
			printf("encounter error when allocating memory for pattern\n");
			return 1;
		}
		len_pat = strlen(argv[4]);
		memcpy(pPat, argv[4], len_pat);
}
else
	{
			pPat=malloc(sizeof(char));
			*pPat=(char)5;
			len_pat=1;
		}
	//	replace start
	matchPat(pSrc, pDest);
	// replace end
	// clean the resource
	fclose(pSrc);
	fclose(pDest);
	free(pPat);
	free(pVal);
	printf("===============================================================\n");
	printf("buffer size: %u bytes\n", BUFF_SIZE);
	printf("src file size:  %u bytes\n", inTotal);
	printf("dest file size: %u bytes\n", outTotal);
	printf("length of pattern: %u bytes\n", len_pat);
	printf("length of replace value: %u bytes\n", len_val);
	printf("match count: %u \n", match);
	printf("===============================================================\n");
	return 0;
}
